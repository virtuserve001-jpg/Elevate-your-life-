package com.eyl.app.ui

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.engine.BackupEngine
import com.eyl.app.service.LockdownAccessibilityService
import kotlinx.coroutines.launch

/**
 * Walks the user through every permission EYL needs but cannot grant
 * itself. Each of these requires explicit user action by Android's
 * design — this screen just makes that action easy to find and shows
 * live status so the user (and you, during sanity-check) can see at a
 * glance what's actually enabled versus what's still pending.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var statusAccessibility: TextView
    private lateinit var statusBattery: TextView
    private lateinit var statusNotifications: TextView
    private lateinit var statusExactAlarm: TextView

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) performExport(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) performImport(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.eyl.app.R.layout.activity_setup)

        statusAccessibility = findViewById(com.eyl.app.R.id.statusAccessibility)
        statusBattery = findViewById(com.eyl.app.R.id.statusBattery)
        statusNotifications = findViewById(com.eyl.app.R.id.statusNotifications)
        statusExactAlarm = findViewById(com.eyl.app.R.id.statusExactAlarm)

        findViewById<Button>(com.eyl.app.R.id.buttonEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(com.eyl.app.R.id.buttonDisableBatteryOptimization).setOnClickListener {
            openBatterySettings()
        }
        findViewById<Button>(com.eyl.app.R.id.buttonEnableNotifications).setOnClickListener {
            openNotificationSettings()
        }
        findViewById<Button>(com.eyl.app.R.id.buttonEnableExactAlarm).setOnClickListener {
            openExactAlarmSettings()
        }
        findViewById<Button>(com.eyl.app.R.id.buttonRefreshStatus).setOnClickListener { refreshStatus() }

        findViewById<Button>(com.eyl.app.R.id.buttonExportBackup).setOnClickListener {
            exportLauncher.launch("eyl_backup_${java.time.LocalDate.now()}.json")
        }
        findViewById<Button>(com.eyl.app.R.id.buttonImportBackup).setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("Import backup")
                .setMessage("This will add the backup's tasks, points history, and templates to what's already here (existing entries with matching IDs will be overwritten). Continue?")
                .setPositiveButton("Choose file") { _, _ -> importLauncher.launch(arrayOf("application/json")) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun performExport(uri: Uri) {
        val app = application as EylApplication
        lifecycleScope.launch {
            try {
                val tasks = app.repository.getAllTasksEver()
                val ledgers = app.repository.getAllLedgersEver()
                val templates = app.repository.getTemplates()
                val json = BackupEngine.exportToJson(tasks, ledgers, templates)
                contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                Toast.makeText(this@SetupActivity, "Backup exported", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@SetupActivity, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun performImport(uri: Uri) {
        val app = application as EylApplication
        lifecycleScope.launch {
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Could not read the selected file")
                val result = BackupEngine.importFromJson(json)
                app.repository.restoreFromBackup(result.tasks, result.ledgers, result.templates)
                Toast.makeText(this@SetupActivity, "Backup imported (${result.tasks.size} tasks, ${result.ledgers.size} days, ${result.templates.size} templates)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this@SetupActivity, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus() // user is likely returning from a Settings screen — check what changed
    }

    private fun refreshStatus() {
        statusAccessibility.text = if (isAccessibilityServiceEnabled())
            "✅ Enabled" else "❌ Not enabled — tasks won't be locked down"

        statusBattery.text = if (isIgnoringBatteryOptimizations())
            "✅ Unrestricted" else "❌ Restricted — lockdown may be killed mid-task"

        statusNotifications.text = if (areNotificationsEnabled())
            "✅ Enabled" else "❌ Not enabled — foreground service can't show its notification"

        statusExactAlarm.text = if (canScheduleExactAlarms())
            "✅ Enabled" else "❌ Not enabled — wake-up alarm may fire late or not at all"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        // instance being non-null means the service is actively connected
        // right now, which is the most direct signal we have without
        // parsing Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES manually.
        if (LockdownAccessibilityService.instance != null) return true

        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val expected = "$packageName/${LockdownAccessibilityService::class.java.name}"
        return enabledServices.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun openBatterySettings() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Some OEM skins block this intent directly — fall back to the general battery settings screen.
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun areNotificationsEnabled(): Boolean {
        return androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
    }

    private fun openNotificationSettings() {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.parse("package:$packageName"))
        }
        startActivity(intent)
    }

    private fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true // no runtime check needed pre-Android 12
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
        }
    }
}
