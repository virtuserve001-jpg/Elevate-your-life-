package com.eyl.app.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.WakeUpGameState
import com.eyl.app.engine.WakeUpGameEngine
import com.eyl.app.service.LockdownForegroundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

/**
 * The mandatory wake-up game. Cannot be dismissed except by winning a
 * round — no back button handling that exits, no swipe-away (excludeFromRecents
 * + singleInstance is set in the manifest for exactly this reason).
 *
 * Game itself: tap number tiles 1..N in ascending order within a time
 * limit. Both N and the time limit come from WakeUpGameEngine.paramsForLevel(),
 * so the "gets harder every failed attempt" rule lives in exactly one
 * place (WakeUpGameEngine), not duplicated here.
 */
class AlarmGameActivity : AppCompatActivity() {

    private lateinit var app: EylApplication
    private lateinit var grid: GridLayout
    private lateinit var textAttemptInfo: TextView
    private lateinit var textGameTimer: TextView

    private var state: WakeUpGameState? = null
    private var nextExpectedNumber = 1
    private var roundTimerJob: kotlinx.coroutines.Job? = null
    private var penaltyCheckJob: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_game)
        app = application as EylApplication

        grid = findViewById(R.id.gridTiles)
        textAttemptInfo = findViewById(R.id.textAttemptInfo)
        textGameTimer = findViewById(R.id.textGameTimer)

        lifecycleScope.launch {
            val today = LocalDate.now()
            var loaded = app.repository.getWakeUpState(today)
            if (loaded == null) {
                loaded = WakeUpGameEngine.start(today, LocalTime.now())
                app.repository.saveWakeUpState(loaded)
            }
            state = loaded
            startRound()
            startPenaltyWatcher()
        }
    }

    /** No back-button exit — this is intentional per the "no ceiling, must beat it" rule. */
    override fun onBackPressed() {
        // no-op
    }

    private fun startPenaltyWatcher() {
        penaltyCheckJob = lifecycleScope.launch {
            while (true) {
                delay(15_000)
                val s = state ?: continue
                val updated = WakeUpGameEngine.checkPenalty(s, LocalTime.now())
                if (updated != s) {
                    state = updated
                    app.repository.saveWakeUpState(updated)
                }
            }
        }
    }

    private fun startRound() {
        val s = state ?: return
        val params = WakeUpGameEngine.paramsForLevel(s.currentDifficultyLevel)
        nextExpectedNumber = 1
        textAttemptInfo.text = "Attempt ${s.attempts + 1} · difficulty ${s.currentDifficultyLevel}"

        buildGrid(params.targetSequenceLength, params.distractionsEnabled)
        runRoundTimer(params.timeLimitSeconds)
    }

    private fun buildGrid(sequenceLength: Int, distractionsEnabled: Boolean) {
        grid.removeAllViews()
        grid.columnCount = 4

        val numberLabels = (1..sequenceLength).map { it.toString() }.toMutableList()
        val decoyCount = if (distractionsEnabled) (sequenceLength / 2).coerceAtLeast(2) else 0
        val decoyLabels = (1..decoyCount).map { listOf('★', '?', '#', '@', '%').random().toString() }

        val allLabels = (numberLabels + decoyLabels).shuffled()

        allLabels.forEach { label ->
            val button = Button(this).apply {
                text = label
                textSize = 20f
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 160
                    height = 160
                    setMargins(8, 8, 8, 8)
                }
                setOnClickListener { onTileTapped(label) }
            }
            grid.addView(button)
        }
    }

    private fun onTileTapped(label: String) {
        val expected = nextExpectedNumber.toString()
        if (label != expected) {
            onRoundFailed()
            return
        }
        nextExpectedNumber++
        val s = state ?: return
        val params = WakeUpGameEngine.paramsForLevel(s.currentDifficultyLevel)
        if (nextExpectedNumber > params.targetSequenceLength) {
            onRoundWon()
        }
    }

    private fun runRoundTimer(seconds: Int) {
        roundTimerJob?.cancel()
        roundTimerJob = lifecycleScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                textGameTimer.text = "$remaining s"
                delay(1000)
                remaining--
            }
            onRoundFailed()
        }
    }

    private fun onRoundFailed() {
        roundTimerJob?.cancel()
        val s = state ?: return
        val updated = WakeUpGameEngine.onAttemptFailed(s)
        state = updated
        lifecycleScope.launch {
            app.repository.saveWakeUpState(updated)
            startRound() // immediately re-present, one level harder — no ceiling
        }
    }

    private fun onRoundWon() {
        roundTimerJob?.cancel()
        val s = state ?: return
        val updated = WakeUpGameEngine.onGameBeaten(s, LocalTime.now())
        state = updated
        lifecycleScope.launch {
            app.repository.saveWakeUpState(updated)
            LockdownForegroundService.stopAlarmRinging(this@AlarmGameActivity)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        roundTimerJob?.cancel()
        penaltyCheckJob?.cancel()
    }
}
