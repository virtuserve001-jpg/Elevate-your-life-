package com.eyl.app.data.db

import androidx.room.*
import com.eyl.app.data.model.PointsLedger
import com.eyl.app.data.model.SpendAllocation
import com.eyl.app.data.model.WakeUpGameState
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface PointsLedgerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ledger: PointsLedger)

    @Query("SELECT * FROM points_ledger WHERE date = :date LIMIT 1")
    suspend fun getForDate(date: LocalDate): PointsLedger?

    @Query("SELECT * FROM points_ledger ORDER BY date DESC LIMIT :limit")
    fun observeRecent(limit: Int = 30): Flow<List<PointsLedger>>
}

@Dao
interface WakeUpGameStateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: WakeUpGameState)

    @Query("SELECT * FROM wake_up_game_state WHERE date = :date LIMIT 1")
    suspend fun getForDate(date: LocalDate): WakeUpGameState?

    @Query("SELECT * FROM wake_up_game_state WHERE date = :date LIMIT 1")
    fun observeForDate(date: LocalDate): Flow<WakeUpGameState?>
}

@Dao
interface SpendAllocationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(allocation: SpendAllocation)

    @Query("SELECT * FROM spend_allocation WHERE date = :date LIMIT 1")
    suspend fun getForDate(date: LocalDate): SpendAllocation?
}
