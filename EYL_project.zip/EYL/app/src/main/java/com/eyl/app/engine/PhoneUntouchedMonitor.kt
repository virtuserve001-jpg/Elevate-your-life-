package com.eyl.app.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager

/**
 * Enforcement for LockdownMode.NONE tasks (prayer, adhkar, tahajud) —
 * these need the OPPOSITE check from app-blocking: rather than confining
 * the user to allowed apps, any phone interaction at all during the
 * window should fail the task, since the whole point is the phone is
 * meant to be put down.
 *
 * Signals watched (all via dynamically-registered receivers, since these
 * are implicit broadcasts the Manifest can't statically register for
 * since Android 8):
 * - ACTION_SCREEN_ON: the screen was turned on during the window.
 * - ACTION_USER_PRESENT: the device was unlocked during the window. This
 *   catches a case ACTION_SCREEN_ON alone would miss — e.g. some OEM
 *   always-on-display setups where the screen technically never went
 *   fully "off", but the user still unlocked and used the phone.
 * - An immediate check at start(): if the screen is ALREADY on the
 *   moment the task begins (task started right after using the phone,
 *   screen hasn't timed out yet), that's caught synchronously rather
 *   than waiting for a future SCREEN_ON event that will never fire
 *   because the screen was already on.
 *
 * Known gap: this still can't detect a phone that's already on, already
 * unlocked, and sitting face-up on a table being glanced at/touched
 * without a fresh unlock event. Closing that fully would need touch or
 * accelerometer sampling, which costs real battery on a low-end device —
 * a deliberate v1 tradeoff, flagged here rather than hidden.
 */
class PhoneUntouchedMonitor(private val context: Context) {

    private var receiver: BroadcastReceiver? = null

    /**
     * @return true if the phone was already on/unlocked at the moment of
     *         starting — callers should treat this as an immediate failure
     *         rather than starting the countdown at all.
     */
    fun start(onPhoneTouched: () -> Unit): Boolean {
        stop() // guard against double-registration

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val alreadyOn = powerManager?.isInteractive == true
        if (alreadyOn) {
            return true
        }

        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> onPhoneTouched()
                }
            }
        }
        receiver = r
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        context.registerReceiver(r, filter)
        return false
    }

    fun stop() {
        receiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (e: IllegalArgumentException) {
                // already unregistered — safe to ignore
            }
        }
        receiver = null
    }
}
