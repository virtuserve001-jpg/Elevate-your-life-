package com.eyl.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.eyl.app.data.EylRepository
import com.eyl.app.data.db.EylDatabase
import com.eyl.app.data.model.Task
import com.eyl.app.engine.TaskTimerManager
import com.eyl.app.ui.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * LockdownForegroundService
 * -------------------------
 * Owns the single running TaskTimerManager for the whole app. Runs as a
 * foreground service with a persistent notification specifically so
 * Android Go's memory manager doesn't kill it mid-task — background
 * services get reaped aggressively on devices like the A50, which would
 * silently break lockdown enforcement.
 *
 * Any Activity (MainActivity, TaskLockdownActivity) talks to the running
 * task by:
 *  1. Sending a start command via startTask()/cancelTask() (static helpers)
 *  2. Observing `eventFlow` for ticks/completion/failure, since that flow
 *     lives here and outlives any single Activity being paused/destroyed
 *     (e.g. screen turning off during a prayer task).
 */
class LockdownForegroundService : LifecycleService() {

    companion object {
        private const val CHANNEL_ID = "eyl_lockdown_channel"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START_TASK = "com.eyl.app.action.START_TASK"
        const val ACTION_CANCEL_TASK = "com.eyl.app.action.CANCEL_TASK"
        const val ACTION_START_ALARM_RINGING = "com.eyl.app.action.START_ALARM_RINGING"
        const val ACTION_STOP_ALARM_RINGING = "com.eyl.app.action.STOP_ALARM_RINGING"
        const val EXTRA_TASK_ID = "extra_task_id"
        private const val ALARM_CHANNEL_ID = "eyl_alarm_channel"
        private const val ALARM_NOTIFICATION_ID = 1002

        @Volatile var instance: LockdownForegroundService? = null
            private set

        fun startTask(context: Context, taskId: String) {
            val intent = Intent(context, LockdownForegroundService::class.java).apply {
                action = ACTION_START_TASK
                putExtra(EXTRA_TASK_ID, taskId)
            }
            context.startForegroundService(intent)
        }

        fun cancelTask(context: Context) {
            val intent = Intent(context, LockdownForegroundService::class.java).apply {
                action = ACTION_CANCEL_TASK
            }
            context.startService(intent)
        }

        /** Called by AlarmReceiver when the wake-up alarm fires. */
        fun startAlarmRinging(context: Context) {
            val intent = Intent(context, LockdownForegroundService::class.java).apply {
                action = ACTION_START_ALARM_RINGING
            }
            context.startForegroundService(intent)
        }

        /**
         * Called ONLY by AlarmGameActivity when WakeUpGameEngine confirms
         * the game was actually beaten. There is deliberately no other
         * path that stops the ringing — no snooze, no swipe-to-dismiss.
         */
        fun stopAlarmRinging(context: Context) {
            val intent = Intent(context, LockdownForegroundService::class.java).apply {
                action = ACTION_STOP_ALARM_RINGING
            }
            context.startService(intent)
        }
    }

    private lateinit var repository: EylRepository
    private lateinit var timerManager: TaskTimerManager
    private var alarmMediaPlayer: MediaPlayer? = null
    private var alarmVibrator: Vibrator? = null

    private val _eventFlow = MutableStateFlow<TaskTimerManager.TimerEvent?>(null)
    val eventFlow: StateFlow<TaskTimerManager.TimerEvent?> = _eventFlow.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        instance = this
        repository = EylRepository(EylDatabase.getInstance(applicationContext))
        timerManager = TaskTimerManager(repository, lifecycleScope, applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START_TASK -> {
                val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return START_NOT_STICKY
                startForeground(NOTIFICATION_ID, buildNotification("Task in progress — stay locked in"))
                lifecycleScope.launchWhenStarted {
                    val task = repository.getTask(taskId) ?: return@launchWhenStarted
                    beginTask(task)
                }
            }
            ACTION_CANCEL_TASK -> {
                timerManager.cancel("Cancelled via foreground service command")
                _eventFlow.value = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_START_ALARM_RINGING -> startAlarmRinging()
            ACTION_STOP_ALARM_RINGING -> stopAlarmRingingInternal()
        }
        // START_STICKY so the system tries to recreate this service if it's
        // killed anyway (last line of defense on very aggressive OEM skins).
        return START_STICKY
    }

    private fun beginTask(task: Task) {
        timerManager.start(task) { event ->
            _eventFlow.value = event
            when (event) {
                is TaskTimerManager.TimerEvent.Tick ->
                    updateNotification("Locked in — ${event.secondsRemaining / 60}m ${event.secondsRemaining % 60}s left")
                is TaskTimerManager.TimerEvent.Completed -> {
                    updateNotification("Task complete ✓")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                is TaskTimerManager.TimerEvent.Failed -> {
                    updateNotification("Task failed — ${event.reason}")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
    }

    private fun startAlarmRinging() {
        createAlarmNotificationChannel()
        startForeground(ALARM_NOTIFICATION_ID, buildAlarmNotification())

        if (alarmMediaPlayer != null) return // already ringing, don't double-start

        val alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

        alarmMediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            setDataSource(this@LockdownForegroundService, alarmUri)
            isLooping = true
            prepare()
            start()
        }

        alarmVibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        val pattern = longArrayOf(0, 500, 500)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            alarmVibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            alarmVibrator?.vibrate(pattern, 0)
        }
    }

    /**
     * The only exit path from a ringing alarm. Called via
     * ACTION_STOP_ALARM_RINGING, which only AlarmGameActivity triggers,
     * and only after WakeUpGameEngine.onGameBeaten() has fired.
     */
    private fun stopAlarmRingingInternal() {
        alarmMediaPlayer?.stop()
        alarmMediaPlayer?.release()
        alarmMediaPlayer = null
        alarmVibrator?.cancel()
        alarmVibrator = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createAlarmNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALARM_CHANNEL_ID, "EYL Wake-Up Alarm", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "The mandatory wake-up alarm — beat the game to stop it"
                setSound(null, null) // audio is handled manually via MediaPlayer(USAGE_ALARM), not the channel
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildAlarmNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, com.eyl.app.ui.AlarmGameActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ALARM_CHANNEL_ID)
            .setContentTitle("Wake up")
            .setContentText("Beat the game to turn off the alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
        alarmMediaPlayer?.release()
        alarmVibrator?.cancel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "EYL Lockdown", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shows while a locked task is running" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("EYL")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }
}
