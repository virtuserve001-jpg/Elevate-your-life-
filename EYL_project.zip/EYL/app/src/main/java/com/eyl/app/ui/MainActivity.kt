package com.eyl.app.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.*
import com.eyl.app.engine.PointsEngine
import com.eyl.app.service.LockdownAccessibilityService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

/**
 * Daily dashboard. Deliberately simple views (no RecyclerView) since the
 * task list per day is short (9 must-tasks + however many optional ones a
 * disciplined person realistically adds) — a ScrollView of inflated rows
 * is lighter on a low-RAM device than standing up a RecyclerView + adapter
 * for what is, in practice, a small list.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var app: EylApplication
    private lateinit var textDate: TextView
    private lateinit var textPointsSummary: TextView
    private lateinit var textGatekeeperWarning: TextView
    private lateinit var containerMustTasks: LinearLayout
    private lateinit var containerOptionalTasks: LinearLayout

    private val today: LocalDate get() = LocalDate.now()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        app = application as EylApplication

        textDate = findViewById(R.id.textDate)
        textPointsSummary = findViewById(R.id.textPointsSummary)
        textGatekeeperWarning = findViewById(R.id.textGatekeeperWarning)
        containerMustTasks = findViewById(R.id.containerMustTasks)
        containerOptionalTasks = findViewById(R.id.containerOptionalTasks)
        findViewById<Button>(R.id.buttonAddTask).setOnClickListener { showAddTaskDialog() }
        findViewById<Button>(R.id.buttonSpendPoints).setOnClickListener {
            startActivity(Intent(this, SpendActivity::class.java))
        }
        findViewById<Button>(R.id.buttonSetup).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }

        textDate.text = today.toString()

        lifecycleScope.launch {
            app.repository.ensureMustTasksExist(today)
        }

        lifecycleScope.launch {
            app.repository.observeTasksForDate(today).collectLatest { tasks ->
                renderTasks(tasks)
                refreshLedgerPreview(tasks)
            }
        }
    }

    private fun renderTasks(allTasks: List<Task>) {
        val must = allTasks.filter { it.category == TaskCategory.MUST }
        val optional = allTasks.filter { it.category == TaskCategory.OPTIONAL }

        containerMustTasks.removeAllViews()
        must.sortedBy { it.mustTaskType?.ordinal ?: 0 }.forEach { task ->
            containerMustTasks.addView(buildTaskRow(task))
        }

        containerOptionalTasks.removeAllViews()
        if (optional.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No optional tasks yet — add one below."
                setTextColor(0xFF888888.toInt())
            }
            containerOptionalTasks.addView(empty)
        } else {
            optional.sortedByDescending { it.tier == ImportanceTier.IMPORTANT }.forEach { task ->
                containerOptionalTasks.addView(buildTaskRow(task))
            }
        }
    }

    private fun buildTaskRow(task: Task): View {
        val row = LayoutInflater.from(this).inflate(R.layout.item_task, containerMustTasks, false)
        val icon = row.findViewById<TextView>(R.id.textTaskStatusIcon)
        val title = row.findViewById<TextView>(R.id.textTaskTitle)
        val meta = row.findViewById<TextView>(R.id.textTaskMeta)
        val action = row.findViewById<Button>(R.id.buttonTaskAction)

        title.text = task.title.replaceFirstChar { it.uppercase() }
        val tierLabel = task.tier?.let { " · ${it.name.lowercase().replace('_', ' ')}" } ?: ""
        meta.text = "${task.durationMinutes} min$tierLabel"

        icon.text = when (task.status) {
            TaskStatus.COMPLETED -> "✅"
            TaskStatus.FAILED -> "❌"
            TaskStatus.IN_PROGRESS -> "⏳"
            TaskStatus.PENDING -> "⬜"
        }

        action.isEnabled = task.status == TaskStatus.PENDING || task.status == TaskStatus.FAILED
        action.text = when (task.status) {
            TaskStatus.COMPLETED -> "Done"
            TaskStatus.IN_PROGRESS -> "Running…"
            TaskStatus.FAILED -> "Retry"
            TaskStatus.PENDING -> "Start"
        }
        action.setOnClickListener {
            val needsAccessibilityService = task.lockdownMode == LockdownMode.SINGLE_APP ||
                task.lockdownMode == LockdownMode.WHITELIST
            if (needsAccessibilityService && LockdownAccessibilityService.instance == null) {
                AlertDialog.Builder(this)
                    .setTitle("Lockdown isn't active")
                    .setMessage("EYL's Accessibility service isn't enabled, so this task would run on a timer with no actual app-blocking. Set it up first, or start anyway on the honor system?")
                    .setPositiveButton("Open setup") { _, _ -> startActivity(Intent(this, SetupActivity::class.java)) }
                    .setNegativeButton("Start anyway") { _, _ -> launchTask(task) }
                    .show()
            } else {
                launchTask(task)
            }
        }

        return row
    }

    private fun launchTask(task: Task) {
        com.eyl.app.service.LockdownForegroundService.startTask(this, task.id)
        startActivity(
            android.content.Intent(this, TaskLockdownActivity::class.java)
                .putExtra(TaskLockdownActivity.EXTRA_TASK_ID, task.id)
        )
    }

    private suspend fun refreshLedgerPreview(allTasks: List<Task>) {
        val must = allTasks.filter { it.category == TaskCategory.MUST }
        val optional = allTasks.filter { it.category == TaskCategory.OPTIONAL }
        val wakeUpState = app.repository.getWakeUpState(today)
        val ledger = PointsEngine.calculateDay(today, must, optional, wakeUpState)

        textPointsSummary.text = "${ledger.finalPoints} points today"
        val anyMustFailed = must.any { it.status == TaskStatus.FAILED }
        textGatekeeperWarning.visibility = if (anyMustFailed) View.VISIBLE else View.GONE
        textGatekeeperWarning.text = "A must-task was missed — today's points are zeroed."
    }

    private fun showAddTaskDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null)
        val editTitle = dialogView.findViewById<EditText>(R.id.editTaskTitle)
        val editDuration = dialogView.findViewById<EditText>(R.id.editTaskDuration)
        val radioTier = dialogView.findViewById<RadioGroup>(R.id.radioGroupTier)
        val radioLockdown = dialogView.findViewById<RadioGroup>(R.id.radioGroupLockdown)
        val editWhitelist = dialogView.findViewById<EditText>(R.id.editWhitelistPackages)

        radioLockdown.setOnCheckedChangeListener { _, checkedId ->
            editWhitelist.visibility = if (checkedId == R.id.radioLockdownWhitelist) View.VISIBLE else View.GONE
        }

        AlertDialog.Builder(this)
            .setTitle("New task")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val title = editTitle.text.toString().trim()
                val duration = editDuration.text.toString().toIntOrNull() ?: 15
                if (title.isEmpty()) return@setPositiveButton

                val tier = if (radioTier.checkedRadioButtonId == R.id.radioTierImportant)
                    ImportanceTier.IMPORTANT else ImportanceTier.LESS_IMPORTANT

                val lockdownMode = if (radioLockdown.checkedRadioButtonId == R.id.radioLockdownWhitelist)
                    LockdownMode.WHITELIST else LockdownMode.SINGLE_APP

                val whitelist = if (lockdownMode == LockdownMode.WHITELIST)
                    editWhitelist.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                else emptyList()

                val task = Task(
                    id = UUID.randomUUID().toString(),
                    date = today,
                    category = TaskCategory.OPTIONAL,
                    title = title,
                    tier = tier,
                    durationMinutes = duration,
                    lockdownMode = lockdownMode,
                    whitelistedPackages = whitelist
                )
                lifecycleScope.launch { app.repository.saveTask(task) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
