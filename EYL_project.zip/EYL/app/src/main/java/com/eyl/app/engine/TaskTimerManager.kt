package com.eyl.app.engine

import android.content.Context
import com.eyl.app.data.EylRepository
import com.eyl.app.data.model.*
import com.eyl.app.service.LockdownAccessibilityService
import kotlinx.coroutines.*
import java.time.LocalDate
import java.time.LocalTime

/**
 * Owns the lifecycle of a single running task: starts the countdown,
 * engages the appropriate lockdown in LockdownAccessibilityService,
 * reacts to a genuine lockdown break, and on natural completion marks
 * the task COMPLETED and recalculates that day's PointsLedger via
 * PointsEngine.
 *
 * Threading: runs its countdown on a coroutine scope owned by the caller
 * (typically a foreground Service's lifecycleScope so it survives the
 * host Activity being backgrounded, which is expected during lockdown —
 * the user's screen may be off entirely for a prayer task).
 */
class TaskTimerManager(
    private val repository: EylRepository,
    private val scope: CoroutineScope,
    context: Context
) {
    private val phoneUntouchedMonitor = PhoneUntouchedMonitor(context.applicationContext)

    sealed class TimerEvent {
        data class Tick(val secondsRemaining: Int) : TimerEvent()
        data class Completed(val task: Task, val ledger: PointsLedger) : TimerEvent()
        data class Failed(val task: Task, val reason: String) : TimerEvent()
    }

    private var tickerJob: Job? = null
    private var currentTaskId: String? = null

    /**
     * Starts a task's timer and engages lockdown. onEvent is called for
     * every tick plus the terminal Completed/Failed event.
     */
    fun start(task: Task, onEvent: (TimerEvent) -> Unit) {
        // Only one task can run at a time — lockdown is exclusive by nature.
        if (currentTaskId != null) {
            onEvent(TimerEvent.Failed(task, "Another task is already running"))
            return
        }
        currentTaskId = task.id

        engageLockdown(task)

        tickerJob = scope.launch {
            val totalSeconds = task.durationMinutes * 60
            var remaining = totalSeconds
            var broken = false
            var breakReason = "Lockdown was broken before the timer completed"

            // Wire the accessibility service's interrupt callback to mark
            // this run as broken if enforcement genuinely stops.
            LockdownAccessibilityService.instance?.onLockdownBrokenCallback = {
                broken = true
            }

            // For prayer/adhkar/tahajud (LockdownMode.NONE), the check is
            // the opposite of app-blocking — any screen-on/unlock event
            // fails it. If the phone is ALREADY on/unlocked the moment the
            // task starts, that's an immediate failure rather than a
            // countdown that starts on a false premise.
            if (task.lockdownMode == LockdownMode.NONE) {
                val alreadyOn = phoneUntouchedMonitor.start {
                    broken = true
                    breakReason = "Phone was touched during the task — it should stay untouched"
                }
                if (alreadyOn) {
                    broken = true
                    breakReason = "Phone was already on/unlocked — put it down before starting this task"
                }
            }

            while (remaining > 0 && !broken) {
                onEvent(TimerEvent.Tick(remaining))
                delay(1000)
                remaining--
            }

            releaseLockdown()

            val finished = repository.getTask(task.id) ?: task
            if (broken) {
                val failedTask = finished.copy(status = TaskStatus.FAILED, lockdownBroken = true)
                repository.saveTask(failedTask)
                onEvent(TimerEvent.Failed(failedTask, breakReason))
            } else {
                val completedTask = finished.copy(
                    status = TaskStatus.COMPLETED,
                    completedAt = LocalTime.now()
                )
                repository.saveTask(completedTask)
                val ledger = recalculateDay(completedTask.date)
                onEvent(TimerEvent.Completed(completedTask, ledger))
            }

            currentTaskId = null
        }

        scope.launch {
            val inProgress = task.copy(status = TaskStatus.IN_PROGRESS, startedAt = LocalTime.now())
            repository.saveTask(inProgress)
        }
    }

    /**
     * Manual cancel — e.g. user force-quits, or the app itself detects an
     * unrecoverable situation. Always counts as a failure, per rule 6
     * (interruptions are meant to be auto-blocked; if the app is cancelling
     * a task on its own it means blocking already failed).
     */
    fun cancel(reason: String = "Manually cancelled") {
        val taskId = currentTaskId ?: return
        tickerJob?.cancel()
        releaseLockdown()
        scope.launch {
            repository.getTask(taskId)?.let { task ->
                repository.saveTask(task.copy(status = TaskStatus.FAILED, lockdownBroken = true))
            }
        }
        currentTaskId = null
    }

    private fun engageLockdown(task: Task) {
        val service = LockdownAccessibilityService.instance
        val lockdown = when (task.lockdownMode) {
            LockdownMode.SINGLE_APP -> LockdownAccessibilityService.ActiveLockdown(
                mode = LockdownMode.SINGLE_APP,
                allowedPackages = emptySet()
            )
            LockdownMode.WHITELIST -> LockdownAccessibilityService.ActiveLockdown(
                mode = LockdownMode.WHITELIST,
                allowedPackages = task.whitelistedPackages.toSet()
            )
            LockdownMode.NONE -> null // handled by PhoneUntouchedMonitor instead, wired in start()
        }
        // Only touch the accessibility service for modes it actually enforces.
        if (task.lockdownMode != LockdownMode.NONE) {
            service?.setActiveLockdown(lockdown) // if service is null (not enabled yet), UI should have already prompted the user before allowing task start
        }
    }

    private fun releaseLockdown() {
        LockdownAccessibilityService.instance?.let {
            it.setActiveLockdown(null)
            it.onLockdownBrokenCallback = null
        }
        phoneUntouchedMonitor.stop()
    }

    private suspend fun recalculateDay(date: LocalDate): PointsLedger {
        val mustTasks = repository.getMustTasksForDate(date)
        val optionalTasks = repository.getOptionalTasksForDate(date)
        val wakeUpState = repository.getWakeUpState(date)
        val ledger = PointsEngine.calculateDay(date, mustTasks, optionalTasks, wakeUpState)
        repository.saveLedger(ledger)
        return ledger
    }
}
