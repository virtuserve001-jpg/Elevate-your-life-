package com.eyl.app.data

import com.eyl.app.data.db.EylDatabase
import com.eyl.app.data.model.*
import java.time.LocalDate

/**
 * Thin wrapper over the DAOs. Exists so TaskTimerManager / UI ViewModels
 * don't reach into EylDatabase directly, and so we have one place to add
 * caching later if the low-end target device needs it.
 */
class EylRepository(private val db: EylDatabase) {

    // --- Tasks ---
    suspend fun getTask(id: String): Task? = db.taskDao().getById(id)

    suspend fun getMustTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.MUST)

    suspend fun getOptionalTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.OPTIONAL)

    fun observeTasksForDate(date: LocalDate) = db.taskDao().observeTasksForDate(date)

    suspend fun saveTask(task: Task) = db.taskDao().upsert(task)

    /**
     * Generates the day's MUST tasks from MustTaskType if they don't
     * already exist. Idempotent — safe to call on every app open.
     */
    suspend fun ensureMustTasksExist(date: LocalDate) {
        val existing = getMustTasksForDate(date)
        val existingTypes = existing.mapNotNull { it.mustTaskType }.toSet()

        val toCreate = MustTaskType.values()
            .filter { it !in existingTypes }
            .map { type ->
                Task(
                    id = "${date}_${type.name}",
                    date = date,
                    category = TaskCategory.MUST,
                    title = type.name.lowercase().replace('_', ' '),
                    mustTaskType = type,
                    durationMinutes = type.durationMinutesFor(date),
                    // Prayers/adhkar/tahajud: phone-untouched, not app-blocking.
                    // The 2hr read is the one MUST task that's app-lockdown-based.
                    lockdownMode = if (type == MustTaskType.READ_TWO_HOURS)
                        LockdownMode.SINGLE_APP else LockdownMode.NONE
                )
            }

        if (toCreate.isNotEmpty()) db.taskDao().upsertAll(toCreate)
    }

    // --- Points / wake-up / spend ---
    suspend fun getLedger(date: LocalDate): PointsLedger? = db.pointsLedgerDao().getForDate(date)
    suspend fun saveLedger(ledger: PointsLedger) = db.pointsLedgerDao().upsert(ledger)

    suspend fun getWakeUpState(date: LocalDate): WakeUpGameState? = db.wakeUpGameStateDao().getForDate(date)
    suspend fun saveWakeUpState(state: WakeUpGameState) = db.wakeUpGameStateDao().upsert(state)

    suspend fun getSpendAllocation(date: LocalDate): SpendAllocation? = db.spendAllocationDao().getForDate(date)
    suspend fun saveSpendAllocation(allocation: SpendAllocation) = db.spendAllocationDao().upsert(allocation)

    /**
     * Points spendable on `date` come from the PREVIOUS day's finalized
     * ledger — you're spending what you earned yesterday, not today's
     * still-in-progress total (which wouldn't be final until midnight
     * anyway, per the gatekeeper rule potentially zeroing it retroactively).
     */
    suspend fun getSpendablePoints(date: LocalDate): Int =
        getLedger(date.minusDays(1))?.finalPoints ?: 0
}
