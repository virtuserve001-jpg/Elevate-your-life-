package com.eyl.app.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GuardianPinHasherTest {

    @Test
    fun `correct pin verifies successfully`() {
        val salt = GuardianPinHasher.generateSalt()
        val hash = GuardianPinHasher.hash("1234", salt)
        assertTrue(GuardianPinHasher.verify("1234", salt, hash))
    }

    @Test
    fun `wrong pin is rejected`() {
        val salt = GuardianPinHasher.generateSalt()
        val hash = GuardianPinHasher.hash("1234", salt)
        assertFalse(GuardianPinHasher.verify("4321", salt, hash))
    }

    @Test
    fun `same pin with different salt produces different hashes`() {
        val saltA = GuardianPinHasher.generateSalt()
        val saltB = GuardianPinHasher.generateSalt()
        val hashA = GuardianPinHasher.hash("1234", saltA)
        val hashB = GuardianPinHasher.hash("1234", saltB)
        assertNotEquals(hashA, hashB)
    }

    @Test
    fun `hash never contains the raw pin as a substring`() {
        val salt = GuardianPinHasher.generateSalt()
        val hash = GuardianPinHasher.hash("1234", salt)
        assertFalse(hash.contains("1234"))
    }

    @Test
    fun `a one-character difference produces a completely different hash`() {
        val salt = GuardianPinHasher.generateSalt()
        val hashA = GuardianPinHasher.hash("1234", salt)
        val hashB = GuardianPinHasher.hash("1235", salt)
        assertNotEquals(hashA, hashB)
    }
}
