package com.eyl.app.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ProgramEngineTest {

    private val start = LocalDate.of(2026, 1, 1)

    @Test
    fun `never set means always active`() {
        assertTrue(ProgramEngine.isActive(null, 0, LocalDate.of(2026, 6, 1)))
    }

    @Test
    fun `day 1, the start date itself, is active`() {
        assertTrue(ProgramEngine.isActive(start, 15, start))
    }

    @Test
    fun `day 15 of a 15-day program is still active`() {
        assertTrue(ProgramEngine.isActive(start, 15, start.plusDays(14)))
    }

    @Test
    fun `day 16 of a 15-day program is no longer active`() {
        assertFalse(ProgramEngine.isActive(start, 15, start.plusDays(15)))
    }

    @Test
    fun `day 17 of a 15-day program is also no longer active`() {
        assertFalse(ProgramEngine.isActive(start, 15, start.plusDays(16)))
    }

    @Test
    fun `guardian extending the duration keeps the same start date active longer`() {
        // Day 16 would have ended a 15-day program, but an extension to
        // 20 days (same start date) keeps it active.
        assertTrue(ProgramEngine.isActive(start, 20, start.plusDays(15)))
    }

    @Test
    fun `days remaining counts down correctly and hits zero right at the boundary`() {
        assertEquals(15, ProgramEngine.daysRemaining(start, 15, start))
        assertEquals(1, ProgramEngine.daysRemaining(start, 15, start.plusDays(14)))
        assertEquals(0, ProgramEngine.daysRemaining(start, 15, start.plusDays(15)))
    }
}
