package com.eyl.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.eyl.app.service.TaskAlarmReceiver
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Schedules a simple alarm for an individual task's scheduledTime.
 * Deliberately separate from AlarmScheduler (the standalone wake-up
 * alarm with its escalating anti-snooze game) — a task alarm just rings
 * and dismisses normally, or taps through to start the task. Only ever
 * one wake-up alarm exists at a time; task alarms are keyed per-task, so
 * many can coexist without colliding with each other or with it.
 *
 * Uses setAlarmClock() for the same reliability reason as the wake-up
 * alarm — it's the one API that reliably survives Doze mode and
 * aggressive Android Go battery management.
 */
object TaskAlarmScheduler {

    /** Derives a stable, distinct request code per task so alarms don't collide. */
    private fun requestCodeFor(taskId: String): Int = taskId.hashCode()

    fun scheduleTaskAlarm(context: Context, taskId: String, date: LocalDate, alarmTime: LocalTime) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val target = LocalDateTime.of(date, alarmTime)

        // Don't schedule something already in the past (e.g. editing a
        // task after its alarm time already passed today).
        if (target.isBefore(LocalDateTime.now())) return

        val triggerAtMillis = target.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val requestCode = requestCodeFor(taskId)

        val intent = Intent(context, TaskAlarmReceiver::class.java).apply {
            putExtra(TaskAlarmReceiver.EXTRA_TASK_ID, taskId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getActivity(
            context, requestCode,
            Intent(context, com.eyl.app.ui.MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setAlarmClock(
            AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent),
            pendingIntent
        )
    }

    fun cancelTaskAlarm(context: Context, taskId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TaskAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCodeFor(taskId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
