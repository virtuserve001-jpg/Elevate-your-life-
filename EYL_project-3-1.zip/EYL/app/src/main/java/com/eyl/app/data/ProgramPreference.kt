package com.eyl.app.data

import android.content.Context
import java.time.LocalDate

/**
 * Stores the timed program's start date and duration. See ProgramEngine
 * for the actual active/inactive logic — this is intentionally just
 * Android plumbing around it, same split as GuardianPreference/
 * GuardianPinHasher.
 */
object ProgramPreference {
    private const val PREFS_NAME = "eyl_prefs"
    private const val KEY_START_DATE = "program_start_date"
    private const val KEY_DURATION_DAYS = "program_duration_days"

    fun getStartDate(context: Context): LocalDate? {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_START_DATE, null) ?: return null
        return LocalDate.parse(raw)
    }

    fun getDurationDays(context: Context): Int =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_DURATION_DAYS, 0)

    /** Starts a fresh program from today — also how a user restarts one after a previous program ended. */
    fun startProgram(context: Context, durationDays: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_START_DATE, LocalDate.now().toString())
            .putInt(KEY_DURATION_DAYS, durationDays)
            .apply()
    }

    /**
     * Guardian extends the current program by setting a new total
     * duration (keeping the original start date) — independent of
     * whatever timer the child sees, a guardian's authority isn't meant
     * to expire on the same clock as the child's own restriction window.
     * If no program was ever started, this starts one from today instead.
     */
    fun extendProgram(context: Context, newDurationDays: Int) {
        val existingStart = getStartDate(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        if (existingStart == null) {
            prefs.putString(KEY_START_DATE, LocalDate.now().toString())
        }
        prefs.putInt(KEY_DURATION_DAYS, newDurationDays)
        prefs.apply()
    }

    fun clearProgram(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_START_DATE)
            .remove(KEY_DURATION_DAYS)
            .apply()
    }
}
