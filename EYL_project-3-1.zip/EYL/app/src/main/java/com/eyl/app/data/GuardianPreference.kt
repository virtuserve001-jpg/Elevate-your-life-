package com.eyl.app.data

import android.content.Context
import android.util.Base64
import com.eyl.app.engine.GuardianPinHasher

/**
 * Stores the guardian PIN as a salted hash, never in plain text. See
 * GuardianPinHasher for the actual hashing logic and its stated threat
 * model — this class is intentionally just Android plumbing around it.
 */
object GuardianPreference {
    private const val PREFS_NAME = "eyl_prefs"
    private const val KEY_SALT = "guardian_pin_salt"
    private const val KEY_HASH = "guardian_pin_hash"
    private const val KEY_MODE_ENABLED = "guardian_mode_enabled"

    fun isPinSet(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.contains(KEY_HASH) && prefs.contains(KEY_SALT)
    }

    fun setPin(context: Context, rawPin: String) {
        val salt = GuardianPinHasher.generateSalt()
        val hash = GuardianPinHasher.hash(rawPin, salt)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, hash)
            .putBoolean(KEY_MODE_ENABLED, true)
            .apply()
    }

    fun verifyPin(context: Context, rawPin: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saltStr = prefs.getString(KEY_SALT, null) ?: return false
        val expectedHash = prefs.getString(KEY_HASH, null) ?: return false
        val salt = Base64.decode(saltStr, Base64.NO_WRAP)
        return GuardianPinHasher.verify(rawPin, salt, expectedHash)
    }

    /** Whether Guardian-Self mode has ever been set up on this device. */
    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_MODE_ENABLED, false)

    fun clearPin(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_SALT)
            .remove(KEY_HASH)
            .putBoolean(KEY_MODE_ENABLED, false)
            .apply()
    }
}
