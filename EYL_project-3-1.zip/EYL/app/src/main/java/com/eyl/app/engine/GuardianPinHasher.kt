package com.eyl.app.engine

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Pure PIN hashing/verification logic, deliberately separated from
 * Android's SharedPreferences storage (see GuardianPreference) so it can
 * be unit-tested without needing Robolectric or a Context — same reason
 * PointsEngine and WakeUpGameEngine stay framework-free.
 *
 * THREAT MODEL, stated honestly: this defends against a curious child
 * poking around app files/prefs and finding the PIN sitting in plain
 * text — a salted SHA-256 hash means there's nothing readable to find.
 * It is NOT designed to withstand a serious offline brute-force attack;
 * a 4-6 digit PIN has a small enough keyspace that no salted hash alone
 * stops that on its own. The actual protection against brute-forcing is
 * meant to live in the UI layer (rate-limiting entry attempts), not here.
 */
object GuardianPinHasher {

    fun generateSalt(): ByteArray {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return salt
    }

    fun hash(pin: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        val hashBytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun verify(pin: String, salt: ByteArray, expectedHash: String): Boolean {
        return hash(pin, salt) == expectedHash
    }
}
