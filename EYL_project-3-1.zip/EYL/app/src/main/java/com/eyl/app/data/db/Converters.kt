package com.eyl.app.data.db

import androidx.room.TypeConverter
import com.eyl.app.data.model.*
import java.time.LocalDate
import java.time.LocalTime

class Converters {

    @TypeConverter
    fun fromLocalDate(date: LocalDate?): String? = date?.toString()

    @TypeConverter
    fun toLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }

    @TypeConverter
    fun fromLocalTime(time: LocalTime?): String? = time?.toString()

    @TypeConverter
    fun toLocalTime(value: String?): LocalTime? = value?.let { LocalTime.parse(it) }

    @TypeConverter
    fun fromTaskCategory(value: TaskCategory?): String? = value?.name

    @TypeConverter
    fun toTaskCategory(value: String?): TaskCategory? = value?.let { TaskCategory.valueOf(it) }

    @TypeConverter
    fun fromTaskSource(value: TaskSource): String = value.name

    @TypeConverter
    fun toTaskSource(value: String): TaskSource = TaskSource.valueOf(value)

    @TypeConverter
    fun fromImportanceTier(value: ImportanceTier?): String? = value?.name

    @TypeConverter
    fun toImportanceTier(value: String?): ImportanceTier? = value?.let { ImportanceTier.valueOf(it) }

    @TypeConverter
    fun fromLockdownMode(value: LockdownMode): String = value.name

    @TypeConverter
    fun toLockdownMode(value: String): LockdownMode = LockdownMode.valueOf(value)

    @TypeConverter
    fun fromTaskStatus(value: TaskStatus): String = value.name

    @TypeConverter
    fun toTaskStatus(value: String): TaskStatus = TaskStatus.valueOf(value)

    // Single converter for all List<String> fields (whitelisted packages,
    // ledger breakdown text, etc). Room disambiguates TypeConverters by
    // type signature, not by name — so we can only have ONE converter
    // per (List<String> -> String) pair in this class. Pipe-delimiter is
    // safe for both package names (never contain it) and breakdown text
    // (free-form but this sequence is unlikely to appear naturally).
    private val listDelimiter = "|~|"

    @TypeConverter
    fun fromStringList(value: List<String>): String = value.joinToString(listDelimiter)

    @TypeConverter
    fun toStringList(value: String): List<String> =
        if (value.isBlank()) emptyList() else value.split(listDelimiter)
}
