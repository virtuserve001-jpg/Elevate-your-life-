package com.eyl.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.LockdownMode
import com.eyl.app.engine.TaskTimerManager
import com.eyl.app.service.LockdownForegroundService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Three jobs in one Activity:
 * 1. Normal path: shown right after the user taps "Start" on a task —
 *    displays the live countdown by observing the foreground service's
 *    eventFlow.
 * 2. Bounce-back path: LockdownAccessibilityService relaunches this
 *    Activity (with FLAG_ACTIVITY_CLEAR_TOP) whenever it catches a
 *    disallowed app trying to come to the foreground during an active
 *    lockdown — so from the user's perspective, trying to escape just
 *    snaps them right back here instead of ever seeing the other app.
 * 3. Direct launch: for a WHITELIST task, shows a button per allowed app
 *    so the user can jump straight to it — instead of leaving through
 *    the home screen/recents and finding their way there manually.
 */
class TaskLockdownActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
    }

    private val app get() = application as EylApplication

    private lateinit var textCountdown: TextView
    private lateinit var textTitle: TextView
    private lateinit var textMessage: TextView
    private lateinit var containerWhitelistApps: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_lockdown)
        textCountdown = findViewById(R.id.textCountdown)
        textTitle = findViewById(R.id.textLockdownTitle)
        textMessage = findViewById(R.id.textLockdownMessage)
        containerWhitelistApps = findViewById(R.id.containerWhitelistApps)

        handleIntent(intent)
        observeEvents()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val blockedAttempt = intent?.getStringExtra("blocked_package_attempted")
        if (blockedAttempt != null) {
            textMessage.text = "That app is off-limits until this task's timer finishes."
        }

        val taskId = intent?.getStringExtra(EXTRA_TASK_ID) ?: return
        lifecycleScope.launch {
            val task = app.repository.getTask(taskId) ?: return@launch
            textTitle.text = task.title
            if (task.lockdownMode == LockdownMode.WHITELIST) {
                populateWhitelistButtons(task.whitelistedPackages)
            } else {
                containerWhitelistApps.removeAllViews()
            }
        }
    }

    private fun populateWhitelistButtons(packages: List<String>) {
        containerWhitelistApps.removeAllViews()
        val pm = packageManager
        packages.forEach { packageName ->
            // A whitelisted app could have been uninstalled since the task
            // was set up — skip it rather than offer a button that'd crash.
            val appInfo = try {
                pm.getApplicationInfo(packageName, 0)
            } catch (e: android.content.pm.PackageManager.NameNotFoundException) {
                null
            } ?: return@forEach

            val label = pm.getApplicationLabel(appInfo).toString()
            val realButton = Button(this).apply {
                text = "Open $label"
                setOnClickListener {
                    pm.getLaunchIntentForPackage(packageName)?.let { launchIntent ->
                        startActivity(launchIntent)
                    }
                }
            }
            containerWhitelistApps.addView(realButton)
        }
    }

    private fun playCompletionAnimation() {
        textCountdown.apply {
            scaleX = 0.3f
            scaleY = 0.3f
            alpha = 0f
            animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(400)
                .setInterpolator(android.view.animation.OvershootInterpolator(2f))
                .start()
        }
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            // The service instance may not exist yet on the very first
            // frame (race with startForegroundService); poll briefly.
            var service = LockdownForegroundService.instance
            var attempts = 0
            while (service == null && attempts < 20) {
                kotlinx.coroutines.delay(50)
                service = LockdownForegroundService.instance
                attempts++
            }
            service?.eventFlow?.collectLatest { event ->
                when (event) {
                    is TaskTimerManager.TimerEvent.Tick -> {
                        val m = event.secondsRemaining / 60
                        val s = event.secondsRemaining % 60
                        textCountdown.text = String.format("%02d:%02d", m, s)
                    }
                    is TaskTimerManager.TimerEvent.Completed -> {
                        textTitle.text = "Task complete"
                        textCountdown.text = "✅"
                        textMessage.text = "Nicely done. You can leave this screen now."
                        containerWhitelistApps.removeAllViews()
                        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
                        playCompletionAnimation()
                    }
                    is TaskTimerManager.TimerEvent.Failed -> {
                        textTitle.text = "Task failed"
                        textCountdown.text = "❌"
                        textMessage.text = event.reason
                        containerWhitelistApps.removeAllViews()
                        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.REJECT)
                    }
                    null -> {}
                }
            }
        }
    }
}
