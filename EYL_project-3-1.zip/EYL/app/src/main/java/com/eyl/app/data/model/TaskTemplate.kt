package com.eyl.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalTime

/**
 * A reusable task blueprint. The single source for BOTH optional and
 * must-tasks:
 *
 * - OPTIONAL templates: saved once from an existing task, then
 *   instantiated into a new Task for "today" whenever the user picks it.
 * - MUST templates: instantiated automatically every day by
 *   EylRepository.ensureMustTasksExist, for as long as isActive stays
 *   true. This replaces the old hardcoded MustTaskType enum — must-tasks
 *   are now just templates like any other, not a fixed built-in list.
 */
@Entity(tableName = "task_templates")
data class TaskTemplate(
    @PrimaryKey val id: String,
    val title: String,
    val category: TaskCategory,
    // Only meaningful for OPTIONAL templates — must-tasks carry no tier,
    // every must-task is equally required.
    val tier: ImportanceTier? = null,
    val durationMinutes: Int,
    val lockdownMode: LockdownMode,
    val whitelistedPackages: List<String> = emptyList(),
    // Lets a MUST template be "retired" without deleting its history —
    // ensureMustTasksExist skips inactive templates when generating today.
    val isActive: Boolean = true,
    val createdBy: TaskSource = TaskSource.SELF,
    // Propagated to each day's generated Task instance — see Task.scheduledTime.
    val scheduledTime: LocalTime? = null
)
