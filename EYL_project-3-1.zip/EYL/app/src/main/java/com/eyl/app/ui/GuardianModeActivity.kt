package com.eyl.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.GuardianPreference
import com.eyl.app.data.model.LockdownMode
import com.eyl.app.data.model.TaskCategory
import com.eyl.app.data.model.TaskSource
import com.eyl.app.data.model.TaskTemplate
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

/**
 * PIN-gated screen for managing guardian-assigned must-do tasks. Three
 * states, toggled by view visibility rather than separate activities,
 * since the flow between them is simple and linear:
 *
 * - No PIN set yet -> first-time setup (choose + confirm a PIN)
 * - PIN set, not yet entered this visit -> PIN entry
 * - Unlocked -> manage guardian tasks (add / edit / delete)
 *
 * Guardian tasks are TaskTemplate rows with category = MUST and
 * createdBy = GUARDIAN. The child's own self-created tasks are untouched
 * by anything in this screen — they stay OPTIONAL, editable by the child,
 * and don't require this PIN at all.
 */
class GuardianModeActivity : AppCompatActivity() {

    private val app get() = application as EylApplication
    private val today: LocalDate get() = LocalDate.now()

    private lateinit var layoutPinSetup: LinearLayout
    private lateinit var layoutPinEntry: LinearLayout
    private lateinit var layoutTemplateManager: LinearLayout
    private lateinit var containerGuardianTasks: LinearLayout

    private var appPickerCallback: ((List<String>) -> Unit)? = null
    private val appPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val chosen = result.data
                ?.getStringArrayExtra(AppPickerActivity.EXTRA_SELECTED_PACKAGES)
                ?.toList() ?: emptyList()
            appPickerCallback?.invoke(chosen)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guardian_mode)

        layoutPinSetup = findViewById(R.id.layoutPinSetup)
        layoutPinEntry = findViewById(R.id.layoutPinEntry)
        layoutTemplateManager = findViewById(R.id.layoutTemplateManager)
        containerGuardianTasks = findViewById(R.id.containerGuardianTasks)

        setupPinSetupFlow()
        setupPinEntryFlow()

        findViewById<Button>(R.id.buttonAddGuardianTask).setOnClickListener {
            showGuardianTaskDialog(existing = null)
        }
        findViewById<Button>(R.id.buttonLockGuardianMode).setOnClickListener { finish() }
        findViewById<Button>(R.id.buttonExtendProgram).setOnClickListener {
            val editDays = findViewById<EditText>(R.id.editGuardianProgramDays)
            val newDuration = editDays.text.toString().toIntOrNull()
            if (newDuration == null || newDuration <= 0) {
                android.widget.Toast.makeText(this, "Enter a number of days greater than 0", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            com.eyl.app.data.ProgramPreference.extendProgram(this, newDuration)
            editDays.text.clear()
            refreshProgramStatus()
        }

        if (!GuardianPreference.isPinSet(this)) {
            layoutPinSetup.visibility = View.VISIBLE
        } else {
            layoutPinEntry.visibility = View.VISIBLE
        }
    }

    private fun setupPinSetupFlow() {
        val editNewPin = findViewById<EditText>(R.id.editNewPin)
        val editConfirmPin = findViewById<EditText>(R.id.editConfirmPin)
        val textError = findViewById<TextView>(R.id.textPinSetupError)

        findViewById<Button>(R.id.buttonSetPin).setOnClickListener {
            val pin = editNewPin.text.toString()
            val confirm = editConfirmPin.text.toString()
            when {
                pin.length < 4 -> {
                    textError.text = "PIN must be at least 4 digits"
                    textError.visibility = View.VISIBLE
                }
                pin != confirm -> {
                    textError.text = "PINs don't match"
                    textError.visibility = View.VISIBLE
                }
                else -> {
                    GuardianPreference.setPin(this, pin)
                    textError.visibility = View.GONE
                    showUnlockedState()
                }
            }
        }
    }

    private fun setupPinEntryFlow() {
        val editPinEntry = findViewById<EditText>(R.id.editPinEntry)
        val textError = findViewById<TextView>(R.id.textPinEntryError)

        findViewById<Button>(R.id.buttonUnlock).setOnClickListener {
            val pin = editPinEntry.text.toString()
            if (GuardianPreference.verifyPin(this, pin)) {
                textError.visibility = View.GONE
                editPinEntry.text.clear()
                showUnlockedState()
            } else {
                textError.text = "Wrong PIN"
                textError.visibility = View.VISIBLE
            }
        }
    }

    private fun showUnlockedState() {
        layoutPinSetup.visibility = View.GONE
        layoutPinEntry.visibility = View.GONE
        layoutTemplateManager.visibility = View.VISIBLE
        refreshGuardianTasks()
        refreshProgramStatus()
    }

    private fun refreshProgramStatus() {
        val textStatus = findViewById<TextView>(R.id.textGuardianProgramStatus)
        val start = com.eyl.app.data.ProgramPreference.getStartDate(this)
        if (start == null) {
            textStatus.text = "No program running on this device yet."
            return
        }
        val duration = com.eyl.app.data.ProgramPreference.getDurationDays(this)
        val active = com.eyl.app.engine.ProgramEngine.isActive(start, duration, today)
        textStatus.text = if (active) {
            val remaining = com.eyl.app.engine.ProgramEngine.daysRemaining(start, duration, today)
            "Active — $remaining day(s) left. Extending below keeps the same start date, just pushes the end further out."
        } else {
            "Program ended. Extending below restarts enforcement using the original start date."
        }
    }

    private fun refreshGuardianTasks() {
        lifecycleScope.launch {
            val templates = app.repository.getGuardianTemplates()
            containerGuardianTasks.removeAllViews()

            if (templates.isEmpty()) {
                val empty = TextView(this@GuardianModeActivity).apply {
                    text = "No guardian tasks yet — add one below."
                    setTextColor(0xFF888888.toInt())
                }
                containerGuardianTasks.addView(empty)
                return@launch
            }

            templates.forEach { template ->
                val row = LayoutInflater.from(this@GuardianModeActivity)
                    .inflate(R.layout.item_guardian_task, containerGuardianTasks, false)
                row.findViewById<TextView>(R.id.textGuardianTaskTitle).text = template.title
                row.findViewById<TextView>(R.id.textGuardianTaskMeta).text =
                    "${template.durationMinutes} min · ${template.lockdownMode.name}"

                row.findViewById<Button>(R.id.buttonEditGuardianTask).setOnClickListener {
                    showGuardianTaskDialog(existing = template)
                }
                row.findViewById<Button>(R.id.buttonDeleteGuardianTask).setOnClickListener {
                    AlertDialog.Builder(this@GuardianModeActivity)
                        .setTitle("Delete this task?")
                        .setMessage("\"${template.title}\" will be removed for today and every day going forward.")
                        .setPositiveButton("Delete") { _, _ ->
                            lifecycleScope.launch {
                                app.repository.deleteMustTemplate(template, today)
                                refreshGuardianTasks()
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
                containerGuardianTasks.addView(row)
            }
        }
    }

    private fun showGuardianTaskDialog(existing: TaskTemplate?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null)
        val editTitle = dialogView.findViewById<EditText>(R.id.editTaskTitle)
        val editDuration = dialogView.findViewById<EditText>(R.id.editTaskDuration)
        val textImportanceLabel = dialogView.findViewById<TextView>(R.id.textImportanceLabel)
        val radioGroupTier = dialogView.findViewById<RadioGroup>(R.id.radioGroupTier)
        val checkSaveAsTemplate = dialogView.findViewById<CheckBox>(R.id.checkSaveAsTemplate)
        val radioLockdown = dialogView.findViewById<RadioGroup>(R.id.radioGroupLockdown)
        val buttonChooseApps = dialogView.findViewById<Button>(R.id.buttonChooseApps)
        val textChosenSummary = dialogView.findViewById<TextView>(R.id.textChosenAppsSummary)
        val textAlarmTimeSummary = dialogView.findViewById<TextView>(R.id.textAlarmTimeSummary)
        val buttonSetAlarmTime = dialogView.findViewById<Button>(R.id.buttonSetAlarmTime)
        val buttonClearAlarmTime = dialogView.findViewById<Button>(R.id.buttonClearAlarmTime)

        // Tier and "save as template" don't apply here — every must-task
        // is equally required (no tier), and guardian tasks are always
        // templates by definition, there's no separate "save" step.
        textImportanceLabel.visibility = View.GONE
        radioGroupTier.visibility = View.GONE
        checkSaveAsTemplate.visibility = View.GONE

        var chosenPackages = existing?.whitelistedPackages ?: emptyList()
        var chosenAlarmTime: java.time.LocalTime? = existing?.scheduledTime

        fun updateAlarmUi() {
            textAlarmTimeSummary.text = chosenAlarmTime?.let {
                "Alarm at ${it.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))}"
            } ?: "No alarm set"
        }
        updateAlarmUi()

        buttonSetAlarmTime.setOnClickListener {
            val initial = chosenAlarmTime ?: java.time.LocalTime.now()
            android.app.TimePickerDialog(
                this,
                { _, hour, minute ->
                    chosenAlarmTime = java.time.LocalTime.of(hour, minute)
                    updateAlarmUi()
                },
                initial.hour, initial.minute, false
            ).show()
        }
        buttonClearAlarmTime.setOnClickListener {
            chosenAlarmTime = null
            updateAlarmUi()
        }

        fun updateAppsUi(mode: LockdownMode) {
            val show = mode == LockdownMode.WHITELIST
            buttonChooseApps.visibility = if (show) View.VISIBLE else View.GONE
            textChosenSummary.visibility = if (show) View.VISIBLE else View.GONE
            textChosenSummary.text = if (chosenPackages.isEmpty())
                "No apps chosen yet" else "${chosenPackages.size} app(s) chosen"
        }

        existing?.let { template ->
            editTitle.setText(template.title)
            editDuration.setText(template.durationMinutes.toString())
            radioLockdown.check(
                when (template.lockdownMode) {
                    LockdownMode.WHITELIST -> R.id.radioLockdownWhitelist
                    LockdownMode.SINGLE_APP -> R.id.radioLockdownSingleApp
                    LockdownMode.NONE -> R.id.radioLockdownNone
                }
            )
        }
        updateAppsUi(existing?.lockdownMode ?: LockdownMode.NONE)

        radioLockdown.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioLockdownWhitelist -> LockdownMode.WHITELIST
                R.id.radioLockdownSingleApp -> LockdownMode.SINGLE_APP
                else -> LockdownMode.NONE
            }
            updateAppsUi(mode)
        }

        buttonChooseApps.setOnClickListener {
            appPickerCallback = { chosen ->
                chosenPackages = chosen
                textChosenSummary.text = if (chosen.isEmpty()) "No apps chosen yet" else "${chosen.size} app(s) chosen"
            }
            val intent = Intent(this, AppPickerActivity::class.java)
                .putExtra(AppPickerActivity.EXTRA_PRESELECTED_PACKAGES, chosenPackages.toTypedArray())
            appPickerLauncher.launch(intent)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "New must-do task" else "Edit must-do task")
            .setView(dialogView)
            .setPositiveButton(if (existing == null) "Add" else "Save") { _, _ ->
                val title = editTitle.text.toString().trim()
                val duration = editDuration.text.toString().toIntOrNull() ?: 15
                if (title.isEmpty()) return@setPositiveButton

                val lockdownMode = when (radioLockdown.checkedRadioButtonId) {
                    R.id.radioLockdownWhitelist -> LockdownMode.WHITELIST
                    R.id.radioLockdownSingleApp -> LockdownMode.SINGLE_APP
                    else -> LockdownMode.NONE
                }
                val whitelist = if (lockdownMode == LockdownMode.WHITELIST) chosenPackages else emptyList()

                val template = TaskTemplate(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    title = title,
                    category = TaskCategory.MUST,
                    tier = null,
                    durationMinutes = duration,
                    lockdownMode = lockdownMode,
                    whitelistedPackages = whitelist,
                    isActive = true,
                    createdBy = TaskSource.GUARDIAN,
                    scheduledTime = chosenAlarmTime
                )

                lifecycleScope.launch {
                    app.repository.saveMustTemplate(template, today)
                    refreshGuardianTasks()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
