package com.eyl.app.data

import android.content.Context
import com.eyl.app.data.db.EylDatabase
import com.eyl.app.data.model.*
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/**
 * Thin wrapper over the DAOs. Exists so TaskTimerManager / UI ViewModels
 * don't reach into EylDatabase directly, and so we have one place to add
 * caching later if the low-end target device needs it.
 */
class EylRepository(private val context: Context, private val db: EylDatabase) {

    // --- Tasks ---
    suspend fun getTask(id: String): Task? = db.taskDao().getById(id)

    suspend fun getMustTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.MUST)

    suspend fun getOptionalTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.OPTIONAL)

    fun observeTasksForDate(date: LocalDate) = db.taskDao().observeTasksForDate(date)

    suspend fun saveTask(task: Task) = db.taskDao().upsert(task)

    /**
     * Generates today's MUST tasks from any active MUST-category
     * templates that don't already have a task for this date. Idempotent,
     * safe to call on every app open.
     *
     * Milestone 4 (generalization): must-tasks are no longer a fixed
     * built-in list. They're TaskTemplates marked category == MUST, the
     * same template system optional tasks already use — so EYL works for
     * any kind of daily discipline, not one specific built-in set. A
     * template's own lockdownMode/whitelistedPackages fully replace the
     * old hardcoded "reading app" special case; any must-template can
     * carry its own whitelist directly, editable like any other template.
     *
     * A fresh install has zero must-task templates until the user creates
     * one (mark a task "Must-do" + "Save as template" in the add-task
     * dialog) — with nothing yet defined, this simply generates nothing,
     * same effect as Guardian-Self mode's "no tasks set" case.
     */
    suspend fun ensureMustTasksExist(date: LocalDate) {
        val existingTemplateIds = getMustTasksForDate(date).mapNotNull { it.templateId }.toSet()
        val mustTemplates = getTemplates().filter { it.category == TaskCategory.MUST && it.isActive }

        val toCreate = mustTemplates
            .filter { it.id !in existingTemplateIds }
            .map { template ->
                Task(
                    id = "${date}_${template.id}",
                    date = date,
                    category = TaskCategory.MUST,
                    title = template.title,
                    templateId = template.id,
                    durationMinutes = template.durationMinutes,
                    lockdownMode = template.lockdownMode,
                    whitelistedPackages = template.whitelistedPackages,
                    createdBy = template.createdBy,
                    scheduledTime = template.scheduledTime
                )
            }

        if (toCreate.isNotEmpty()) {
            db.taskDao().upsertAll(toCreate)
            // Templates with a scheduledTime need their alarm actually
            // (re)scheduled each day they're generated — ensureMustTasksExist
            // runs with no UI in the loop (app open, daily rollover), so
            // nothing else would ever call TaskAlarmScheduler for these.
            toCreate.forEach { task ->
                task.scheduledTime?.let {
                    com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(context, task.id, task.date, it)
                }
            }
        }
    }

    /**
     * Milestone 3 fix: resolves any task stuck at IN_PROGRESS whose
     * scheduled end time has already passed. This happens when the
     * foreground service running the countdown gets killed by the OS
     * (common on aggressive battery-management devices) before it can
     * mark the task COMPLETED itself — without this check, such a task
     * stays "running" forever.
     *
     * Marked FAILED rather than COMPLETED: since the coroutine died,
     * there's no way to confirm lockdown stayed active for the whole
     * duration, and the app's own stated philosophy elsewhere is that an
     * interruption to enforcement counts as a failure, not a free pass.
     */
    suspend fun reconcileOrphanedTasks(date: LocalDate) {
        val tasks = getMustTasksForDate(date) + getOptionalTasksForDate(date)
        val now = java.time.LocalDateTime.now()

        tasks.filter { it.status == TaskStatus.IN_PROGRESS && it.startedAt != null }
            .forEach { task ->
                val expectedEnd = date.atTime(task.startedAt).plusMinutes(task.durationMinutes.toLong())
                if (now.isAfter(expectedEnd)) {
                    saveTask(task.copy(status = TaskStatus.FAILED, lockdownBroken = true))
                }
            }
    }

    // --- Points / wake-up / spend ---
    suspend fun getLedger(date: LocalDate): PointsLedger? = db.pointsLedgerDao().getForDate(date)
    suspend fun saveLedger(ledger: PointsLedger) = db.pointsLedgerDao().upsert(ledger)

    /** Most recent N days of ledgers, used by the Milestone 4 analytics screen. */
    suspend fun getRecentLedgers(days: Int = 30): List<PointsLedger> =
        db.pointsLedgerDao().observeRecent(days).first()

    suspend fun getWakeUpState(date: LocalDate): WakeUpGameState? = db.wakeUpGameStateDao().getForDate(date)
    suspend fun saveWakeUpState(state: WakeUpGameState) = db.wakeUpGameStateDao().upsert(state)

    suspend fun getSpendAllocation(date: LocalDate): SpendAllocation? = db.spendAllocationDao().getForDate(date)
    suspend fun saveSpendAllocation(allocation: SpendAllocation) = db.spendAllocationDao().upsert(allocation)

    /**
     * Points spendable on `date` come from the PREVIOUS day's finalized
     * ledger — you're spending what you earned yesterday, not today's
     * still-in-progress total (which wouldn't be final until midnight
     * anyway, per the gatekeeper rule potentially zeroing it retroactively).
     */
    suspend fun getSpendablePoints(date: LocalDate): Int =
        getLedger(date.minusDays(1))?.finalPoints ?: 0

    // --- Milestone 2: templates, duplication, editing ---

    fun observeTemplates() = db.taskTemplateDao().observeAll()
    suspend fun getTemplates(): List<TaskTemplate> = db.taskTemplateDao().getAll()
    suspend fun saveTemplate(template: TaskTemplate) = db.taskTemplateDao().upsert(template)
    suspend fun deleteTemplate(template: TaskTemplate) = db.taskTemplateDao().delete(template)

    // --- Guardian-Self mode ---

    suspend fun getGuardianTemplates(): List<TaskTemplate> =
        getTemplates().filter { it.createdBy == TaskSource.GUARDIAN }

    /**
     * Saves any MUST-category template (guardian-assigned OR self-created,
     * both use this now) and — since ensureMustTasksExist only ever fills
     * in tasks missing for today, it never updates ones that already
     * exist — also retroactively syncs today's already-generated instance
     * to match, if one exists and hasn't been started yet. Without this,
     * editing a must-task wouldn't take effect until tomorrow, the same
     * class of bug the reading-app whitelist had before it was fixed to
     * sync same-day too.
     *
     * If today's instance was already IN_PROGRESS or resolved
     * (COMPLETED/FAILED) when the edit happened, it's left alone rather
     * than rewritten out from under whatever state it's already in.
     */
    suspend fun saveMustTemplate(template: TaskTemplate, date: LocalDate) {
        saveTemplate(template)
        val todayTask = getMustTasksForDate(date).firstOrNull { it.templateId == template.id }
        when {
            todayTask == null -> {
                val newTask = Task(
                    id = "${date}_${template.id}",
                    date = date,
                    category = TaskCategory.MUST,
                    title = template.title,
                    templateId = template.id,
                    durationMinutes = template.durationMinutes,
                    lockdownMode = template.lockdownMode,
                    whitelistedPackages = template.whitelistedPackages,
                    createdBy = template.createdBy,
                    scheduledTime = template.scheduledTime
                )
                db.taskDao().upsert(newTask)
                template.scheduledTime?.let {
                    com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(context, newTask.id, newTask.date, it)
                }
            }
            todayTask.status == TaskStatus.PENDING -> {
                saveTask(
                    todayTask.copy(
                        title = template.title,
                        durationMinutes = template.durationMinutes,
                        lockdownMode = template.lockdownMode,
                        whitelistedPackages = template.whitelistedPackages,
                        scheduledTime = template.scheduledTime
                    )
                )
                com.eyl.app.engine.TaskAlarmScheduler.cancelTaskAlarm(context, todayTask.id)
                template.scheduledTime?.let {
                    com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(context, todayTask.id, date, it)
                }
            }
            // else: already IN_PROGRESS/COMPLETED/FAILED — leave it be.
        }
    }

    /**
     * Deletes a MUST template and, if today's instance hasn't been
     * started yet, removes it too — a deleted must-task shouldn't keep
     * sitting there gating the day. A task already IN_PROGRESS or
     * resolved is left alone, same reasoning as saveMustTemplate.
     */
    suspend fun deleteMustTemplate(template: TaskTemplate, date: LocalDate) {
        deleteTemplate(template)
        val todayTask = getMustTasksForDate(date).firstOrNull { it.templateId == template.id }
        if (todayTask != null && todayTask.status == TaskStatus.PENDING) {
            db.taskDao().deleteById(todayTask.id)
            com.eyl.app.engine.TaskAlarmScheduler.cancelTaskAlarm(context, todayTask.id)
        }
    }

    /** Instantiates a saved template into a new task for the given date,
     * in whichever category the template itself is (MUST or OPTIONAL). */
    suspend fun createTaskFromTemplate(template: TaskTemplate, date: LocalDate): Task {
        val task = Task(
            id = java.util.UUID.randomUUID().toString(),
            date = date,
            category = template.category,
            title = template.title,
            templateId = template.id,
            tier = template.tier,
            durationMinutes = template.durationMinutes,
            lockdownMode = template.lockdownMode,
            whitelistedPackages = template.whitelistedPackages,
            createdBy = template.createdBy,
            scheduledTime = template.scheduledTime
        )
        saveTask(task)
        template.scheduledTime?.let {
            com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(context, task.id, task.date, it)
        }
        return task
    }

    /** Clones an existing task as a brand-new PENDING task for today — same
     *  title/tier/duration/lockdown, fresh id and status, no completion history. */
    suspend fun duplicateTask(source: Task, date: LocalDate = source.date): Task {
        val copy = Task(
            id = java.util.UUID.randomUUID().toString(),
            date = date,
            category = TaskCategory.OPTIONAL, // duplicates are always optional-style, even if cloned from a must-task's shape
            title = source.title,
            tier = source.tier ?: ImportanceTier.LESS_IMPORTANT,
            durationMinutes = source.durationMinutes,
            lockdownMode = source.lockdownMode,
            whitelistedPackages = source.whitelistedPackages
        )
        saveTask(copy)
        return copy
    }

    // --- Milestone 4: full data export/import (local backup, not cloud sync — see BackupEngine) ---

    suspend fun getAllTasksEver(): List<Task> = db.taskDao().getAllTasks()
    suspend fun getAllLedgersEver(): List<PointsLedger> = db.pointsLedgerDao().getAll()

    /** Merges an imported backup into existing local data — each task, ledger,
     * and template is upserted individually (matching IDs get overwritten,
     * everything else stays untouched). Not destructive: nothing outside
     * the backup's own IDs gets deleted. Matches exactly what the import
     * confirmation dialog in SetupActivity tells the user will happen. */
    suspend fun restoreFromBackup(tasks: List<Task>, ledgers: List<PointsLedger>, templates: List<TaskTemplate>) {
        tasks.forEach { saveTask(it) }
        ledgers.forEach { saveLedger(it) }
        templates.forEach { saveTemplate(it) }

        // A restored task's alarm (if any) needs to actually be re-armed —
        // saveTask alone only writes the database row, it doesn't touch
        // AlarmManager. Only bother for tasks that are still pending and
        // whose alarm time hasn't already passed.
        val now = java.time.LocalDateTime.now()
        tasks.filter { it.status == TaskStatus.PENDING && it.scheduledTime != null }
            .forEach { task ->
                val target = task.date.atTime(task.scheduledTime)
                if (target.isAfter(now)) {
                    com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(context, task.id, task.date, task.scheduledTime!!)
                }
            }
    }
}
