package com.eyl.app

import android.app.Application
import com.eyl.app.data.EylRepository
import com.eyl.app.data.db.EylDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class EylApplication : Application() {

    // SupervisorJob so one failed child (e.g. a save that throws) doesn't
    // cancel the whole app-wide scope, which would kill unrelated in-flight
    // work like an active task timer.
    val applicationScope = CoroutineScope(SupervisorJob())

    lateinit var database: EylDatabase
        private set
    lateinit var repository: EylRepository
        private set

    // NOTE: there is deliberately no app-level TaskTimerManager here.
    // The single source of truth for a running task is
    // LockdownForegroundService's own TaskTimerManager instance — it owns
    // the coroutine scope that must outlive any one Activity, and it's
    // the thing actually wired to the accessibility service + phone
    // monitor. UI code talks to it via LockdownForegroundService.instance
    // and its eventFlow (see MainActivity / TaskLockdownActivity), never
    // by constructing a second one.

    override fun onCreate() {
        super.onCreate()
        database = EylDatabase.getInstance(this)
        repository = EylRepository(this, database)

        com.eyl.app.engine.DailyRolloverScheduler.scheduleDaily(this)
    }
}
