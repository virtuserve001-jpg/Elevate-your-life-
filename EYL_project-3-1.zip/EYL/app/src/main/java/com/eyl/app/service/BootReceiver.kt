package com.eyl.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.eyl.app.data.WakeUpAlarmPreference
import com.eyl.app.engine.AlarmScheduler
import com.eyl.app.engine.DailyRolloverScheduler

/**
 * WorkManager's periodic work generally survives reboots on its own, but
 * some OEM Android Go skins are known to wipe scheduled work aggressively
 * to save space/battery. Re-asserting the schedule on boot costs nothing
 * (enqueueUniquePeriodicWork with KEEP policy is a no-op if it's already
 * there) and is cheap insurance for exactly the kind of device this app
 * targets.
 *
 * The wake-up alarm is now re-armed here too, using whatever time was
 * last saved in WakeUpAlarmPreference — this was previously an open TODO
 * (the time genuinely wasn't persisted anywhere), closed as part of
 * building out per-task alarms.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DailyRolloverScheduler.scheduleDaily(context)
            WakeUpAlarmPreference.getTime(context)?.let {
                AlarmScheduler.scheduleWakeUpAlarm(context, it)
            }
        }
    }
}
