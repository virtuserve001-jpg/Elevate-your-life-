package com.eyl.app.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.*
import com.eyl.app.engine.PointsEngine
import com.eyl.app.service.LockdownAccessibilityService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

/**
 * Daily dashboard. Deliberately simple views (no RecyclerView for the task
 * lists themselves) since the task list per day is short — a ScrollView of
 * inflated rows is lighter on a low-RAM device than a RecyclerView+adapter
 * for what is, in practice, a small list. (The app picker DOES use a
 * RecyclerView, since installed-app lists can be genuinely long.)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var app: EylApplication
    private lateinit var textDate: TextView
    private lateinit var textPointsSummary: TextView
    private lateinit var textGatekeeperWarning: TextView
    private lateinit var textStreakSummary: TextView
    private lateinit var textProgramSummary: TextView
    private lateinit var textGuardianSummary: TextView
    private lateinit var containerMustTasks: LinearLayout
    private lateinit var containerOptionalTasks: LinearLayout

    private val today: LocalDate get() = LocalDate.now()

    // Holds whichever set of packages the currently-open dialog's app
    // picker last returned, since the dialog itself is a transient View
    // and can't easily own activity-result state across the picker launch.
    private var pendingChosenPackages: List<String> = emptyList()
    private var appPickerCallback: ((List<String>) -> Unit)? = null

    private val appPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val chosen = result.data
                ?.getStringArrayExtra(AppPickerActivity.EXTRA_SELECTED_PACKAGES)
                ?.toList() ?: emptyList()
            pendingChosenPackages = chosen
            appPickerCallback?.invoke(chosen)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        app = application as EylApplication

        textDate = findViewById(R.id.textDate)
        textPointsSummary = findViewById(R.id.textPointsSummary)
        textGatekeeperWarning = findViewById(R.id.textGatekeeperWarning)
        textStreakSummary = findViewById(R.id.textStreakSummary)
        textProgramSummary = findViewById(R.id.textProgramSummary)
        textGuardianSummary = findViewById(R.id.textGuardianSummary)
        findViewById<View>(R.id.blurLayerPoints).applyPremiumBlur()
        findViewById<View>(R.id.blurLayerDashboard).applyPremiumBlur()
        containerMustTasks = findViewById(R.id.containerMustTasks)
        containerOptionalTasks = findViewById(R.id.containerOptionalTasks)

        findViewById<Button>(R.id.buttonAddTask).setOnClickListener { showTaskDialog(existing = null) }
        findViewById<Button>(R.id.buttonFromTemplate).setOnClickListener { showTemplatePickerDialog() }
        findViewById<Button>(R.id.buttonSpendPoints).setOnClickListener {
            startActivity(Intent(this, SpendActivity::class.java))
        }
        findViewById<Button>(R.id.buttonSetup).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        findViewById<Button>(R.id.buttonAnalytics).setOnClickListener {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }

        textDate.text = today.toString()

        lifecycleScope.launch {
            app.repository.reconcileOrphanedTasks(today)
            app.repository.ensureMustTasksExist(today)
        }

        lifecycleScope.launch {
            app.repository.observeTasksForDate(today).collectLatest { tasks ->
                renderTasks(tasks)
                refreshLedgerPreview(tasks)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Streak/program/guardian status can change from other screens
        // (Guardian Mode, Setup) — refresh whenever the user comes back.
        // This also covers the initial launch, since onResume always
        // fires right after onCreate, no separate call needed there.
        refreshDashboardSummary()
    }

    private fun refreshDashboardSummary() {
        lifecycleScope.launch {
            val ledgers = app.repository.getAllLedgersEver()
            val currentStreak = com.eyl.app.engine.AchievementEngine.currentStreak(ledgers, today)
            val longestStreak = com.eyl.app.engine.AchievementEngine.longestStreak(ledgers)
            textStreakSummary.text = if (currentStreak > 0) {
                "🔥 $currentStreak day streak · best $longestStreak"
            } else {
                "No streak yet · best $longestStreak"
            }

            val programStart = com.eyl.app.data.ProgramPreference.getStartDate(this@MainActivity)
            textProgramSummary.text = if (programStart == null) {
                "No timed program running — fully restricted, as always"
            } else {
                val duration = com.eyl.app.data.ProgramPreference.getDurationDays(this@MainActivity)
                val active = com.eyl.app.engine.ProgramEngine.isActive(programStart, duration, today)
                if (active) {
                    val remaining = com.eyl.app.engine.ProgramEngine.daysRemaining(programStart, duration, today)
                    "Program active — $remaining day(s) left"
                } else {
                    "Program ended — screen time & points unrestricted"
                }
            }

            val guardianTemplates = app.repository.getGuardianTemplates()
            if (guardianTemplates.isNotEmpty()) {
                textGuardianSummary.visibility = View.VISIBLE
                textGuardianSummary.text = "Guardian Mode — ${guardianTemplates.size} task(s) assigned"
            } else {
                textGuardianSummary.visibility = View.GONE
            }
        }
    }

    private fun renderTasks(allTasks: List<Task>) {
        val must = allTasks.filter { it.category == TaskCategory.MUST }
        val optional = allTasks.filter { it.category == TaskCategory.OPTIONAL }

        containerMustTasks.removeAllViews()
        // Alphabetical by title for now — Task has no stored scheduled
        // clock time yet, only a duration, so there's no real timeline to
        // sort by. A true chronological order would need that added to
        // the data model (tracked as part of the per-task alarm work).
        must.sortedBy { it.title }.forEach { task ->
            containerMustTasks.addView(buildTaskRow(task, isMustTask = true))
        }

        containerOptionalTasks.removeAllViews()
        if (optional.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No optional tasks yet — add one below."
                setTextColor(0xFF888888.toInt())
            }
            containerOptionalTasks.addView(empty)
        } else {
            optional.sortedByDescending { it.tier == ImportanceTier.IMPORTANT }.forEach { task ->
                containerOptionalTasks.addView(buildTaskRow(task, isMustTask = false))
            }
        }
    }

    private fun buildTaskRow(task: Task, isMustTask: Boolean): View {
        val row = LayoutInflater.from(this).inflate(R.layout.item_task, containerMustTasks, false)
        val icon = row.findViewById<TextView>(R.id.textTaskStatusIcon)
        val title = row.findViewById<TextView>(R.id.textTaskTitle)
        val meta = row.findViewById<TextView>(R.id.textTaskMeta)
        val action = row.findViewById<Button>(R.id.buttonTaskAction)
        val editButton = row.findViewById<ImageButton>(R.id.buttonEditTask)
        val duplicateButton = row.findViewById<ImageButton>(R.id.buttonDuplicateTask)

        title.text = task.title.replaceFirstChar { it.uppercase() }
        val tierLabel = task.tier?.let { " · ${it.name.lowercase().replace('_', ' ')}" } ?: ""
        meta.text = "${task.durationMinutes} min$tierLabel"

        icon.text = when (task.status) {
            TaskStatus.COMPLETED -> "✅"
            TaskStatus.FAILED -> "❌"
            TaskStatus.IN_PROGRESS -> "⏳"
            TaskStatus.PENDING -> "⬜"
        }

        action.isEnabled = task.status == TaskStatus.PENDING || task.status == TaskStatus.FAILED
        action.text = when (task.status) {
            TaskStatus.COMPLETED -> "Done"
            TaskStatus.IN_PROGRESS -> "Running…"
            TaskStatus.FAILED -> "Retry"
            TaskStatus.PENDING -> "Start"
        }
        action.setOnClickListener {
            val needsAccessibilityService = task.lockdownMode == LockdownMode.SINGLE_APP ||
                task.lockdownMode == LockdownMode.WHITELIST
            if (needsAccessibilityService && LockdownAccessibilityService.instance == null) {
                AlertDialog.Builder(this)
                    .setTitle("Lockdown isn't active")
                    .setMessage("EYL's Accessibility service isn't enabled, so this task would run on a timer with no actual app-blocking. Set it up first, or start anyway on the honor system?")
                    .setPositiveButton("Open setup") { _, _ -> startActivity(Intent(this, SetupActivity::class.java)) }
                    .setNegativeButton("Start anyway") { _, _ -> launchTask(task) }
                    .show()
            } else {
                launchTask(task)
            }
        }

        // Milestone 2: editing and duplicating only make sense for
        // user-created (optional) tasks — must-tasks are auto-generated
        // and their rules are fixed, so editing/duplicating them would be
        // meaningless (and duplicating a must-task's shape is handled via
        // EylRepository.duplicateTask, which always produces an OPTIONAL
        // task even if the source was a must-task).
        if (!isMustTask) {
            editButton.visibility = View.VISIBLE
            duplicateButton.visibility = View.VISIBLE
            editButton.setOnClickListener { showTaskDialog(existing = task) }
            duplicateButton.setOnClickListener {
                lifecycleScope.launch {
                    app.repository.duplicateTask(task)
                    Toast.makeText(this@MainActivity, "Duplicated \"${task.title}\"", Toast.LENGTH_SHORT).show()
                }
            }
        }

        row.apply {
            alpha = 0f
            translationY = 16f
            animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(220)
                .start()
        }

        return row
    }

    @Suppress("DEPRECATION")
    private fun launchTask(task: Task) {
        window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
        com.eyl.app.service.LockdownForegroundService.startTask(this, task.id)
        startActivity(
            Intent(this, TaskLockdownActivity::class.java)
                .putExtra(TaskLockdownActivity.EXTRA_TASK_ID, task.id)
        )
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private suspend fun refreshLedgerPreview(allTasks: List<Task>) {
        val must = allTasks.filter { it.category == TaskCategory.MUST }
        val optional = allTasks.filter { it.category == TaskCategory.OPTIONAL }
        val wakeUpState = app.repository.getWakeUpState(today)
        val isProgramActive = com.eyl.app.engine.ProgramEngine.isActive(
            com.eyl.app.data.ProgramPreference.getStartDate(this),
            com.eyl.app.data.ProgramPreference.getDurationDays(this),
            today
        )
        val ledger = PointsEngine.calculateDay(today, must, optional, wakeUpState, isProgramActive)

        textPointsSummary.text = if (ledger.mustTasksAllCompleted) {
            "${ledger.finalPoints} points today"
        } else {
            val doneCount = must.count { it.status == TaskStatus.COMPLETED }
            "0 points available (${doneCount}/${must.size} must-tasks done) — ${ledger.rawOptionalPoints} earned so far, unlocks once all must-tasks are complete"
        }
        val anyMustFailed = must.any { it.status == TaskStatus.FAILED }
        textGatekeeperWarning.visibility = if (anyMustFailed) View.VISIBLE else View.GONE
        textGatekeeperWarning.text = "A must-task was missed — today's points are zeroed."
    }

    /**
     * Milestone 3 — a simple 5-segment bar, one per daily prayer
     * (excluding adhkar/tahajud/the read, which aren't "prayers" in the
     * conventional sense), filled with the accent color as each is
     * completed. Deliberately lightweight (plain colored Views in a
     * LinearLayout) rather than a custom-drawn View, since this is a
     * cosmetic touch, not core logic — no need for the complexity of a
     * custom Canvas view on a low-RAM target device.
     */
    // --- Milestone 2: add/edit task dialog, now shared between both flows ---

    private fun showTaskDialog(existing: Task?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null)
        val editTitle = dialogView.findViewById<EditText>(R.id.editTaskTitle)
        val editDuration = dialogView.findViewById<EditText>(R.id.editTaskDuration)
        val checkMustTask = dialogView.findViewById<CheckBox>(R.id.checkMustTask)
        val textImportanceLabel = dialogView.findViewById<TextView>(R.id.textImportanceLabel)
        val radioTier = dialogView.findViewById<RadioGroup>(R.id.radioGroupTier)
        val radioLockdown = dialogView.findViewById<RadioGroup>(R.id.radioGroupLockdown)
        val buttonChooseApps = dialogView.findViewById<Button>(R.id.buttonChooseApps)
        val textChosenSummary = dialogView.findViewById<TextView>(R.id.textChosenAppsSummary)
        val checkSaveAsTemplate = dialogView.findViewById<CheckBox>(R.id.checkSaveAsTemplate)
        val textAlarmTimeSummary = dialogView.findViewById<TextView>(R.id.textAlarmTimeSummary)
        val buttonSetAlarmTime = dialogView.findViewById<Button>(R.id.buttonSetAlarmTime)
        val buttonClearAlarmTime = dialogView.findViewById<Button>(R.id.buttonClearAlarmTime)

        var chosenPackages = existing?.whitelistedPackages ?: emptyList()
        var chosenAlarmTime: java.time.LocalTime? = existing?.scheduledTime

        fun updateAlarmUi() {
            textAlarmTimeSummary.text = chosenAlarmTime?.let {
                "Alarm at ${it.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))}"
            } ?: "No alarm set"
        }
        updateAlarmUi()

        buttonSetAlarmTime.setOnClickListener {
            val initial = chosenAlarmTime ?: java.time.LocalTime.now()
            android.app.TimePickerDialog(
                this,
                { _, hour, minute ->
                    chosenAlarmTime = java.time.LocalTime.of(hour, minute)
                    updateAlarmUi()
                },
                initial.hour, initial.minute, false
            ).show()
        }
        buttonClearAlarmTime.setOnClickListener {
            chosenAlarmTime = null
            updateAlarmUi()
        }

        fun updateAppsUi(mode: LockdownMode) {
            val show = mode == LockdownMode.WHITELIST
            buttonChooseApps.visibility = if (show) View.VISIBLE else View.GONE
            textChosenSummary.visibility = if (show) View.VISIBLE else View.GONE
            textChosenSummary.text = if (chosenPackages.isEmpty())
                "No apps chosen yet" else "${chosenPackages.size} app(s) chosen"
        }

        // Tier only means anything for optional tasks — every must-task
        // is equally required, so hide it entirely once "must-do" is on.
        fun updateTierUi(isMustTask: Boolean) {
            val show = if (isMustTask) View.GONE else View.VISIBLE
            textImportanceLabel.visibility = show
            radioTier.visibility = show
        }

        // Pre-fill if editing an existing task.
        existing?.let { task ->
            editTitle.setText(task.title)
            editDuration.setText(task.durationMinutes.toString())
            checkMustTask.isChecked = task.category == TaskCategory.MUST
            radioTier.check(
                if (task.tier == ImportanceTier.IMPORTANT) R.id.radioTierImportant else R.id.radioTierLessImportant
            )
            radioLockdown.check(
                when (task.lockdownMode) {
                    LockdownMode.WHITELIST -> R.id.radioLockdownWhitelist
                    LockdownMode.SINGLE_APP -> R.id.radioLockdownSingleApp
                    LockdownMode.NONE -> R.id.radioLockdownNone
                }
            )
        }
        updateAppsUi(existing?.lockdownMode ?: LockdownMode.NONE)
        updateTierUi(checkMustTask.isChecked)

        checkMustTask.setOnCheckedChangeListener { _, isChecked -> updateTierUi(isChecked) }

        radioLockdown.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioLockdownWhitelist -> LockdownMode.WHITELIST
                R.id.radioLockdownSingleApp -> LockdownMode.SINGLE_APP
                else -> LockdownMode.NONE
            }
            updateAppsUi(mode)
        }

        buttonChooseApps.setOnClickListener {
            appPickerCallback = { chosen ->
                chosenPackages = chosen
                textChosenSummary.text = if (chosen.isEmpty()) "No apps chosen yet" else "${chosen.size} app(s) chosen"
            }
            val intent = Intent(this, AppPickerActivity::class.java)
                .putExtra(AppPickerActivity.EXTRA_PRESELECTED_PACKAGES, chosenPackages.toTypedArray())
            appPickerLauncher.launch(intent)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "New task" else "Edit task")
            .setView(dialogView)
            .setPositiveButton(if (existing == null) "Add" else "Save") { _, _ ->
                val title = editTitle.text.toString().trim()
                val duration = editDuration.text.toString().toIntOrNull() ?: 15
                if (title.isEmpty()) return@setPositiveButton

                val isMustTask = checkMustTask.isChecked
                val category = if (isMustTask) TaskCategory.MUST else TaskCategory.OPTIONAL
                val tier = if (isMustTask) null else if (radioTier.checkedRadioButtonId == R.id.radioTierImportant)
                    ImportanceTier.IMPORTANT else ImportanceTier.LESS_IMPORTANT

                val lockdownMode = when (radioLockdown.checkedRadioButtonId) {
                    R.id.radioLockdownWhitelist -> LockdownMode.WHITELIST
                    R.id.radioLockdownSingleApp -> LockdownMode.SINGLE_APP
                    else -> LockdownMode.NONE
                }

                val whitelist = if (lockdownMode == LockdownMode.WHITELIST) chosenPackages else emptyList()

                val task = Task(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    date = existing?.date ?: today,
                    category = category,
                    title = title,
                    tier = tier,
                    durationMinutes = duration,
                    lockdownMode = lockdownMode,
                    whitelistedPackages = whitelist,
                    status = existing?.status ?: TaskStatus.PENDING,
                    scheduledTime = chosenAlarmTime
                )

                // Always cancel first, then reschedule only if a time is
                // set — simpler than tracking "was it previously set" and
                // correctly handles clearing an alarm on an edit too.
                com.eyl.app.engine.TaskAlarmScheduler.cancelTaskAlarm(this, task.id)
                chosenAlarmTime?.let {
                    com.eyl.app.engine.TaskAlarmScheduler.scheduleTaskAlarm(this, task.id, task.date, it)
                }

                lifecycleScope.launch {
                    app.repository.saveTask(task)
                    if (checkSaveAsTemplate.isChecked) {
                        val template = TaskTemplate(
                            id = UUID.randomUUID().toString(),
                            title = title,
                            category = category,
                            tier = tier,
                            durationMinutes = duration,
                            lockdownMode = lockdownMode,
                            whitelistedPackages = whitelist,
                            createdBy = TaskSource.SELF,
                            scheduledTime = chosenAlarmTime
                        )
                        if (category == TaskCategory.MUST) {
                            // Recurs daily via ensureMustTasksExist from now on —
                            // reuse the same retroactive same-day sync Guardian
                            // mode uses, so today's instance (already saved just
                            // above) stays linked to this template correctly.
                            app.repository.saveMustTemplate(template, today)
                        } else {
                            app.repository.saveTemplate(template)
                        }
                        Toast.makeText(this@MainActivity, "Saved as template", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Milestone 2: templates ---

    private fun showTemplatePickerDialog() {
        lifecycleScope.launch {
            val list = app.repository.getTemplates()
            if (list.isEmpty()) {
                Toast.makeText(this@MainActivity, "No templates saved yet — create a task and check \"Save as template\"", Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = list.map { "${it.title} (${it.durationMinutes} min)" }.toTypedArray()
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Choose a template")
                .setItems(labels) { _, index ->
                    val template = list[index]
                    lifecycleScope.launch {
                        app.repository.createTaskFromTemplate(template, today)
                        Toast.makeText(this@MainActivity, "Added \"${template.title}\"", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}
