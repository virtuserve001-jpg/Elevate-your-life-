package com.eyl.app.engine

import java.time.LocalDate

/**
 * Pure logic for the optional timed-program feature: a user can choose to
 * restrict themselves for a fixed number of days, after which the app
 * stops enforcing the day-wide screen-time budget and the points
 * gatekeeper entirely — a "training wheels come off" design, not a
 * punishment or a reward.
 *
 * Deliberately kept framework-free (no Context, no SharedPreferences) so
 * it's directly unit-testable, same reasoning as PointsEngine and
 * WakeUpGameEngine. See ProgramPreference for the Android storage side.
 *
 * IMPORTANT: never set = always active. A user who never opts into a
 * timed program gets today's existing behavior forever — this feature is
 * additive, not a change to anyone who doesn't touch it.
 *
 * Deliberately NOT checked by task-level lockdown enforcement — a task
 * the user actively starts still locks down normally regardless of
 * program status, only the ambient day-wide restriction and the points
 * gatekeeper are affected. Starting a task is always a deliberate,
 * present-moment choice, separate from the program's ongoing restriction.
 */
object ProgramEngine {

    /**
     * @param startDate the day the program began, or null if one was
     *        never set up
     * @param durationDays how many days the program restricts for,
     *        counting the start date itself as day 1. A 15-day program
     *        starting Jan 1 is active Jan 1 through Jan 15 inclusive,
     *        and inactive from Jan 16 onward.
     */
    fun isActive(startDate: LocalDate?, durationDays: Int, today: LocalDate): Boolean {
        if (startDate == null) return true
        val endExclusive = startDate.plusDays(durationDays.toLong())
        return today.isBefore(endExclusive)
    }

    /** Positive while active, 0 or negative once the program has ended. */
    fun daysRemaining(startDate: LocalDate?, durationDays: Int, today: LocalDate): Int {
        if (startDate == null) return 0
        val endExclusive = startDate.plusDays(durationDays.toLong())
        return java.time.temporal.ChronoUnit.DAYS.between(today, endExclusive).toInt()
    }
}
