package com.eyl.app.data

import android.content.Context
import java.time.LocalTime

/**
 * Persists the user's chosen wake-up alarm time — the missing piece
 * BootReceiver's own comment flagged as an open TODO ("needs the user's
 * chosen alarm time, which isn't modeled/persisted yet"). Storing it here
 * is what lets BootReceiver re-arm the alarm after a reboot.
 */
object WakeUpAlarmPreference {
    private const val PREFS_NAME = "eyl_prefs"
    private const val KEY_HOUR = "wakeup_alarm_hour"
    private const val KEY_MINUTE = "wakeup_alarm_minute"

    fun getTime(context: Context): LocalTime? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_HOUR)) return null
        return LocalTime.of(prefs.getInt(KEY_HOUR, 7), prefs.getInt(KEY_MINUTE, 0))
    }

    fun setTime(context: Context, time: LocalTime) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_HOUR, time.hour)
            .putInt(KEY_MINUTE, time.minute)
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_HOUR)
            .remove(KEY_MINUTE)
            .apply()
    }
}
