package com.eyl.app.ui

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.eyl.app.R

/**
 * Step-by-step settings walkthrough, covering every permission the app
 * actually needs, in the order they should be granted. Reachable from
 * both first-run onboarding (WelcomeActivity) and later from Setup, for
 * anyone who wants a refresher without re-doing the whole welcome flow.
 */
class SettingsTutorialActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings_tutorial)
        findViewById<Button>(R.id.buttonBackToSetup).setOnClickListener { finish() }
    }
}
