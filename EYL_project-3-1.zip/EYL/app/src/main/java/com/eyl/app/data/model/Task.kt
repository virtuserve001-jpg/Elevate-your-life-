package com.eyl.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalTime

/**
 * The two categories of task in EYL.
 *
 * MUST tasks are non-negotiable and trigger the gatekeeper rule:
 * missing even one zeroes the entire day's points.
 *
 * OPTIONAL tasks are user-defined and placed into an importance Tier
 * by the user, but the point VALUE of each tier is fixed by the app,
 * not chosen by the user (prevents self-inflation of points).
 */
enum class TaskCategory {
    MUST,
    OPTIONAL
}

/**
 * Importance tier for OPTIONAL tasks. The user assigns a task to a tier;
 * the app assigns the point value per tier (see PointsEngine.TIER_VALUES).
 * Not used for MUST tasks — every must-task carries equal weight, since
 * the gatekeeper rule requires all of them regardless of importance.
 */
enum class ImportanceTier {
    IMPORTANT,
    LESS_IMPORTANT
}

/**
 * The two lockdown modes used during a task's verification timer.
 *
 * SINGLE_APP: only EYL (or one designated app) is reachable.
 *
 * WHITELIST: a pre-defined set of apps stay reachable — the whitelist is
 * baked into the task's originating template, not chosen per-session, so
 * lockdown engages automatically when the task starts.
 */
enum class LockdownMode {
    SINGLE_APP,
    WHITELIST,
    NONE // no enforcement — honor system
}

/**
 * Who created a task or template. SELF for the device owner's own tasks;
 * GUARDIAN for tasks assigned by a guardian/teacher in Guardian-Self mode.
 * Defaults to SELF so existing single-user usage is unaffected.
 */
enum class TaskSource {
    SELF,
    GUARDIAN
}

/**
 * A single task instance for a given day.
 *
 * MUST tasks are generated automatically each day from any active
 * TaskTemplate marked category == MUST — there's no fixed built-in list
 * (previously a hardcoded set of prayer-specific task types; generalized
 * so EYL works for any kind of daily discipline, not one specific use).
 *
 * OPTIONAL tasks are created directly by the user (or instantiated from
 * a saved template), who sets title, tier, duration, and lockdown mode.
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val date: LocalDate,
    val category: TaskCategory,
    val title: String,
    // Links back to whichever TaskTemplate generated this instance.
    // Null for one-off optional tasks not created from a template.
    val templateId: String? = null,
    // Only meaningfully set when category == OPTIONAL
    val tier: ImportanceTier? = null,
    val durationMinutes: Int,
    val lockdownMode: LockdownMode,
    // App package names allowed during lockdown, only used when lockdownMode == WHITELIST
    val whitelistedPackages: List<String> = emptyList(),
    val status: TaskStatus = TaskStatus.PENDING,
    val startedAt: LocalTime? = null,
    val completedAt: LocalTime? = null,
    // True if the lockdown was broken (interruption slipped through, manual override, etc.)
    val lockdownBroken: Boolean = false,
    val createdBy: TaskSource = TaskSource.SELF,
    // Optional clock time this task's own alarm should fire at — separate
    // from durationMinutes (how long the task takes once started). Null
    // means no alarm, the task is just started manually whenever. Distinct
    // from the standalone wake-up alarm (AlarmScheduler/AlarmReceiver),
    // which keeps its own escalating anti-snooze game — a task alarm just
    // rings and dismisses normally, see TaskAlarmScheduler.
    val scheduledTime: LocalTime? = null
)

enum class TaskStatus {
    PENDING,
    IN_PROGRESS, // timer running, lockdown active
    COMPLETED,   // timer ran to completion without the lockdown being broken
    FAILED       // lockdown broken, or day ended with task incomplete
}
