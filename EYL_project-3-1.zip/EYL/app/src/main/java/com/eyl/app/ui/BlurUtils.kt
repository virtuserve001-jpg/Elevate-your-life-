package com.eyl.app.ui

import android.graphics.RenderEffect
import android.graphics.Shader
import android.view.View

/**
 * Applies real hardware blur (RenderEffect, API 31+ — guaranteed by
 * minSdk 31) to a View. Deliberately used on a plain decorative backing
 * layer within each card, NOT on the card's content container directly —
 * RenderEffect blurs a View's own rendered output including its
 * children, so applying it to something holding text would blur the
 * text too. Each card should have a plain background View as its first
 * child (no text/icons inside it) that this gets applied to, with the
 * real content sitting in a separate, unblurred layer on top.
 *
 * This isn't true CSS-style backdrop-filter (which samples and blurs
 * whatever is actually rendered behind a layer, live) — Android has no
 * simple one-call API for that outside of Window.setBackgroundBlurRadius
 * (window-level only, used for dialogs/sheets, not arbitrary in-layout
 * cards). This is a soft frosted backing surface using genuine RenderEffect
 * blur, which is what actually delivers the visual effect in practice.
 */
fun View.applyPremiumBlur(radius: Float = 24f) {
    setRenderEffect(
        RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
    )
}
