package com.eyl.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.ui.MainActivity
import kotlinx.coroutines.launch

/**
 * Fired by AlarmManager at an individual task's scheduledTime. Unlike
 * AlarmReceiver (the standalone wake-up alarm), this doesn't launch a
 * full-screen escalating game — it posts a normal high-priority
 * notification with sound, and tapping it just opens the app. Only the
 * one standalone wake-up alarm gets the anti-snooze treatment; every
 * task alarm rings and dismisses like an ordinary reminder.
 */
class TaskAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        private const val CHANNEL_ID = "eyl_task_alarm_channel"
        private const val NOTIFICATION_ID_BASE = 6000
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return
        val app = context.applicationContext as EylApplication

        app.applicationScope.launch {
            val task = app.repository.getTask(taskId) ?: return@launch
            // Don't ring for a task that's already been resolved one way
            // or another since this alarm was scheduled (completed early,
            // failed, or the day already moved on).
            if (task.status != com.eyl.app.data.model.TaskStatus.PENDING) return@launch

            postNotification(context, taskId, task.title)
        }
    }

    private fun postNotification(context: Context, taskId: String, title: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Task alarms", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts you when a scheduled task's time has arrived"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, taskId.hashCode(), contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time for: $title")
            .setContentText("Tap to open EYL and start this task")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_BASE + taskId.hashCode(), notification)
    }
}
