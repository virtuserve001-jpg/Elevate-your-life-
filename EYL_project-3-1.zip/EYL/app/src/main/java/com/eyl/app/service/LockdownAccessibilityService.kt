package com.eyl.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.eyl.app.EylApplication
import com.eyl.app.data.model.LockdownMode
import com.eyl.app.data.model.TaskStatus
import com.eyl.app.engine.DayWideRestrictionStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * LockdownAccessibilityService
 * ----------------------------
 * This is the enforcement mechanism for two separate things:
 *
 * 1. TASK LOCKDOWN (rules 4 & 6 of the original spec): "auto lockdown,
 *    all interruptions auto-blocked, no per-session setup" — while a
 *    single task's timer is running (activeLockdown != null), only the
 *    allowed app(s) for THAT task can be foreground.
 *
 * 2. DAY-WIDE RESTRICTIONS (the points-spending system): independent of
 *    any running task — a user-designated set of "restricted" apps stay
 *    blocked unless unlocked with spent points, and a daily screen-time
 *    budget (also funded by spent points) cuts off all non-EYL apps once
 *    exhausted. This only applies when NO task lockdown is active, since
 *    task lockdown is already stricter and takes priority.
 *
 * HOW IT WORKS:
 * Android fires TYPE_WINDOW_STATE_CHANGED accessibility events whenever
 * the foreground app changes. We inspect every such event against
 * whichever of the two systems above currently applies, and immediately
 * bounce back to EYL if the newly-foregrounded app isn't allowed — the
 * disallowed app never gets a chance to actually render to the user.
 *
 * IMPORTANT DEVICE CONSTRAINTS (relevant to the Itel A50 / Android Go):
 * - Android Go devices are aggressive about killing background services
 *   to save RAM. This service relies on LockdownForegroundService's
 *   persistent notification to avoid being killed mid-task.
 * - The user must manually enable this service under
 *   Settings > Accessibility > EYL, and should be prompted to disable
 *   battery optimization for EYL specifically. This can't be done
 *   programmatically — it requires explicit user action, by design of
 *   the Android permission model.
 * - This permission is heavily scrutinized by Google Play review since
 *   it's historically abused by malware. Expect friction if you ever
 *   want this distributed via Play Store rather than sideloaded.
 *
 * NOTE ON SCREEN-TIME TRACKING ACCURACY: elapsed time is measured between
 * consecutive TYPE_WINDOW_STATE_CHANGED events, which fire on app
 * switches, not on a fixed clock — so usage while sitting untouched in a
 * single app for a long stretch is still captured correctly (attributed
 * at the NEXT switch), but very rapid switching between many apps could
 * accumulate small rounding differences. Fine for a personal discipline
 * tool; not audit-grade.
 *
 * SELF-HEALING ON RECONNECT: activeLockdown previously only ever got set
 * by TaskTimerManager explicitly pushing state in — meaning if the whole
 * app process died mid-task (killed by the OS, or the persistent
 * notification got force-cancelled, which also lets Android reclaim the
 * foreground service keeping this process alive) and the accessibility
 * service later reconnected fresh, activeLockdown came back null and
 * enforcement silently stopped, even though the task was still marked
 * IN_PROGRESS in the database. onServiceConnected now pulls its own
 * state directly from the database instead of waiting to be told,
 * closing that window regardless of why the process died.
 */
class LockdownAccessibilityService : AccessibilityService() {

    companion object {
        // The system manages this service's lifecycle, so other classes
        // can't just construct one — they need a reference to whichever
        // instance is currently running. Null until the service connects,
        // and null again once it's torn down (e.g. user revoked permission).
        @Volatile var instance: LockdownAccessibilityService? = null
            private set
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var restrictionStore: DayWideRestrictionStore
    private var lastForegroundPackage: String? = null
    private var lastEventTimeMillis: Long = 0L

    // Resolved once on connect so users can pass through the home screen to
    // reach a whitelisted app — without this, switching to the launcher to
    // navigate to (say) WhatsApp gets bounced just like any other app,
    // since the launcher is its own separate foreground package.
    private var launcherPackage: String? = null

    // The system UI process (status bar, notification shade, and — the
    // one that actually bit us — the recent-apps/app-switcher overview)
    // is its own separate foreground package too. Swiping up to Recents
    // to tap a whitelisted app briefly foregrounds this package first;
    // without allowing it through, users get bounced before ever reaching
    // the app they were switching to.
    private val systemUiPackages = setOf("com.android.systemui")

    // Safety-critical: phone calls should never be blocked, in ANY lockdown
    // mode, including SINGLE_APP prayer tasks — being unreachable for an
    // emergency call because a task lockdown is active would be a real
    // harm, not just an inconvenience. Combines the device's actual dialer
    // (resolved dynamically, since it varies by OEM) with the common
    // AOSP in-call/telecom package names as a fallback, since incoming
    // calls are often shown by a different package than the outgoing
    // dialer itself.
    private var dialerPackage: String? = null
    private val callUiFallbackPackages = setOf(
        "com.android.server.telecom",
        "com.android.incallui",
        "com.android.phone"
    )
    private val phonePackages: Set<String>
        get() = callUiFallbackPackages + listOfNotNull(dialerPackage)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        restrictionStore = DayWideRestrictionStore(applicationContext)
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        launcherPackage = packageManager.resolveActivity(
            homeIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        val dialIntent = Intent(Intent.ACTION_DIAL)
        dialerPackage = packageManager.resolveActivity(
            dialIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName

        serviceScope.launch { reengageActiveTaskIfAny() }
    }

    /**
     * Checks the database directly for any task still marked IN_PROGRESS
     * whose scheduled window hasn't ended yet, and re-engages lockdown for
     * it immediately — without waiting for TaskTimerManager to push state
     * in. This is what makes the service self-healing: it no longer
     * depends on the app process having stayed alive continuously since
     * the task started.
     *
     * Deliberately does NOT touch tasks whose window has already passed —
     * that's reconcileOrphanedTasks' job (run elsewhere, on app open and
     * at daily rollover), which resolves them to FAILED. Re-engaging
     * lockdown for an already-expired task here would trap the user
     * indefinitely with no way for the countdown to ever complete.
     */
    private suspend fun reengageActiveTaskIfAny() {
        val app = applicationContext as? EylApplication ?: return
        val today = LocalDate.now()
        val allTasks = app.repository.getMustTasksForDate(today) +
            app.repository.getOptionalTasksForDate(today)

        val activeTask = allTasks.firstOrNull { task ->
            task.status == TaskStatus.IN_PROGRESS && task.startedAt != null
        } ?: return
        val startedAt = activeTask.startedAt ?: return

        val expectedEnd = today.atTime(startedAt).plusMinutes(activeTask.durationMinutes.toLong())
        if (LocalDateTime.now().isAfter(expectedEnd)) return // already expired — reconciliation's job, not ours

        val lockdown = when (activeTask.lockdownMode) {
            LockdownMode.SINGLE_APP -> ActiveLockdown(taskId = activeTask.id, mode = LockdownMode.SINGLE_APP, allowedPackages = emptySet())
            LockdownMode.WHITELIST -> ActiveLockdown(taskId = activeTask.id, mode = LockdownMode.WHITELIST, allowedPackages = activeTask.whitelistedPackages.toSet())
            LockdownMode.NONE -> null
        }
        if (activeTask.lockdownMode != LockdownMode.NONE) {
            setActiveLockdown(lockdown)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (instance == this) instance = null
    }

    // Populated by TaskTimerManager when a task's timer starts, cleared when it ends.
    private var activeLockdown: ActiveLockdown? = null

    data class ActiveLockdown(
        val taskId: String,
        val mode: LockdownMode,
        val allowedPackages: Set<String> // for SINGLE_APP this is just {ownPackage}
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val foregroundPackage = event.packageName?.toString() ?: return

        val lockdown = activeLockdown
        if (lockdown != null) {
            enforceTaskLockdown(lockdown, foregroundPackage)
        } else {
            trackAndEnforceDayWide(foregroundPackage)
        }

        lastForegroundPackage = foregroundPackage
        lastEventTimeMillis = System.currentTimeMillis()
    }

    // --- Task lockdown (unchanged behavior, highest priority) ---

    private fun enforceTaskLockdown(lockdown: ActiveLockdown, foregroundPackage: String) {
        // Safety-critical, applies regardless of lockdown mode: never block
        // a phone call, not even during a strict SINGLE_APP prayer task.
        if (foregroundPackage in phonePackages) return

        val isAllowed = when (lockdown.mode) {
            LockdownMode.SINGLE_APP -> foregroundPackage == packageName
            LockdownMode.WHITELIST -> foregroundPackage in lockdown.allowedPackages ||
                foregroundPackage == packageName ||
                foregroundPackage == launcherPackage ||
                foregroundPackage in systemUiPackages
            LockdownMode.NONE -> true // "No lockdown" tasks — genuinely no enforcement, nothing to check
        }
        if (!isAllowed) {
            bounceBackToTask(lockdown.taskId, foregroundPackage)
        }
    }

    // --- Day-wide restrictions (screen-time budget + app-unlock list) ---

    private fun trackAndEnforceDayWide(foregroundPackage: String) {
        if (!::restrictionStore.isInitialized) return
        val today = LocalDate.now()

        val isProgramActive = com.eyl.app.engine.ProgramEngine.isActive(
            com.eyl.app.data.ProgramPreference.getStartDate(applicationContext),
            com.eyl.app.data.ProgramPreference.getDurationDays(applicationContext),
            today
        )
        if (!isProgramActive) return // timed program has ended — day-wide restriction no longer applies

        if (restrictionStore.isStale(today)) {
            // No budget set for today yet (DailyRolloverWorker or MainActivity
            // hasn't initialized it) — nothing to enforce until it is.
            return
        }

        // Attribute elapsed time to whatever was ALLOWED and foreground
        // before this switch (not to EYL itself, and not to something
        // that was already blocked).
        val previous = lastForegroundPackage
        if (previous != null && previous != packageName && lastEventTimeMillis > 0) {
            val elapsedSeconds = ((System.currentTimeMillis() - lastEventTimeMillis) / 1000).toInt()
            if (elapsedSeconds > 0) restrictionStore.addUsedSeconds(elapsedSeconds)
        }

        if (foregroundPackage == packageName) return // EYL itself is always allowed

        val restricted = restrictionStore.getRestrictedPackages()
        val unlockedToday = restrictionStore.getUnlockedPackages()

        val isRestrictedAndLocked = foregroundPackage in restricted && foregroundPackage !in unlockedToday
        val isOverBudget = restrictionStore.isBudgetExhausted()

        if (isRestrictedAndLocked) {
            bounceBackDayWide(foregroundPackage, "That app is restricted — spend points to unlock it for today.")
        } else if (isOverBudget) {
            bounceBackDayWide(foregroundPackage, "Today's screen-time budget is used up.")
        }
    }

    /**
     * Called when a disallowed app slips into the foreground during task
     * lockdown. We immediately bring EYL back to front. A bounce-back
     * that succeeds within a fraction of a second does NOT fail the task
     * outright — only a genuine enforcement failure (onInterrupt) does.
     */
    private fun bounceBackToTask(taskId: String, attemptedPackage: String) {
        val intent = Intent(this, com.eyl.app.ui.TaskLockdownActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(com.eyl.app.ui.TaskLockdownActivity.EXTRA_TASK_ID, taskId)
            putExtra("blocked_package_attempted", attemptedPackage)
        }
        startActivity(intent)
    }

    private fun bounceBackDayWide(attemptedPackage: String, reason: String) {
        val intent = Intent(this, com.eyl.app.ui.SpendActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("blocked_package_attempted", attemptedPackage)
            putExtra("block_reason", reason)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {
        // Called if the system disables this service mid-task (e.g. user
        // revokes the permission, or an OEM battery-saver kills it).
        // This is a genuine lockdown break — unlike a bounce-back, there's
        // no recovery here, so we notify whoever is managing the active task.
        onLockdownBrokenCallback?.invoke()
    }

    // Set by TaskTimerManager when it starts a locked task; cleared when
    // the task ends. Lets the service report a genuine, unrecoverable
    // lockdown failure back to the thing that owns task state.
    var onLockdownBrokenCallback: (() -> Unit)? = null

    fun setActiveLockdown(lockdown: ActiveLockdown?) {
        activeLockdown = lockdown
    }
}
