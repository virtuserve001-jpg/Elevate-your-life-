# EYL — Elevate Your Life

Core rules engine + lockdown enforcement skeleton, built to spec.

## What's here (v3 — complete first build)

Every rule from our spec conversation is implemented end to end: data models → Room persistence → points/gatekeeper logic → lockdown enforcement (both app-blocking and phone-untouched modes) → timer coordination → foreground service → UI → the wake-up alarm and its escalating minigame → daily rollover. This is a real, sync-able Android Studio project now, not just a scaffold.

```
EYL/
├── build.gradle.kts, settings.gradle.kts
├── app/build.gradle.kts
├── app/src/main/AndroidManifest.xml
├── app/src/main/res/
│   ├── layout/            # activity_main, item_task, dialog_add_task,
│   │                       # activity_task_lockdown, activity_alarm_game
│   ├── values/             # strings, themes
│   └── xml/                 # accessibility_service_config
└── app/src/main/java/com/eyl/app/
    ├── EylApplication.kt          # app-wide DB/repo singletons, schedules daily rollover on launch
    ├── data/model/                 # Task, MustTaskType, WakeUpGameState, PointsLedger, SpendAllocation (all @Entity)
    ├── data/db/                    # Converters, DAOs, EylDatabase
    ├── data/EylRepository.kt       # DAO wrapper + auto-generates each day's must-tasks
    ├── engine/
    │   ├── PointsEngine.kt          # gatekeeper + tier + wake-up penalty — the rulebook
    │   ├── WakeUpGameEngine.kt       # escalating difficulty, 30-min penalty trigger, no ceiling
    │   ├── TaskTimerManager.kt       # starts a task, routes to the right lockdown, ticks, finalizes
    │   ├── PhoneUntouchedMonitor.kt   # screen-on detector for prayer/adhkar/tahajud (opposite of app-blocking)
    │   ├── AlarmScheduler.kt          # AlarmManager wiring for the wake-up alarm
    │   └── DailyRolloverWorker.kt     # WorkManager midnight job: finalize yesterday, generate today
    ├── service/
    │   ├── LockdownAccessibilityService.kt  # single-app / whitelist app-blocking enforcement
    │   ├── LockdownForegroundService.kt      # keeps enforcement alive on Android Go; owns TaskTimerManager + alarm sound/vibration
    │   ├── AlarmReceiver.kt                   # fired by AlarmManager, launches the game + starts ringing
    │   └── BootReceiver.kt                     # re-asserts the daily rollover schedule after reboot
    └── ui/
        ├── MainActivity.kt          # dashboard: must-tasks, optional tasks, points, add-task dialog
        ├── TaskLockdownActivity.kt   # live countdown screen + bounce-back target from the accessibility service
        └── AlarmGameActivity.kt      # the tap-in-sequence wake-up game, undismissable except by winning
```

Every rule from our spec conversation maps directly to a place in this code:

| Spec rule | Where it lives |
|---|---|
| Must-tasks are gatekeeper (miss one → day = 0) | `PointsEngine.calculateDay()` |
| Fixed points per tier, not user-set | `PointsEngine.tierValue()` |
| One pool, flexible spend | `SpendAllocation` |
| Prayer durations fixed, Friday Dhuhr exception | `MustTaskType.durationMinutesFor()` |
| Auto lockdown, no per-session app picking | `LockdownAccessibilityService` reads a pre-set whitelist |
| Interruptions auto-blocked | Accessibility event bounce-back |
| Wake-up game never capped, gets harder, 30-min penalty | `WakeUpGameEngine` |

## How to open this

1. Open Android Studio → Open → select the `EYL` folder. It should sync and build cleanly now — every class referenced in the manifest exists.
2. Before running: replace the placeholder launcher icon (`@android:drawable/sym_def_app_icon` in the manifest) with real app art whenever you get to that.

## Before your first real run — permissions the user must grant manually

Android won't let any app self-grant these, by design. On first launch you'll want an onboarding flow (not yet built) that walks the user through:

1. **Settings → Accessibility → EYL → enable.** Without this, `LockdownAccessibilityService.instance` is null and `TaskTimerManager` silently skips app-blocking lockdown (see `engageLockdown()` — it no-ops gracefully rather than crashing, but the task won't actually be enforced).
2. **Disable battery optimization for EYL specifically**, or the A50's Android Go battery manager will likely kill the foreground service mid-task.
3. **Notification permission** (Android 13+) — needed for the foreground service notifications to show at all.
4. **"Allow setting alarms & reminders"** (`SCHEDULE_EXACT_ALARM`) — needed for `AlarmScheduler` to fire on time.

## Friction points from the last review — all addressed

1. **Duplicate `TaskTimerManager` instance** — removed. `EylApplication` no longer constructs one; `LockdownForegroundService`'s instance is the single source of truth, with a comment in `EylApplication.kt` explaining why.

2. **No automated tests** — added `app/src/test/java/com/eyl/app/engine/`: `PointsEngineTest.kt` (gatekeeper priority over wake-up penalty, tier scoring, penalty floor at zero) and `WakeUpGameEngineTest.kt` (monotonic difficulty escalation, no-ceiling behavior, exact 30-min penalty boundary, idempotent penalty checks). Both engines have zero Android dependencies, so these run as plain JVM unit tests — no emulator needed. Run via `./gradlew test`.

3. **`PhoneUntouchedMonitor` only caught screen-ON events** — now also listens for `ACTION_USER_PRESENT` (unlock), and `start()` returns `true` immediately if the screen is already on/unlocked the moment a prayer/adhkar/tahajud task begins, so `TaskTimerManager` fails it right away instead of running a countdown that was already compromised. The remaining known gap (an already-on, already-unlocked screen being glanced at without a fresh unlock event) is still documented in the file — closing it fully needs touch/accelerometer sampling, a real battery-cost tradeoff worth a deliberate decision rather than a quiet addition.

4. **Points-spending had no UI or enforcement** — built out fully, with one honesty constraint kept front and center: only **screen time** and **app unlocks** are genuinely enforceable by a non-Device-Owner app (via the same accessibility-service mechanism as task lockdown); **mobile data** cannot be throttled per-app without Device Owner provisioning or a VPN-based traffic filter — both significant scope increases beyond what a personal tool needs. So mobile data is tracked and shown, explicitly labeled "not enforced" in the UI, rather than pretending to work.
   - `SpendEngine.kt` — the three exchange rates in one place.
   - `DayWideRestrictionStore.kt` — SharedPreferences-backed daily budget/unlock state, read by the accessibility service on every foreground-app switch.
   - `LockdownAccessibilityService` — extended with a second enforcement path (day-wide restrictions) that only applies when no task lockdown is active, since task lockdown is stricter and takes priority.
   - `SpendActivity` + `activity_spend.xml` — sliders for each currency, live budget previews, a restricted-apps list editor, and per-app unlock checkboxes capped by how many points were allocated.
   - `DailyRolloverWorker` now also resets the restriction store each day — defaulting to a **zero budget** if the user didn't manually allocate, rather than silently carrying over yesterday's numbers, since spending is meant to be a deliberate daily choice.

5. **No onboarding/permissions flow** — added `SetupActivity` + `activity_setup.xml`: one screen listing all four manual permissions EYL needs (Accessibility service, battery optimization, notifications, exact alarms), each with a live ✅/❌ status check and a direct link to the right Settings screen. Reachable from the dashboard's "Permissions setup" button. `MainActivity` also now checks `LockdownAccessibilityService.instance` before starting any lockdown-requiring task — if it's not enabled, the user gets an explicit choice between opening setup or starting anyway on the honor system, rather than a task silently running unenforced.

## What's still open (smaller, lower-priority than the above)

- Alarm time itself still isn't configurable from the UI — `AlarmScheduler.scheduleWakeUpAlarm()` exists and works, but nothing calls it yet. `BootReceiver` only re-arms the daily rollover, not the wake-up alarm, for the same reason (noted in its own file).
- No UI test coverage yet (Espresso is in the Gradle deps, unused so far) — the unit tests cover the two pure-logic engines only.
- Placeholder launcher icon (`@android:drawable/sym_def_app_icon`) — fine for sideloading, needs real art before any wider distribution.
- `foregroundServiceType="specialUse"` needs a `<property>` declaration for Android 14+ Play Store compliance — not required for sideloading.
