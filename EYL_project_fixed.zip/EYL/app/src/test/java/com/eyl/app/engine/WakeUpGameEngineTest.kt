package com.eyl.app.engine

import com.eyl.app.data.model.WakeUpGameState
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class WakeUpGameEngineTest {

    private val date = LocalDate.of(2026, 7, 21)
    private val alarmStart = LocalTime.of(5, 0)

    @Test
    fun `starts at difficulty level 1 with zero attempts`() {
        val state = WakeUpGameEngine.start(date, alarmStart)
        assertEquals(1, state.currentDifficultyLevel)
        assertEquals(0, state.attempts)
    }

    @Test
    fun `difficulty only ever increases, never resets on failure`() {
        var state = WakeUpGameEngine.start(date, alarmStart)
        val levels = mutableListOf(state.currentDifficultyLevel)
        repeat(10) {
            state = WakeUpGameEngine.onAttemptFailed(state)
            levels.add(state.currentDifficultyLevel)
        }
        // Strictly increasing, no dips.
        for (i in 1 until levels.size) {
            assertTrue(levels[i] > levels[i - 1])
        }
        assertEquals(10, state.attempts)
    }

    @Test
    fun `failing an attempt never applies a penalty by itself`() {
        var state = WakeUpGameEngine.start(date, alarmStart)
        repeat(5) { state = WakeUpGameEngine.onAttemptFailed(state) }
        assertFalse(state.penaltyApplied)
    }

    @Test
    fun `game params scale with difficulty and cap sequence length reasonably`() {
        val early = WakeUpGameEngine.paramsForLevel(1)
        val late = WakeUpGameEngine.paramsForLevel(50) // simulate someone failing a LOT — no ceiling on attempts

        assertTrue(late.targetSequenceLength >= early.targetSequenceLength)
        assertTrue(late.timeLimitSeconds <= early.timeLimitSeconds)
        // Sanity: even at absurd difficulty, params stay usable (not zero/negative).
        assertTrue(late.timeLimitSeconds > 0)
        assertTrue(late.targetSequenceLength <= 12) // coerced ceiling from the implementation
    }

    @Test
    fun `distractions only enable from level 3 onward`() {
        assertFalse(WakeUpGameEngine.paramsForLevel(1).distractionsEnabled)
        assertFalse(WakeUpGameEngine.paramsForLevel(2).distractionsEnabled)
        assertTrue(WakeUpGameEngine.paramsForLevel(3).distractionsEnabled)
        assertTrue(WakeUpGameEngine.paramsForLevel(10).distractionsEnabled)
    }

    @Test
    fun `no penalty before the 30-minute limit`() {
        val state = WakeUpGameEngine.start(date, alarmStart)
        val checked = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(29))
        assertFalse(checked.penaltyApplied)
    }

    @Test
    fun `penalty applies exactly at and after the 30-minute limit`() {
        val state = WakeUpGameEngine.start(date, alarmStart)
        val atLimit = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(30))
        assertTrue(atLimit.penaltyApplied)

        val pastLimit = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(45))
        assertTrue(pastLimit.penaltyApplied)
    }

    @Test
    fun `beating the game before the limit prevents a later penalty check from applying`() {
        var state = WakeUpGameEngine.start(date, alarmStart)
        state = WakeUpGameEngine.onGameBeaten(state, alarmStart.plusMinutes(10))

        val checked = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(40))
        assertFalse(checked.penaltyApplied) // already beaten, penalty check is moot
    }

    @Test
    fun `checkPenalty is idempotent once already applied`() {
        val state = WakeUpGameEngine.start(date, alarmStart)
        val first = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(35))
        val second = WakeUpGameEngine.checkPenalty(first, alarmStart.plusMinutes(60))
        assertEquals(first, second)
    }

    @Test
    fun `beating the game after the penalty already triggered does not retroactively remove it`() {
        var state = WakeUpGameEngine.start(date, alarmStart)
        state = WakeUpGameEngine.checkPenalty(state, alarmStart.plusMinutes(35))
        assertTrue(state.penaltyApplied)

        state = WakeUpGameEngine.onGameBeaten(state, alarmStart.plusMinutes(40))
        assertTrue(state.penaltyApplied) // penalty is about being up in time, not about eventual success
    }
}
