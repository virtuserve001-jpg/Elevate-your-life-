package com.eyl.app.engine

import com.eyl.app.data.model.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class PointsEngineTest {

    private val date = LocalDate.of(2026, 7, 21)

    private fun mustTask(type: MustTaskType, status: TaskStatus) = Task(
        id = "${date}_${type.name}",
        date = date,
        category = TaskCategory.MUST,
        title = type.name,
        mustTaskType = type,
        durationMinutes = type.durationMinutesFor(date),
        lockdownMode = LockdownMode.NONE,
        status = status
    )

    private fun optionalTask(tier: ImportanceTier, status: TaskStatus, id: String = "opt-${tier}-$status") = Task(
        id = id,
        date = date,
        category = TaskCategory.OPTIONAL,
        title = "task",
        tier = tier,
        durationMinutes = 20,
        lockdownMode = LockdownMode.SINGLE_APP,
        status = status
    )

    private fun allMustTasksCompleted() = MustTaskType.values().map { mustTask(it, TaskStatus.COMPLETED) }

    @Test
    fun `gatekeeper zeroes the day when a single must-task is missed`() {
        val must = allMustTasksCompleted().toMutableList()
        // Flip just the last one to FAILED — everything else completed.
        must[must.lastIndex] = mustTask(MustTaskType.values().last(), TaskStatus.FAILED)

        val optional = listOf(optionalTask(ImportanceTier.IMPORTANT, TaskStatus.COMPLETED))

        val ledger = PointsEngine.calculateDay(date, must, optional, wakeUpState = null)

        assertEquals(0, ledger.finalPoints)
        assertFalse(ledger.mustTasksAllCompleted)
    }

    @Test
    fun `gatekeeper zeroes the day even if must-task is merely PENDING, not just FAILED`() {
        val must = allMustTasksCompleted().toMutableList()
        must[0] = mustTask(MustTaskType.values()[0], TaskStatus.PENDING)

        val ledger = PointsEngine.calculateDay(date, must, emptyList(), wakeUpState = null)

        assertEquals(0, ledger.finalPoints)
    }

    @Test
    fun `all must-tasks completed with no optional tasks yields zero but passes gatekeeper`() {
        val must = allMustTasksCompleted()
        val ledger = PointsEngine.calculateDay(date, must, emptyList(), wakeUpState = null)

        assertTrue(ledger.mustTasksAllCompleted)
        assertEquals(0, ledger.finalPoints)
    }

    @Test
    fun `important tier is worth more than less-important tier`() {
        val must = allMustTasksCompleted()
        val optional = listOf(
            optionalTask(ImportanceTier.IMPORTANT, TaskStatus.COMPLETED, id = "a"),
            optionalTask(ImportanceTier.LESS_IMPORTANT, TaskStatus.COMPLETED, id = "b")
        )
        val ledger = PointsEngine.calculateDay(date, must, optional, wakeUpState = null)

        val importantOnly = PointsEngine.calculateDay(
            date, must, listOf(optionalTask(ImportanceTier.IMPORTANT, TaskStatus.COMPLETED, id = "a")), null
        )
        val lessImportantOnly = PointsEngine.calculateDay(
            date, must, listOf(optionalTask(ImportanceTier.LESS_IMPORTANT, TaskStatus.COMPLETED, id = "b")), null
        )

        assertTrue(importantOnly.finalPoints > lessImportantOnly.finalPoints)
        assertEquals(importantOnly.finalPoints + lessImportantOnly.finalPoints, ledger.finalPoints)
    }

    @Test
    fun `incomplete optional tasks contribute zero points`() {
        val must = allMustTasksCompleted()
        val optional = listOf(optionalTask(ImportanceTier.IMPORTANT, TaskStatus.PENDING))
        val ledger = PointsEngine.calculateDay(date, must, optional, wakeUpState = null)

        assertEquals(0, ledger.finalPoints)
        assertTrue(ledger.mustTasksAllCompleted) // gatekeeper still passes, optional just didn't score
    }

    @Test
    fun `wake-up penalty reduces points but does not zero the day when must-tasks are complete`() {
        val must = allMustTasksCompleted()
        val optional = listOf(optionalTask(ImportanceTier.IMPORTANT, TaskStatus.COMPLETED))
        val wakeUpState = WakeUpGameState(
            date = date,
            alarmStartedAt = LocalTime.of(5, 0),
            penaltyApplied = true
        )

        val withPenalty = PointsEngine.calculateDay(date, must, optional, wakeUpState)
        val withoutPenalty = PointsEngine.calculateDay(date, must, optional, wakeUpState = null)

        assertTrue(withPenalty.finalPoints < withoutPenalty.finalPoints)
        assertTrue(withPenalty.mustTasksAllCompleted) // gatekeeper unaffected by wake-up penalty
        assertTrue(withPenalty.wakeUpPenaltyApplied)
    }

    @Test
    fun `wake-up penalty never pushes points below zero`() {
        val must = allMustTasksCompleted()
        // Very few optional points, far less than the flat penalty deduction.
        val optional = listOf(optionalTask(ImportanceTier.LESS_IMPORTANT, TaskStatus.COMPLETED))
        val wakeUpState = WakeUpGameState(date, LocalTime.of(5, 0), penaltyApplied = true)

        val ledger = PointsEngine.calculateDay(date, must, optional, wakeUpState)

        assertTrue(ledger.finalPoints >= 0)
    }

    @Test
    fun `gatekeeper failure is independent of and takes priority over wake-up penalty`() {
        val must = allMustTasksCompleted().toMutableList()
        must[0] = mustTask(MustTaskType.values()[0], TaskStatus.FAILED)
        val wakeUpState = WakeUpGameState(date, LocalTime.of(5, 0), penaltyApplied = true)

        val ledger = PointsEngine.calculateDay(date, must, emptyList(), wakeUpState)

        assertEquals(0, ledger.finalPoints)
        // The wake-up penalty is moot once the gatekeeper already zeroed the day.
        assertFalse(ledger.wakeUpPenaltyApplied)
    }
}
