package com.eyl.app.engine

import com.eyl.app.data.model.PointsLedger
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class AchievementEngineTest {

    private fun ledger(date: LocalDate, success: Boolean, points: Int = 10) = PointsLedger(
        date = date,
        mustTasksAllCompleted = success,
        rawOptionalPoints = points,
        wakeUpPenaltyApplied = false,
        finalPoints = if (success) points else 0
    )

    @Test
    fun `current streak counts consecutive successful days ending today`() {
        val today = LocalDate.of(2026, 7, 21)
        val ledgers = listOf(
            ledger(today, true),
            ledger(today.minusDays(1), true),
            ledger(today.minusDays(2), true),
            ledger(today.minusDays(3), false) // breaks it here
        )
        assertEquals(3, AchievementEngine.currentStreak(ledgers, today))
    }

    @Test
    fun `current streak is zero if today's gatekeeper failed`() {
        val today = LocalDate.of(2026, 7, 21)
        val ledgers = listOf(ledger(today, false), ledger(today.minusDays(1), true))
        assertEquals(0, AchievementEngine.currentStreak(ledgers, today))
    }

    @Test
    fun `current streak is zero if today has no ledger at all`() {
        val today = LocalDate.of(2026, 7, 21)
        val ledgers = listOf(ledger(today.minusDays(1), true))
        assertEquals(0, AchievementEngine.currentStreak(ledgers, today))
    }

    @Test
    fun `longest streak finds the best run even if it is not the most recent`() {
        val d0 = LocalDate.of(2026, 7, 1)
        val ledgers = (0..9).map { i ->
            // Days 0-4 succeed (5-day streak), day 5 fails, days 6-7 succeed (2-day streak)
            ledger(d0.plusDays(i.toLong()), success = i in 0..4 || i in 6..7)
        }
        assertEquals(5, AchievementEngine.longestStreak(ledgers))
    }

    @Test
    fun `non-consecutive dates do not chain even if both are successes`() {
        val d0 = LocalDate.of(2026, 7, 1)
        val ledgers = listOf(
            ledger(d0, true),
            ledger(d0.plusDays(5), true) // gap — not consecutive
        )
        assertEquals(1, AchievementEngine.longestStreak(ledgers))
    }

    @Test
    fun `achievements unlock only at or below the longest streak reached`() {
        val d0 = LocalDate.of(2026, 7, 1)
        val ledgers = (0 until 7).map { i -> ledger(d0.plusDays(i.toLong()), true) }
        val unlocked = AchievementEngine.unlockedAchievements(ledgers)
        val ids = unlocked.map { it.id }
        assertTrue("3-day badge should unlock", ids.contains("streak_3"))
        assertTrue("7-day badge should unlock", ids.contains("streak_7"))
        assertFalse("14-day badge should NOT unlock yet", ids.contains("streak_14"))
    }

    @Test
    fun `total points ever sums only what was actually earned`() {
        val d0 = LocalDate.of(2026, 7, 1)
        val ledgers = listOf(
            ledger(d0, true, points = 20),
            ledger(d0.plusDays(1), false, points = 999), // gatekeeper failed -> finalPoints is 0 regardless
            ledger(d0.plusDays(2), true, points = 15)
        )
        assertEquals(35, AchievementEngine.totalPointsEver(ledgers))
    }
}
