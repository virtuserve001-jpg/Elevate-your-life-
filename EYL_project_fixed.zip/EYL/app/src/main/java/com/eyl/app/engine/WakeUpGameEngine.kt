package com.eyl.app.engine

import com.eyl.app.data.model.WakeUpGameState
import java.time.LocalDate
import java.time.LocalTime

/**
 * Drives the wake-up game's difficulty curve and penalty trigger.
 *
 * Locked rules:
 * - No ceiling on the alarm itself — caller keeps re-presenting the game
 *   until beaten, no matter how long that takes.
 * - Difficulty escalates by 1 level per failed attempt, and never resets
 *   down mid-session (a fresh alarm the next day starts back at level 1).
 * - Failing an attempt costs nothing directly.
 * - If 30 minutes pass from alarmStartedAt without the game being beaten,
 *   mark the penalty as applied (PointsEngine picks this up). The alarm
 *   keeps ringing regardless — the penalty is independent of dismissal.
 *
 * This class is pure logic; wiring it to an actual AlarmManager + a
 * full-screen Activity that hosts the minigame is a separate concern
 * (see AlarmGameActivity, not yet built).
 */
object WakeUpGameEngine {

    fun start(date: LocalDate, alarmStartedAt: LocalTime): WakeUpGameState {
        return WakeUpGameState(
            date = date,
            alarmStartedAt = alarmStartedAt,
            attempts = 0,
            currentDifficultyLevel = 1
        )
    }

    /**
     * Call this whenever the user fails a round of the minigame.
     * Difficulty only ever goes up.
     */
    fun onAttemptFailed(state: WakeUpGameState): WakeUpGameState {
        return state.copy(
            attempts = state.attempts + 1,
            currentDifficultyLevel = state.currentDifficultyLevel + 1
        )
    }

    /**
     * Call this when the user actually beats the minigame — this is what
     * silences the alarm. Does NOT retroactively remove a penalty that
     * already triggered; the penalty is about whether you were up in time,
     * not about whether you eventually succeeded.
     */
    fun onGameBeaten(state: WakeUpGameState, beatenAt: LocalTime): WakeUpGameState {
        return state.copy(beatenAt = beatenAt)
    }

    /**
     * Call this periodically (e.g. every tick of a foreground alarm service)
     * to check whether the 30-min limit has just been crossed. Returns an
     * updated state with penaltyApplied = true the first time this fires;
     * safe to call repeatedly afterwards (idempotent).
     */
    fun checkPenalty(state: WakeUpGameState, now: LocalTime): WakeUpGameState {
        if (state.penaltyApplied || state.beatenAt != null) return state
        return if (state.isPastLimit(now)) {
            state.copy(penaltyApplied = true)
        } else {
            state
        }
    }

    /**
     * Difficulty level translates into concrete game parameters here.
     * Example for a simple reaction/pattern game — adjust to whatever
     * minigame you actually build (math problems, pattern match, shake
     * sequence, etc.). Keeping this centralized means the "gets harder"
     * rule is defined in exactly one place.
     */
    fun paramsForLevel(level: Int): GameParams {
        return GameParams(
            targetSequenceLength = (3 + level).coerceAtMost(12),
            timeLimitSeconds = (20 - level).coerceAtLeast(6),
            distractionsEnabled = level >= 3
        )
    }

    data class GameParams(
        val targetSequenceLength: Int,
        val timeLimitSeconds: Int,
        val distractionsEnabled: Boolean
    )
}
