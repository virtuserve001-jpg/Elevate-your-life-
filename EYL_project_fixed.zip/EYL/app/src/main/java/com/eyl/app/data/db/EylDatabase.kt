package com.eyl.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.eyl.app.data.model.PointsLedger
import com.eyl.app.data.model.SpendAllocation
import com.eyl.app.data.model.Task
import com.eyl.app.data.model.TaskTemplate
import com.eyl.app.data.model.WakeUpGameState

@Database(
    entities = [Task::class, PointsLedger::class, WakeUpGameState::class, SpendAllocation::class, TaskTemplate::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class EylDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun pointsLedgerDao(): PointsLedgerDao
    abstract fun wakeUpGameStateDao(): WakeUpGameStateDao
    abstract fun spendAllocationDao(): SpendAllocationDao
    abstract fun taskTemplateDao(): TaskTemplateDao

    companion object {
        @Volatile private var instance: EylDatabase? = null

        fun getInstance(context: Context): EylDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    EylDatabase::class.java,
                    "eyl.db"
                )
                    // No destructive fallback in production once this ships —
                    // for v1 development only, remove before real users have data.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
        }
    }
}
