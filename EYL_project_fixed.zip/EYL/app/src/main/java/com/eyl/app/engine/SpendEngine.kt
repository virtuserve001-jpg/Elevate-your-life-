package com.eyl.app.engine

/**
 * Converts spent points into concrete budgets. Two currencies are
 * genuinely enforceable by a normal (non-Device-Owner) Android app using
 * the same accessibility-service mechanism already built for task
 * lockdown; one currency is not, and that's stated plainly rather than
 * building UI that implies otherwise.
 *
 * WHY MOBILE DATA CAN'T BE ENFORCED HERE:
 * Per-app mobile data throttling on Android requires either:
 *  (a) Device Owner / Profile Owner provisioning via DevicePolicyManager,
 *      which needs a deliberate enrollment flow (factory reset + QR/NFC
 *      provisioning) — the same heavy path already ruled out for lockdown
 *      in the original spec conversation, or
 *  (b) A VPN-based traffic filter (using VpnService to route all traffic
 *      through a local filter), which is invasive, battery-costly on a
 *      low-end device, and functionally routes ALL the user's traffic
 *      through the app — a big ask for what's meant to be a personal
 *      discipline tool, not a parental-control/MDM product.
 * Given that, mobileDataPointsSpent is tracked and shown to the user
 * (so the currency isn't silently useless — it's an honest "budget you're
 * holding yourself to"), but EYL does not and cannot technically block
 * data usage once that budget hits zero. If real enforcement matters to
 * you later, (b) is the more realistic of the two paths, but it's a
 * significant scope increase — worth a deliberate decision, not a
 * silent addition.
 */
object SpendEngine {

    // 1 point = 5 minutes of screen time budget (non-EYL apps).
    const val MINUTES_PER_POINT_SCREEN_TIME = 5

    // Flat cost to unlock one self-designated "restricted" app for the day.
    const val POINTS_PER_APP_UNLOCK = 10

    // Purely informational — see class doc. Not enforced.
    const val MB_PER_POINT_MOBILE_DATA = 50

    fun screenTimeBudgetMinutes(pointsSpent: Int): Int = pointsSpent * MINUTES_PER_POINT_SCREEN_TIME

    fun maxAppUnlocksFor(pointsSpent: Int): Int = pointsSpent / POINTS_PER_APP_UNLOCK

    fun mobileDataBudgetMb(pointsSpent: Int): Int = pointsSpent * MB_PER_POINT_MOBILE_DATA
}
