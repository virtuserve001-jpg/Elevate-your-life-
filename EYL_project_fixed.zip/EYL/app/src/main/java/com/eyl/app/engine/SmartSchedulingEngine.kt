package com.eyl.app.engine

import com.eyl.app.data.model.ImportanceTier
import com.eyl.app.data.model.MustTaskType
import com.eyl.app.data.model.Task
import com.eyl.app.data.model.TaskStatus
import java.time.LocalDate

/**
 * Milestone 4 — "smart scheduling."
 *
 * IMPORTANT SCOPE NOTE: this is a lightweight heuristic, not a real
 * calendar-aware AI scheduler. There is no notion of clock time in the
 * Task data model (only durationMinutes), no calendar integration, and
 * no learning from past behavior. What this DOES do: given today's
 * must-tasks (fixed, un-movable) and a set of pending optional tasks,
 * it suggests a sensible ORDER to tackle the optional tasks in — not a
 * schedule of clock times. Building genuine time-slot scheduling would
 * require adding scheduled-time fields to Task and real calendar
 * awareness — a bigger, separate feature, flagged here rather than
 * quietly under-delivered.
 *
 * Heuristic used: Important-tier tasks first, then within each tier,
 * shorter tasks before longer ones (a "quick wins first" ordering that
 * tends to build momentum and reduces the chance a long task eats the
 * whole remaining day before shorter important ones get attention).
 */
object SmartSchedulingEngine {

    fun suggestedOrder(pendingOptionalTasks: List<Task>): List<Task> {
        return pendingOptionalTasks
            .filter { it.status == TaskStatus.PENDING }
            .sortedWith(
                compareByDescending<Task> { it.tier == ImportanceTier.IMPORTANT }
                    .thenBy { it.durationMinutes }
            )
    }

    /**
     * Rough estimate of how many free minutes remain in the day once
     * today's must-tasks are accounted for. Uses a 16-hour "reasonably
     * awake" window (not a full 24h) as a simplifying assumption, since
     * sleep isn't otherwise modeled. This is a ballpark, not a precise
     * calendar calculation — intentionally so, given the scope note above.
     */
    fun estimatedFreeMinutesToday(mustTasks: List<Task>, date: LocalDate): Int {
        val awakeMinutes = 16 * 60
        val mustTaskMinutes = mustTasks.sumOf {
            it.mustTaskType?.durationMinutesFor(date) ?: it.durationMinutes
        }
        return (awakeMinutes - mustTaskMinutes).coerceAtLeast(0)
    }
}
