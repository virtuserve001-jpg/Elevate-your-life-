package com.eyl.app.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.eyl.app.R

/**
 * Milestone 2 — a real app picker with search and icons, used whenever a
 * task's lockdown mode is "Allowed apps". Replaces the old comma-separated
 * package-name text field, which required the user to know exact package
 * IDs by heart.
 *
 * Returns the selected package names as a String array extra
 * (EXTRA_SELECTED_PACKAGES) via setResult, for the caller (MainActivity's
 * add/edit-task dialog) to read in onActivityResult / the Activity Result API.
 */
class AppPickerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PRESELECTED_PACKAGES = "extra_preselected_packages"
        const val EXTRA_SELECTED_PACKAGES = "extra_selected_packages"
    }

    private data class AppEntry(
        val packageName: String,
        val label: String,
        val icon: Drawable
    )

    private lateinit var allApps: List<AppEntry>
    private val selected = mutableSetOf<String>()
    private lateinit var adapter: AppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_picker)

        val preselected = intent.getStringArrayExtra(EXTRA_PRESELECTED_PACKAGES)?.toSet() ?: emptySet()
        selected.addAll(preselected)

        allApps = loadInstalledApps()

        val recycler = findViewById<RecyclerView>(R.id.recyclerApps)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = AppAdapter(allApps)
        recycler.adapter = adapter

        findViewById<EditText>(R.id.editSearch).addTextChangedListener(afterTextChanged = { text ->
            adapter.filter(text?.toString().orEmpty())
        })

        findViewById<Button>(R.id.buttonConfirmSelection).setOnClickListener {
            val result = Intent().putExtra(EXTRA_SELECTED_PACKAGES, selected.toTypedArray())
            setResult(RESULT_OK, result)
            finish()
        }
    }

    /**
     * Only lists apps with a launcher entry point (i.e. things the user
     * could actually open themselves) — excludes system services and
     * background-only packages that would just clutter the list.
     */
    private fun loadInstalledApps(): List<AppEntry> {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = pm.queryIntentActivities(launcherIntent, 0)

        return resolveInfos
            .mapNotNull { resolveInfo ->
                try {
                    val appInfo: ApplicationInfo = resolveInfo.activityInfo.applicationInfo
                    AppEntry(
                        packageName = appInfo.packageName,
                        label = pm.getApplicationLabel(appInfo).toString(),
                        icon = pm.getApplicationIcon(appInfo)
                    )
                } catch (e: Exception) {
                    null // some OEM system entries throw on icon lookup — skip rather than crash the picker
                }
            }
            .filter { it.packageName != packageName } // no point letting the user whitelist EYL itself, it's always allowed
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private inner class AppAdapter(private val fullList: List<AppEntry>) :
        RecyclerView.Adapter<AppAdapter.ViewHolder>() {

        private var shown: List<AppEntry> = fullList

        fun filter(query: String) {
            shown = if (query.isBlank()) fullList
            else fullList.filter { it.label.contains(query, ignoreCase = true) }
            notifyDataSetChanged()
        }

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.imageAppIcon)
            val name: TextView = view.findViewById(R.id.textAppName)
            val checkbox: CheckBox = view.findViewById(R.id.checkAppSelected)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val entry = shown[position]
            holder.icon.setImageDrawable(entry.icon)
            holder.name.text = entry.label
            // Clear listener before setting checked state to avoid triggering
            // it during recycled-view rebind (a common RecyclerView checkbox bug).
            holder.checkbox.setOnCheckedChangeListener(null)
            holder.checkbox.isChecked = entry.packageName in selected
            holder.checkbox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selected.add(entry.packageName) else selected.remove(entry.packageName)
            }
            holder.itemView.setOnClickListener { holder.checkbox.toggle() }
        }

        override fun getItemCount(): Int = shown.size
    }
}

/** Small helper so we can use the concise `addTextChangedListener { }` style without an extra library. */
private fun EditText.addTextChangedListener(afterTextChanged: (CharSequence?) -> Unit) {
    this.addTextChangedListener(object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: android.text.Editable?) = afterTextChanged(s?.toString())
    })
}
