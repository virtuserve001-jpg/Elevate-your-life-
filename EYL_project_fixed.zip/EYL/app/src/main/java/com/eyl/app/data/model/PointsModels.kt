package com.eyl.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalTime

/**
 * Tracks the state of the mandatory wake-up game tied to the alarm.
 *
 * Rules locked in:
 * - No ceiling on the alarm itself; it keeps ringing until the game is beaten.
 * - Difficulty escalates with every failed attempt (never resets down).
 * - A failed attempt costs nothing by itself.
 * - BUT there is a 30-minute limit measured from alarmStartedAt. If the game
 *   still isn't beaten by then, the day's points take a penalty (this is
 *   separate from, and less severe than, the MUST-task gatekeeper zeroing).
 */
@Entity(tableName = "wake_up_game_state")
data class WakeUpGameState(
    @PrimaryKey val date: LocalDate,
    val alarmStartedAt: LocalTime,
    val attempts: Int = 0,
    val currentDifficultyLevel: Int = 1, // increments by 1 per failed attempt, never decreases
    val beatenAt: LocalTime? = null,
    val penaltyApplied: Boolean = false
) {
    companion object {
        const val TIME_LIMIT_MINUTES = 30
    }

    fun minutesSinceAlarmStart(now: LocalTime): Long {
        return java.time.Duration.between(alarmStartedAt, now).toMinutes()
    }

    fun isPastLimit(now: LocalTime): Boolean {
        return beatenAt == null && minutesSinceAlarmStart(now) >= TIME_LIMIT_MINUTES
    }
}

/**
 * One day's point ledger. This is the output of PointsEngine.calculateDay(),
 * not something tasks write to directly.
 */
@Entity(tableName = "points_ledger")
data class PointsLedger(
    @PrimaryKey val date: LocalDate,
    val mustTasksAllCompleted: Boolean,
    val rawOptionalPoints: Int,       // sum of tier-based points before gatekeeper/penalties
    val wakeUpPenaltyApplied: Boolean,
    val finalPoints: Int,             // what actually gets banked / spendable next day
    val breakdown: List<String> = emptyList() // human-readable reasons, for transparency in UI
)

/**
 * The single spendable pool, and how a user allocates it the next day.
 *
 * Enforcement honesty check (see SpendEngine / LockdownAccessibilityService
 * for where this actually gets enforced):
 * - screenTimePointsSpent -> genuinely enforced, via a daily foreground-time
 *   budget the accessibility service tracks and cuts off.
 * - appUnlockPointsSpent -> genuinely enforced: unlockedPackages lists which
 *   of the user's self-designated "restricted" apps are allowed today.
 * - mobileDataPointsSpent -> NOT enforced. Actually throttling mobile data
 *   per-app requires Device Owner provisioning (same heavy MDM path we
 *   ruled out for lockdown). This field is tracked/displayed only — see
 *   SpendEngine's doc comment for the full explanation. Don't build UI
 *   that implies this currency does something it doesn't.
 */
@Entity(tableName = "spend_allocation")
data class SpendAllocation(
    @PrimaryKey val date: LocalDate,
    val pointsAvailable: Int,
    val screenTimePointsSpent: Int = 0,
    val mobileDataPointsSpent: Int = 0,
    val appUnlockPointsSpent: Int = 0,
    val unlockedPackages: List<String> = emptyList()
) {
    val pointsRemaining: Int
        get() = pointsAvailable - screenTimePointsSpent - mobileDataPointsSpent - appUnlockPointsSpent

    init {
        require(pointsRemaining >= 0) { "Cannot allocate more points than available" }
    }
}
