package com.eyl.app.engine

import android.content.Context
import java.time.LocalDate

/**
 * Backs the day-wide (not task-specific) enforcement: the screen-time
 * budget and the restricted-apps unlock list, both funded by spent
 * points via SpendEngine. Separate from task lockdown, which is scoped
 * to a single running task and handled by TaskTimerManager instead.
 *
 * Uses SharedPreferences rather than Room because this is a small set of
 * frequently-read, rarely-written values (checked on every foreground-app
 * switch) rather than relational data — cheaper on a low-RAM device than
 * spinning up a Room query per accessibility event.
 */
class DayWideRestrictionStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("eyl_day_wide_restrictions", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_RESTRICTED_PACKAGES = "restricted_packages"
        private const val KEY_BUDGET_DATE = "budget_date"
        private const val KEY_BUDGET_MINUTES = "budget_minutes"
        private const val KEY_USED_SECONDS = "used_seconds"
        private const val KEY_UNLOCKED_PACKAGES = "unlocked_packages"
    }

    /** User-designated apps that are blocked by default unless unlocked with points. Persists across days. */
    fun getRestrictedPackages(): Set<String> =
        prefs.getStringSet(KEY_RESTRICTED_PACKAGES, emptySet()) ?: emptySet()

    fun setRestrictedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_RESTRICTED_PACKAGES, packages).apply()
    }

    /**
     * Call once per day (e.g. from DailyRolloverWorker, or lazily on first
     * check of the day) with the new budget derived from yesterday's spend.
     * Resets the used-time counter and unlocked-packages list for the new day.
     */
    fun startNewDay(date: LocalDate, budgetMinutes: Int, unlockedPackages: Set<String>) {
        prefs.edit()
            .putString(KEY_BUDGET_DATE, date.toString())
            .putInt(KEY_BUDGET_MINUTES, budgetMinutes)
            .putInt(KEY_USED_SECONDS, 0)
            .putStringSet(KEY_UNLOCKED_PACKAGES, unlockedPackages)
            .apply()
    }

    /** True if startNewDay() hasn't been called yet for today — caller should treat budget as 0/unset. */
    fun isStale(today: LocalDate): Boolean = prefs.getString(KEY_BUDGET_DATE, null) != today.toString()

    fun getBudgetMinutes(): Int = prefs.getInt(KEY_BUDGET_MINUTES, 0)

    fun getUsedSeconds(): Int = prefs.getInt(KEY_USED_SECONDS, 0)

    fun addUsedSeconds(seconds: Int) {
        prefs.edit().putInt(KEY_USED_SECONDS, getUsedSeconds() + seconds).apply()
    }

    fun isBudgetExhausted(): Boolean = getUsedSeconds() >= getBudgetMinutes() * 60

    fun getUnlockedPackages(): Set<String> =
        prefs.getStringSet(KEY_UNLOCKED_PACKAGES, emptySet()) ?: emptySet()
}
