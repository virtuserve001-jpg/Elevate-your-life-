package com.eyl.app.ui

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.engine.AchievementEngine
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Milestone 4 — weekly discipline analytics, streaks, and achievements.
 * Deliberately no external charting library: a manual proportional-width
 * bar per day is enough for a 7-day view and keeps the app's footprint
 * small on a low-RAM target device.
 */
class AnalyticsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)
        val app = application as EylApplication

        lifecycleScope.launch {
            val ledgers = app.repository.getRecentLedgers(days = 30)
            val today = LocalDate.now()

            val currentStreak = AchievementEngine.currentStreak(ledgers, today)
            val longestStreak = AchievementEngine.longestStreak(ledgers)
            val totalPoints = AchievementEngine.totalPointsEver(ledgers)

            findViewById<TextView>(R.id.textCurrentStreak).text = "🔥 $currentStreak day streak"
            findViewById<TextView>(R.id.textLongestStreak).text = "Longest ever: $longestStreak days"
            findViewById<TextView>(R.id.textTotalPoints).text = "Lifetime points: $totalPoints"

            renderWeekBars(ledgers, today)
            renderAchievements(ledgers)
        }
    }

    private fun renderWeekBars(ledgers: List<com.eyl.app.data.model.PointsLedger>, today: LocalDate) {
        val container = findViewById<LinearLayout>(R.id.containerWeekBars)
        container.removeAllViews()

        val byDate = ledgers.associateBy { it.date }
        val last7 = (6 downTo 0).map { today.minusDays(it.toLong()) }
        val maxPoints = last7.mapNotNull { byDate[it]?.finalPoints }.maxOrNull()?.coerceAtLeast(1) ?: 1
        val formatter = DateTimeFormatter.ofPattern("EEE")

        last7.forEach { date ->
            val points = byDate[date]?.finalPoints ?: 0
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = 6 }
            }
            val label = TextView(this).apply {
                text = date.format(formatter)
                layoutParams = LinearLayout.LayoutParams(80, LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            val barContainer = LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, 24, 1f)
                setBackgroundColor(0xFFEDEDED.toInt())
            }
            val bar = android.view.View(this).apply {
                val widthFraction = points.toFloat() / maxPoints.toFloat()
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, widthFraction.coerceIn(0.02f, 1f))
                setBackgroundColor(0xFFC9A24B.toInt())
            }
            val spacer = android.view.View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, (1f - widthFractionSafe(points, maxPoints)))
            }
            barContainer.addView(bar)
            barContainer.addView(spacer)
            val pointsLabel = TextView(this).apply {
                text = " $points"
                layoutParams = LinearLayout.LayoutParams(60, LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            row.addView(label)
            row.addView(barContainer)
            row.addView(pointsLabel)
            container.addView(row)
        }
    }

    private fun widthFractionSafe(points: Int, max: Int): Float =
        (points.toFloat() / max.toFloat()).coerceIn(0.02f, 1f)

    private fun renderAchievements(ledgers: List<com.eyl.app.data.model.PointsLedger>) {
        val container = findViewById<LinearLayout>(R.id.containerAchievements)
        container.removeAllViews()
        val achievements = AchievementEngine.unlockedAchievements(ledgers)

        if (achievements.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "No achievements unlocked yet — build a streak to earn your first badge."
                setTextColor(0xFF888888.toInt())
            })
            return
        }

        achievements.forEach { achievement ->
            container.addView(TextView(this).apply {
                text = "🏅 ${achievement.title} — ${achievement.description}"
                setPadding(0, 8, 0, 8)
            })
        }
    }
}
