package com.eyl.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.R
import com.eyl.app.engine.TaskTimerManager
import com.eyl.app.service.LockdownForegroundService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Two jobs in one Activity:
 * 1. Normal path: shown right after the user taps "Start" on a task —
 *    displays the live countdown by observing the foreground service's
 *    eventFlow.
 * 2. Bounce-back path: LockdownAccessibilityService relaunches this
 *    Activity (with FLAG_ACTIVITY_CLEAR_TOP) whenever it catches a
 *    disallowed app trying to come to the foreground during an active
 *    lockdown — so from the user's perspective, trying to escape just
 *    snaps them right back here instead of ever seeing the other app.
 */
class TaskLockdownActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
    }

    private lateinit var textCountdown: TextView
    private lateinit var textTitle: TextView
    private lateinit var textMessage: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_lockdown)
        textCountdown = findViewById(R.id.textCountdown)
        textTitle = findViewById(R.id.textLockdownTitle)
        textMessage = findViewById(R.id.textLockdownMessage)

        handleIntent(intent)
        observeEvents()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val blockedAttempt = intent?.getStringExtra("blocked_package_attempted")
        if (blockedAttempt != null) {
            textMessage.text = "That app is off-limits until this task's timer finishes."
        }
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            // The service instance may not exist yet on the very first
            // frame (race with startForegroundService); poll briefly.
            var service = LockdownForegroundService.instance
            var attempts = 0
            while (service == null && attempts < 20) {
                kotlinx.coroutines.delay(50)
                service = LockdownForegroundService.instance
                attempts++
            }
            service?.eventFlow?.collectLatest { event ->
                when (event) {
                    is TaskTimerManager.TimerEvent.Tick -> {
                        val m = event.secondsRemaining / 60
                        val s = event.secondsRemaining % 60
                        textCountdown.text = String.format("%02d:%02d", m, s)
                    }
                    is TaskTimerManager.TimerEvent.Completed -> {
                        textTitle.text = "Task complete"
                        textCountdown.text = "✅"
                        textMessage.text = "Nicely done. You can leave this screen now."
                    }
                    is TaskTimerManager.TimerEvent.Failed -> {
                        textTitle.text = "Task failed"
                        textCountdown.text = "❌"
                        textMessage.text = event.reason
                    }
                    null -> {}
                }
            }
        }
    }
}
