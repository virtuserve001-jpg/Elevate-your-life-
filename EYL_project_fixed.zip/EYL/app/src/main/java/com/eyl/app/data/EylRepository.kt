package com.eyl.app.data

import com.eyl.app.data.db.EylDatabase
import com.eyl.app.data.model.*
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/**
 * Thin wrapper over the DAOs. Exists so TaskTimerManager / UI ViewModels
 * don't reach into EylDatabase directly, and so we have one place to add
 * caching later if the low-end target device needs it.
 */
class EylRepository(private val db: EylDatabase) {

    // --- Tasks ---
    suspend fun getTask(id: String): Task? = db.taskDao().getById(id)

    suspend fun getMustTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.MUST)

    suspend fun getOptionalTasksForDate(date: LocalDate): List<Task> =
        db.taskDao().getTasksForDate(date, TaskCategory.OPTIONAL)

    fun observeTasksForDate(date: LocalDate) = db.taskDao().observeTasksForDate(date)

    suspend fun saveTask(task: Task) = db.taskDao().upsert(task)

    /**
     * Generates the day's MUST tasks from MustTaskType if they don't
     * already exist. Idempotent — safe to call on every app open.
     *
     * readingAppPackages: the user's saved reading-app choice(s), from
     * ReadingAppPreference. If empty (never chosen), READ_TWO_HOURS falls
     * back to SINGLE_APP (only EYL reachable) so behavior stays sane
     * before a choice has been made.
     */
    suspend fun ensureMustTasksExist(date: LocalDate, readingAppPackages: List<String> = emptyList()) {
        val existing = getMustTasksForDate(date)
        val existingTypes = existing.mapNotNull { it.mustTaskType }.toSet()

        val toCreate = MustTaskType.values()
            .filter { it !in existingTypes }
            .map { type ->
                val useWhitelist = type == MustTaskType.READ_TWO_HOURS && readingAppPackages.isNotEmpty()
                Task(
                    id = "${date}_${type.name}",
                    date = date,
                    category = TaskCategory.MUST,
                    title = type.name.lowercase().replace('_', ' '),
                    mustTaskType = type,
                    durationMinutes = type.durationMinutesFor(date),
                    // Milestone 1 change: ALL must-tasks (prayers, adhkar,
                    // tahajud, the 2hr read) now trap the user inside EYL
                    // via SINGLE_APP lockdown for the full duration, rather
                    // than the old "phone must stay untouched" check. This
                    // is a deliberate reversal from the original design —
                    // the phone-untouched approach failed tasks the moment
                    // the screen turned on at all, which proved too harsh/
                    // unreliable in practice. Being trapped inside EYL with
                    // a visible countdown is the new intended behavior.
                    //
                    // Milestone 3 fix: reading specifically uses WHITELIST
                    // with the user's chosen app(s) once set, instead of
                    // being locked to EYL only — the app picker was being
                    // built but never actually wired into enforcement.
                    lockdownMode = if (useWhitelist) LockdownMode.WHITELIST else LockdownMode.SINGLE_APP,
                    whitelistedPackages = if (useWhitelist) readingAppPackages else emptyList()
                )
            }

        if (toCreate.isNotEmpty()) db.taskDao().upsertAll(toCreate)
    }

    /**
     * Milestone 3 fix: resolves any task stuck at IN_PROGRESS whose
     * scheduled end time has already passed. This happens when the
     * foreground service running the countdown gets killed by the OS
     * (common on aggressive battery-management devices) before it can
     * mark the task COMPLETED itself — without this check, such a task
     * stays "running" forever.
     *
     * Marked FAILED rather than COMPLETED: since the coroutine died,
     * there's no way to confirm lockdown stayed active for the whole
     * duration, and the app's own stated philosophy elsewhere is that an
     * interruption to enforcement counts as a failure, not a free pass.
     */
    suspend fun reconcileOrphanedTasks(date: LocalDate) {
        val tasks = getMustTasksForDate(date) + getOptionalTasksForDate(date)
        val now = java.time.LocalDateTime.now()

        tasks.filter { it.status == TaskStatus.IN_PROGRESS && it.startedAt != null }
            .forEach { task ->
                val expectedEnd = date.atTime(task.startedAt).plusMinutes(task.durationMinutes.toLong())
                if (now.isAfter(expectedEnd)) {
                    saveTask(task.copy(status = TaskStatus.FAILED, lockdownBroken = true))
                }
            }
    }

    // --- Points / wake-up / spend ---
    suspend fun getLedger(date: LocalDate): PointsLedger? = db.pointsLedgerDao().getForDate(date)
    suspend fun saveLedger(ledger: PointsLedger) = db.pointsLedgerDao().upsert(ledger)

    /** Most recent N days of ledgers, used by the Milestone 4 analytics screen. */
    suspend fun getRecentLedgers(days: Int = 30): List<PointsLedger> =
        db.pointsLedgerDao().observeRecent(days).first()

    suspend fun getWakeUpState(date: LocalDate): WakeUpGameState? = db.wakeUpGameStateDao().getForDate(date)
    suspend fun saveWakeUpState(state: WakeUpGameState) = db.wakeUpGameStateDao().upsert(state)

    suspend fun getSpendAllocation(date: LocalDate): SpendAllocation? = db.spendAllocationDao().getForDate(date)
    suspend fun saveSpendAllocation(allocation: SpendAllocation) = db.spendAllocationDao().upsert(allocation)

    /**
     * Points spendable on `date` come from the PREVIOUS day's finalized
     * ledger — you're spending what you earned yesterday, not today's
     * still-in-progress total (which wouldn't be final until midnight
     * anyway, per the gatekeeper rule potentially zeroing it retroactively).
     */
    suspend fun getSpendablePoints(date: LocalDate): Int =
        getLedger(date.minusDays(1))?.finalPoints ?: 0

    // --- Milestone 2: templates, duplication, editing ---

    fun observeTemplates() = db.taskTemplateDao().observeAll()
    suspend fun getTemplates(): List<TaskTemplate> = db.taskTemplateDao().getAll()
    suspend fun saveTemplate(template: TaskTemplate) = db.taskTemplateDao().upsert(template)
    suspend fun deleteTemplate(template: TaskTemplate) = db.taskTemplateDao().delete(template)

    /** Instantiates a saved template into a new OPTIONAL task for the given date. */
    suspend fun createTaskFromTemplate(template: TaskTemplate, date: LocalDate): Task {
        val task = Task(
            id = java.util.UUID.randomUUID().toString(),
            date = date,
            category = TaskCategory.OPTIONAL,
            title = template.title,
            tier = template.tier,
            durationMinutes = template.durationMinutes,
            lockdownMode = template.lockdownMode,
            whitelistedPackages = template.whitelistedPackages
        )
        saveTask(task)
        return task
    }

    /** Clones an existing task as a brand-new PENDING task for today — same
     *  title/tier/duration/lockdown, fresh id and status, no completion history. */
    suspend fun duplicateTask(source: Task, date: LocalDate = source.date): Task {
        val copy = Task(
            id = java.util.UUID.randomUUID().toString(),
            date = date,
            category = source.category,
            title = source.title,
            mustTaskType = null, // duplicates are always optional-style, even if cloned from a must-task's shape
            tier = source.tier ?: ImportanceTier.LESS_IMPORTANT,
            durationMinutes = source.durationMinutes,
            lockdownMode = source.lockdownMode,
            whitelistedPackages = source.whitelistedPackages
        )
        saveTask(copy.copy(category = TaskCategory.OPTIONAL))
        return copy
    }

    // --- Milestone 4: full data export/import (local backup, not cloud sync — see BackupEngine) ---

    suspend fun getAllTasksEver(): List<Task> = db.taskDao().getAllTasks()
    suspend fun getAllLedgersEver(): List<PointsLedger> = db.pointsLedgerDao().getAll()

    /** Wipes and replaces all local data with an imported backup. Destructive by design — call only after explicit user confirmation. */
    suspend fun restoreFromBackup(tasks: List<Task>, ledgers: List<PointsLedger>, templates: List<TaskTemplate>) {
        tasks.forEach { saveTask(it) }
        ledgers.forEach { saveLedger(it) }
        templates.forEach { saveTemplate(it) }
    }
}
