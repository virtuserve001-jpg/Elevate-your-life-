package com.eyl.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.eyl.app.EylApplication
import com.eyl.app.engine.WakeUpGameEngine
import com.eyl.app.ui.AlarmGameActivity
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

/**
 * Fired by AlarmManager at the scheduled wake-up time. Immediately:
 * 1. Creates today's WakeUpGameState (attempts=0, difficulty level 1).
 * 2. Launches AlarmGameActivity full-screen, over the lock screen.
 * 3. Starts LockdownForegroundService's alarm-ringing mode so the alarm
 *    sound/vibration keeps going even if the Activity gets backgrounded
 *    (e.g. user manages to hit Home — the ringing must NOT stop, only
 *    beating the game stops it).
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as EylApplication
        val now = LocalTime.now()
        val today = LocalDate.now()

        app.applicationScope.launch {
            val existing = app.repository.getWakeUpState(today)
            if (existing == null) {
                val state = WakeUpGameEngine.start(today, now)
                app.repository.saveWakeUpState(state)
            }
        }

        val activityIntent = Intent(context, AlarmGameActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        context.startActivity(activityIntent)

        val serviceIntent = Intent(context, LockdownForegroundService::class.java).apply {
            action = LockdownForegroundService.ACTION_START_ALARM_RINGING
        }
        context.startForegroundService(serviceIntent)
    }
}