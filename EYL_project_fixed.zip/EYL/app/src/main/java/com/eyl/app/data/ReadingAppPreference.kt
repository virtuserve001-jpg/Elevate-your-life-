package com.eyl.app.data

import android.content.Context

/**
 * Persists which app(s) the user picked as allowed during the daily
 * 2-hour reading task. Stored separately from the Task itself because
 * READ_TWO_HOURS is regenerated fresh every day by
 * EylRepository.ensureMustTasksExist — the chosen app is a standing
 * preference, not a per-day value.
 */
object ReadingAppPreference {
    private const val PREFS_NAME = "eyl_prefs"
    private const val KEY_PACKAGES = "reading_app_packages"

    fun get(context: Context): List<String> {
        val stored = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PACKAGES, null) ?: return emptyList()
        return stored.split(",").filter { it.isNotBlank() }
    }

    fun set(context: Context, packages: List<String>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PACKAGES, packages.joinToString(","))
            .apply()
    }
}
