package com.eyl.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalTime

/**
 * The two categories of task in EYL.
 *
 * MUST tasks are non-negotiable and trigger the gatekeeper rule:
 * missing even one zeroes the entire day's points.
 *
 * OPTIONAL tasks are user-defined and placed into an importance Tier
 * by the user, but the point VALUE of each tier is fixed by the app,
 * not chosen by the user (prevents self-inflation of points).
 */
enum class TaskCategory {
    MUST,
    OPTIONAL
}

/**
 * The specific "must" tasks that always exist in every user's day.
 * Prayer durations are fixed and non-adjustable by the user.
 * Friday Dhuhr is the one variable-duration exception (khutbah + prayer).
 */
enum class MustTaskType(val defaultMinutes: Int, val fridayOverrideMinutes: Int? = null) {
    FAJR(10),
    DHUHR(15, fridayOverrideMinutes = 38),
    ASR(15),
    MAGHRIB(10),
    ISHA(15),
    TAHAJUD(30),
    ADHKAR_SABAH(10),
    ADHKAR_MASA(10),
    READ_TWO_HOURS(120);

    fun durationMinutesFor(date: LocalDate): Int {
        return if (this == DHUHR && date.dayOfWeek == java.time.DayOfWeek.FRIDAY) {
            fridayOverrideMinutes ?: defaultMinutes
        } else {
            defaultMinutes
        }
    }
}

/**
 * Importance tier for OPTIONAL tasks. The user assigns a task to a tier;
 * the app assigns the point value per tier (see PointsEngine.TIER_VALUES).
 */
enum class ImportanceTier {
    IMPORTANT,
    LESS_IMPORTANT
}

/**
 * The two lockdown modes used during a task's verification timer.
 *
 * SINGLE_APP: only EYL (or one designated app) is reachable — used for
 * adhkar-on-phone, reading, anything that should have zero distraction.
 *
 * WHITELIST: a pre-defined set of apps stay reachable — used for tasks
 * like freelancing where multiple work apps are legitimately needed.
 * The whitelist is baked into the task definition once, not chosen
 * per-session, so lockdown engages automatically when the task starts.
 */
enum class LockdownMode {
    SINGLE_APP,
    WHITELIST,
    NONE // for must-tasks like prayer where the phone should be untouched entirely
}

/**
 * A single task instance for a given day.
 * MUST tasks are generated automatically each day from MustTaskType.
 * OPTIONAL tasks are created by the user, who sets: title, tier, duration,
 * and lockdown mode (whitelist apps if applicable).
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val date: LocalDate,
    val category: TaskCategory,
    val title: String,
    // Only set when category == MUST
    val mustTaskType: MustTaskType? = null,
    // Only set when category == OPTIONAL
    val tier: ImportanceTier? = null,
    val durationMinutes: Int,
    val lockdownMode: LockdownMode,
    // App package names allowed during lockdown, only used when lockdownMode == WHITELIST
    val whitelistedPackages: List<String> = emptyList(),
    val status: TaskStatus = TaskStatus.PENDING,
    val startedAt: LocalTime? = null,
    val completedAt: LocalTime? = null,
    // True if the lockdown was broken (interruption slipped through, manual override, etc.)
    val lockdownBroken: Boolean = false
)

enum class TaskStatus {
    PENDING,
    IN_PROGRESS, // timer running, lockdown active
    COMPLETED,   // timer ran to completion without the lockdown being broken
    FAILED       // lockdown broken, or day ended with task incomplete
}
