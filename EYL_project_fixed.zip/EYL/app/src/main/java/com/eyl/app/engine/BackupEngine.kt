package com.eyl.app.engine

import com.eyl.app.data.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/**
 * Milestone 4 — "cloud backup and sync" honesty substitute.
 *
 * Real automatic cloud sync needs a backend (Firebase, a custom server,
 * etc.) — infrastructure that can't be provisioned as part of this local
 * app build, and would meaningfully increase the app's size/complexity
 * on a low-RAM target device. Instead: this exports all local data to a
 * single JSON file the user saves wherever they like (Google Drive, email
 * to themselves, a USB transfer, etc.) via Android's Storage Access
 * Framework, and can re-import it later — manual backup/restore, not
 * automatic sync, but genuinely working without needing any external
 * service or account.
 *
 * Uses org.json (built into Android, no extra dependency) rather than a
 * reflection-based serialization library, since the data model is small
 * and stable enough that explicit mapping is clearer and safer than
 * relying on annotation-processing magic.
 */
object BackupEngine {

    fun exportToJson(
        tasks: List<Task>,
        ledgers: List<PointsLedger>,
        templates: List<TaskTemplate>
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("tasks", JSONArray(tasks.map { taskToJson(it) }))
        root.put("ledgers", JSONArray(ledgers.map { ledgerToJson(it) }))
        root.put("templates", JSONArray(templates.map { templateToJson(it) }))
        return root.toString(2)
    }

    data class ImportResult(
        val tasks: List<Task>,
        val ledgers: List<PointsLedger>,
        val templates: List<TaskTemplate>
    )

    fun importFromJson(json: String): ImportResult {
        val root = JSONObject(json)
        val tasks = (0 until root.getJSONArray("tasks").length())
            .map { taskFromJson(root.getJSONArray("tasks").getJSONObject(it)) }
        val ledgers = (0 until root.getJSONArray("ledgers").length())
            .map { ledgerFromJson(root.getJSONArray("ledgers").getJSONObject(it)) }
        val templates = (0 until root.getJSONArray("templates").length())
            .map { templateFromJson(root.getJSONArray("templates").getJSONObject(it)) }
        return ImportResult(tasks, ledgers, templates)
    }

    private fun taskToJson(t: Task): JSONObject = JSONObject().apply {
        put("id", t.id)
        put("date", t.date.toString())
        put("category", t.category.name)
        put("title", t.title)
        put("mustTaskType", t.mustTaskType?.name ?: JSONObject.NULL)
        put("tier", t.tier?.name ?: JSONObject.NULL)
        put("durationMinutes", t.durationMinutes)
        put("lockdownMode", t.lockdownMode.name)
        put("whitelistedPackages", JSONArray(t.whitelistedPackages))
        put("status", t.status.name)
        put("startedAt", t.startedAt?.toString() ?: JSONObject.NULL)
        put("completedAt", t.completedAt?.toString() ?: JSONObject.NULL)
        put("lockdownBroken", t.lockdownBroken)
    }

    private fun taskFromJson(o: JSONObject): Task = Task(
        id = o.getString("id"),
        date = LocalDate.parse(o.getString("date")),
        category = TaskCategory.valueOf(o.getString("category")),
        title = o.getString("title"),
        mustTaskType = if (o.isNull("mustTaskType")) null else MustTaskType.valueOf(o.getString("mustTaskType")),
        tier = if (o.isNull("tier")) null else ImportanceTier.valueOf(o.getString("tier")),
        durationMinutes = o.getInt("durationMinutes"),
        lockdownMode = LockdownMode.valueOf(o.getString("lockdownMode")),
        whitelistedPackages = (0 until o.getJSONArray("whitelistedPackages").length())
            .map { o.getJSONArray("whitelistedPackages").getString(it) },
        status = TaskStatus.valueOf(o.getString("status")),
        startedAt = if (o.isNull("startedAt")) null else LocalTime.parse(o.getString("startedAt")),
        completedAt = if (o.isNull("completedAt")) null else LocalTime.parse(o.getString("completedAt")),
        lockdownBroken = o.getBoolean("lockdownBroken")
    )

    private fun ledgerToJson(l: PointsLedger): JSONObject = JSONObject().apply {
        put("date", l.date.toString())
        put("mustTasksAllCompleted", l.mustTasksAllCompleted)
        put("rawOptionalPoints", l.rawOptionalPoints)
        put("wakeUpPenaltyApplied", l.wakeUpPenaltyApplied)
        put("finalPoints", l.finalPoints)
        put("breakdown", JSONArray(l.breakdown))
    }

    private fun ledgerFromJson(o: JSONObject): PointsLedger = PointsLedger(
        date = LocalDate.parse(o.getString("date")),
        mustTasksAllCompleted = o.getBoolean("mustTasksAllCompleted"),
        rawOptionalPoints = o.getInt("rawOptionalPoints"),
        wakeUpPenaltyApplied = o.getBoolean("wakeUpPenaltyApplied"),
        finalPoints = o.getInt("finalPoints"),
        breakdown = (0 until o.getJSONArray("breakdown").length())
            .map { o.getJSONArray("breakdown").getString(it) }
    )

    private fun templateToJson(t: TaskTemplate): JSONObject = JSONObject().apply {
        put("id", t.id)
        put("title", t.title)
        put("tier", t.tier.name)
        put("durationMinutes", t.durationMinutes)
        put("lockdownMode", t.lockdownMode.name)
        put("whitelistedPackages", JSONArray(t.whitelistedPackages))
    }

    private fun templateFromJson(o: JSONObject): TaskTemplate = TaskTemplate(
        id = o.getString("id"),
        title = o.getString("title"),
        tier = ImportanceTier.valueOf(o.getString("tier")),
        durationMinutes = o.getInt("durationMinutes"),
        lockdownMode = LockdownMode.valueOf(o.getString("lockdownMode")),
        whitelistedPackages = (0 until o.getJSONArray("whitelistedPackages").length())
            .map { o.getJSONArray("whitelistedPackages").getString(it) }
    )
}
