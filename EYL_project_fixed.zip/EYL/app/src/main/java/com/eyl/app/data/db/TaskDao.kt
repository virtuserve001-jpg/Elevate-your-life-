package com.eyl.app.data.db

import androidx.room.*
import com.eyl.app.data.model.Task
import com.eyl.app.data.model.TaskCategory
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: Task)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tasks: List<Task>)

    @Update
    suspend fun update(task: Task)

    @Query("SELECT * FROM tasks WHERE date = :date ORDER BY category, title")
    fun observeTasksForDate(date: LocalDate): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE date = :date AND category = :category")
    suspend fun getTasksForDate(date: LocalDate, category: TaskCategory): List<Task>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Task?

    @Query("DELETE FROM tasks WHERE date = :date AND category = :category")
    suspend fun clearTasksForDate(date: LocalDate, category: TaskCategory)

    @Query("SELECT * FROM tasks")
    suspend fun getAllTasks(): List<Task>
}
