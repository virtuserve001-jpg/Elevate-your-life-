package com.eyl.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.eyl.app.engine.DailyRolloverScheduler

/**
 * WorkManager's periodic work generally survives reboots on its own, but
 * some OEM Android Go skins are known to wipe scheduled work aggressively
 * to save space/battery. Re-asserting the schedule on boot costs nothing
 * (enqueueUniquePeriodicWork with KEEP policy is a no-op if it's already
 * there) and is cheap insurance for exactly the kind of device this app
 * targets.
 *
 * NOTE: the actual wake-up alarm (AlarmScheduler.scheduleWakeUpAlarm) is
 * NOT re-armed here, because it needs the user's chosen alarm time, which
 * isn't modeled/persisted yet (see README — alarm-time settings screen is
 * still an open TODO). Once that setting exists, re-arm it here too.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DailyRolloverScheduler.scheduleDaily(context)
        }
    }
}
