package com.eyl.app.data.db

import androidx.room.*
import com.eyl.app.data.model.TaskTemplate
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskTemplateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(template: TaskTemplate)

    @Delete
    suspend fun delete(template: TaskTemplate)

    @Query("SELECT * FROM task_templates ORDER BY title")
    fun observeAll(): Flow<List<TaskTemplate>>

    @Query("SELECT * FROM task_templates ORDER BY title")
    suspend fun getAll(): List<TaskTemplate>
}
