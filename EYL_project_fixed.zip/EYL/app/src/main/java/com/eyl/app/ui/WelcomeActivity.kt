package com.eyl.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.eyl.app.R

/**
 * First-run explanation screen. Shown once (tracked via SharedPreferences),
 * then skipped on every future launch — WelcomeActivity is the app's
 * launcher, and immediately hands off to MainActivity if the user has
 * already seen this once, so returning users never see it again.
 */
class WelcomeActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "eyl_prefs"
        private const val KEY_SEEN_WELCOME = "has_seen_welcome"

        fun hasSeenWelcome(context: Context): Boolean =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SEEN_WELCOME, false)

        private fun markSeen(context: Context) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SEEN_WELCOME, true)
                .apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (hasSeenWelcome(this)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_welcome)

        findViewById<Button>(R.id.buttonGetStarted).setOnClickListener {
            markSeen(this)
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
        }
    }
}
