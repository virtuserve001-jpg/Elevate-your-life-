package com.eyl.app.ui

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.SpendAllocation
import com.eyl.app.engine.DayWideRestrictionStore
import com.eyl.app.engine.SpendEngine
import kotlinx.coroutines.launch
import java.time.LocalDate

class SpendActivity : AppCompatActivity() {

    private lateinit var app: EylApplication
    private lateinit var restrictionStore: DayWideRestrictionStore
    private val today: LocalDate get() = LocalDate.now()

    private lateinit var textAvailable: TextView
    private lateinit var seekScreenTime: SeekBar
    private lateinit var seekAppUnlock: SeekBar
    private lateinit var seekMobileData: SeekBar
    private lateinit var textScreenTimePreview: TextView
    private lateinit var textAppUnlockPreview: TextView
    private lateinit var textMobileDataPreview: TextView
    private lateinit var containerUnlockChoices: LinearLayout

    private var availablePoints = 0
    private val unlockCheckboxes = mutableMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spend)
        app = application as EylApplication
        restrictionStore = DayWideRestrictionStore(this)

        textAvailable = findViewById(R.id.textAvailablePoints)
        seekScreenTime = findViewById(R.id.seekScreenTime)
        seekAppUnlock = findViewById(R.id.seekAppUnlock)
        seekMobileData = findViewById(R.id.seekMobileData)
        textScreenTimePreview = findViewById(R.id.textScreenTimePreview)
        textAppUnlockPreview = findViewById(R.id.textAppUnlockPreview)
        textMobileDataPreview = findViewById(R.id.textMobileDataPreview)
        containerUnlockChoices = findViewById(R.id.containerUnlockChoices)

        val blockReason = intent.getStringExtra("block_reason")
        if (blockReason != null) {
            findViewById<TextView>(R.id.textBlockReason).apply {
                text = blockReason
                visibility = View.VISIBLE
            }
        }

        findViewById<EditText>(R.id.editRestrictedPackages).setText(
            restrictionStore.getRestrictedPackages().joinToString(", ")
        )
        findViewById<Button>(R.id.buttonSaveRestrictedPackages).setOnClickListener {
            val text = findViewById<EditText>(R.id.editRestrictedPackages).text.toString()
            val packages = text.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
            restrictionStore.setRestrictedPackages(packages)
            rebuildUnlockChoices()
            Toast.makeText(this, "Restricted list saved", Toast.LENGTH_SHORT).show()
        }

        lifecycleScope.launch { loadState() }

        findViewById<Button>(R.id.buttonSaveAllocation).setOnClickListener { saveAllocation() }

        seekScreenTime.setOnSeekBarChangeListener(previewUpdater { updatePreviews() })
        seekAppUnlock.setOnSeekBarChangeListener(previewUpdater {
            updatePreviews()
            rebuildUnlockChoices()
        })
        seekMobileData.setOnSeekBarChangeListener(previewUpdater { updatePreviews() })
    }

    private suspend fun loadState() {
        availablePoints = app.repository.getSpendablePoints(today)
        textAvailable.text = "$availablePoints points available today"

        seekScreenTime.max = availablePoints
        seekAppUnlock.max = availablePoints
        seekMobileData.max = availablePoints

        val existing = app.repository.getSpendAllocation(today)
        if (existing != null) {
            seekScreenTime.progress = existing.screenTimePointsSpent
            seekAppUnlock.progress = existing.appUnlockPointsSpent
            seekMobileData.progress = existing.mobileDataPointsSpent
        }

        rebuildUnlockChoices(preselect = existing?.unlockedPackages?.toSet() ?: emptySet())
        updatePreviews()
    }

    private fun updatePreviews() {
        clampToAvailable()
        textScreenTimePreview.text =
            "${seekScreenTime.progress} pts → ${SpendEngine.screenTimeBudgetMinutes(seekScreenTime.progress)} min today"
        val maxUnlocks = SpendEngine.maxAppUnlocksFor(seekAppUnlock.progress)
        textAppUnlockPreview.text = "${seekAppUnlock.progress} pts → up to $maxUnlocks app(s) unlocked"
        textMobileDataPreview.text =
            "${seekMobileData.progress} pts → ${SpendEngine.mobileDataBudgetMb(seekMobileData.progress)} MB tracked (not enforced)"
    }

    /** Keeps the three sliders from summing past what's actually available. */
    private fun clampToAvailable() {
        val total = seekScreenTime.progress + seekAppUnlock.progress + seekMobileData.progress
        if (total > availablePoints) {
            val over = total - availablePoints
            seekMobileData.progress = (seekMobileData.progress - over).coerceAtLeast(0)
        }
    }

    private fun rebuildUnlockChoices(preselect: Set<String> = emptySet()) {
        containerUnlockChoices.removeAllViews()
        unlockCheckboxes.clear()
        val maxUnlocks = SpendEngine.maxAppUnlocksFor(seekAppUnlock.progress)
        val restricted = restrictionStore.getRestrictedPackages()

        if (restricted.isEmpty()) {
            val hint = TextView(this).apply {
                text = "No restricted apps configured yet — add some below."
                setTextColor(0xFF888888.toInt())
            }
            containerUnlockChoices.addView(hint)
            return
        }

        restricted.forEach { pkg ->
            val cb = CheckBox(this).apply {
                text = pkg
                isChecked = pkg in preselect
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked && unlockCheckboxes.values.count { it.isChecked } > maxUnlocks) {
                        this.isChecked = false
                        Toast.makeText(this@SpendActivity, "Increase app-unlock points to unlock more", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            unlockCheckboxes[pkg] = cb
            containerUnlockChoices.addView(cb)
        }
    }

    private fun saveAllocation() {
        clampToAvailable()
        val unlocked = unlockCheckboxes.filterValues { it.isChecked }.keys.toList()

        val allocation = SpendAllocation(
            date = today,
            pointsAvailable = availablePoints,
            screenTimePointsSpent = seekScreenTime.progress,
            appUnlockPointsSpent = seekAppUnlock.progress,
            mobileDataPointsSpent = seekMobileData.progress,
            unlockedPackages = unlocked
        )

        lifecycleScope.launch {
            app.repository.saveSpendAllocation(allocation)
            // Push the new budget into the store the accessibility service
            // actually reads from, so enforcement updates immediately
            // rather than waiting for the next daily rollover.
            restrictionStore.startNewDay(
                today,
                SpendEngine.screenTimeBudgetMinutes(allocation.screenTimePointsSpent),
                unlocked.toSet()
            )
            Toast.makeText(this@SpendActivity, "Allocation saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun previewUpdater(onChange: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onChange()
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
}
