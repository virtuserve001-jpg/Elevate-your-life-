package com.eyl.app.engine

import com.eyl.app.data.model.PointsLedger
import java.time.LocalDate

/**
 * Milestone 4 — streaks and achievements. Pure logic, no Android
 * dependencies, computed from a list of PointsLedger entries (most recent
 * first or in any order — this sorts internally).
 *
 * A "successful day" for streak purposes means mustTasksAllCompleted was
 * true — i.e. the gatekeeper passed, regardless of the exact optional
 * point total. This matches the spirit of the original rulebook: the
 * gatekeeper is what defines whether a day "counts."
 */
object AchievementEngine {

    data class Achievement(val id: String, val title: String, val description: String)

    private val MILESTONES = listOf(3, 7, 14, 30, 100)

    /**
     * Current streak length ending TODAY (or the most recent day with
     * data). Counts consecutive successful days backward from the most
     * recent ledger entry; a single gap (missing ledger or a failed
     * gatekeeper day) breaks the streak.
     */
    fun currentStreak(ledgers: List<PointsLedger>, asOf: LocalDate = LocalDate.now()): Int {
        val byDate = ledgers.associateBy { it.date }
        var streak = 0
        var date = asOf
        while (true) {
            val ledger = byDate[date] ?: break
            if (!ledger.mustTasksAllCompleted) break
            streak++
            date = date.minusDays(1)
        }
        return streak
    }

    /** Longest streak ever seen across the provided history. */
    fun longestStreak(ledgers: List<PointsLedger>): Int {
        if (ledgers.isEmpty()) return 0
        val sorted = ledgers.sortedBy { it.date }
        var longest = 0
        var current = 0
        var previousDate: LocalDate? = null
        for (ledger in sorted) {
            val isConsecutive = previousDate != null && ledger.date == previousDate.plusDays(1)
            current = if (ledger.mustTasksAllCompleted) {
                if (isConsecutive) current + 1 else 1
            } else 0
            longest = maxOf(longest, current)
            previousDate = ledger.date
        }
        return longest
    }

    /** Which streak-length badges have been unlocked, based on the longest streak ever achieved. */
    fun unlockedAchievements(ledgers: List<PointsLedger>): List<Achievement> {
        val longest = longestStreak(ledgers)
        return MILESTONES.filter { longest >= it }.map { days ->
            Achievement(
                id = "streak_$days",
                title = "$days-day streak",
                description = "Completed every must-task $days days in a row"
            )
        }
    }

    /** Total points earned across the provided history — a simple lifetime tally. */
    fun totalPointsEver(ledgers: List<PointsLedger>): Int = ledgers.sumOf { it.finalPoints }
}
