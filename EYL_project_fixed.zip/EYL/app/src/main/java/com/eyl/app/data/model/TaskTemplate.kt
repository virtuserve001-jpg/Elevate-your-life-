package com.eyl.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A reusable task blueprint (Milestone 2). Saved once from an existing
 * optional task, then instantiated into a new Task for "today" whenever
 * the user picks it — avoids re-typing the same title/duration/tier/
 * lockdown/whitelist every time for a recurring optional task.
 */
@Entity(tableName = "task_templates")
data class TaskTemplate(
    @PrimaryKey val id: String,
    val title: String,
    val tier: ImportanceTier,
    val durationMinutes: Int,
    val lockdownMode: LockdownMode,
    val whitelistedPackages: List<String> = emptyList()
)
