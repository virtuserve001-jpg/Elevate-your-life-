package com.eyl.app.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.eyl.app.service.AlarmReceiver
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object AlarmScheduler {

    private const val REQUEST_CODE = 1001

    /**
     * Schedules the wake-up alarm for the given time (today or tomorrow,
     * whichever is next). Uses setAlarmClock() rather than setExactAndAllowWhileIdle()
     * — setAlarmClock is the only reliable way to guarantee exact firing
     * even under Doze mode and aggressive Android Go battery management,
     * and it's semantically correct here: this genuinely IS an alarm clock.
     */
    fun scheduleWakeUpAlarm(context: Context, alarmTime: LocalTime) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val now = LocalDateTime.now()
        var target = LocalDateTime.of(now.toLocalDate(), alarmTime)
        if (target.isBefore(now)) target = target.plusDays(1)
        val triggerAtMillis = target.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // The "show intent" is what the system may display in the lock
        // screen / status bar as "next alarm" — reuse the same PendingIntent
        // target so tapping it also opens the alarm flow.
        val showIntent = PendingIntent.getActivity(
            context, REQUEST_CODE,
            Intent(context, com.eyl.app.ui.AlarmGameActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setAlarmClock(
            AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent),
            pendingIntent
        )
    }

    fun cancelWakeUpAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
