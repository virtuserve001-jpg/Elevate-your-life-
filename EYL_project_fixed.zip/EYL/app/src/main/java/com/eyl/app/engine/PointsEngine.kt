package com.eyl.app.engine

import com.eyl.app.data.model.*
import java.time.LocalDate

/**
 * PointsEngine is the single source of truth for how a day's points are
 * calculated. Nothing else should compute points directly — every rule
 * from the spec lives here so it can be reasoned about and tested in
 * one place.
 *
 * RULES IMPLEMENTED:
 * 1. Gatekeeper: if ANY must-task for the day isn't COMPLETED, finalPoints = 0.
 * 2. Fixed value per importance tier (not user-chosen, not pooled/split).
 * 3. Wake-up penalty: a separate deduction from the wake-up game time limit,
 *    applied on top of (2) but only relevant if the gatekeeper didn't
 *    already zero the day.
 */
object PointsEngine {

    // Fixed point values per tier. Tunable constants, not user-editable.
    private const val IMPORTANT_TIER_POINTS = 15
    private const val LESS_IMPORTANT_TIER_POINTS = 5

    // Flat deduction applied when the wake-up game isn't beaten inside the
    // 30-minute limit. This is a penalty, not a gatekeeper zero-out, so it
    // only matters when must-tasks were otherwise all completed.
    private const val WAKE_UP_PENALTY_POINTS = 20

    fun tierValue(tier: ImportanceTier): Int = when (tier) {
        ImportanceTier.IMPORTANT -> IMPORTANT_TIER_POINTS
        ImportanceTier.LESS_IMPORTANT -> LESS_IMPORTANT_TIER_POINTS
    }

    /**
     * Calculates the final ledger for a single day.
     *
     * @param date the day being calculated
     * @param mustTasks all MUST tasks scheduled for that day (should be one
     *        per MustTaskType — 5 prayers + adhkar x2 + tahajud + read)
     * @param optionalTasks all OPTIONAL tasks the user created for that day
     * @param wakeUpState the wake-up game state for that day, or null if
     *        there was no alarm/game tracked for the day (e.g. day off)
     */
    fun calculateDay(
        date: LocalDate,
        mustTasks: List<Task>,
        optionalTasks: List<Task>,
        wakeUpState: WakeUpGameState?
    ): PointsLedger {
        val breakdown = mutableListOf<String>()

        // --- Rule 1: gatekeeper check ---
        val allMustCompleted = mustTasks.isNotEmpty() &&
            mustTasks.all { it.status == TaskStatus.COMPLETED }

        if (mustTasks.any { it.status != TaskStatus.COMPLETED }) {
            val missed = mustTasks.filter { it.status != TaskStatus.COMPLETED }
                .map { it.mustTaskType?.name ?: it.title }
            breakdown.add("Gatekeeper triggered — missed must-task(s): ${missed.joinToString()}")
            return PointsLedger(
                date = date,
                mustTasksAllCompleted = false,
                rawOptionalPoints = sumOptionalPoints(optionalTasks),
                wakeUpPenaltyApplied = false, // moot, day is already zero
                finalPoints = 0,
                breakdown = breakdown
            )
        }

        breakdown.add("All must-tasks completed — gatekeeper passed")

        // --- Rule 2: tier-based optional points ---
        val rawPoints = sumOptionalPoints(optionalTasks)
        breakdown.add("Optional task points: $rawPoints")

        // --- Rule 3: wake-up penalty (independent of gatekeeper, applied after) ---
        var finalPoints = rawPoints
        var penaltyApplied = false
        if (wakeUpState != null && wakeUpState.penaltyApplied) {
            penaltyApplied = true
            finalPoints = (finalPoints - WAKE_UP_PENALTY_POINTS).coerceAtLeast(0)
            breakdown.add("Wake-up penalty applied: -$WAKE_UP_PENALTY_POINTS (exceeded ${WakeUpGameState.TIME_LIMIT_MINUTES} min limit)")
        }

        return PointsLedger(
            date = date,
            mustTasksAllCompleted = allMustCompleted,
            rawOptionalPoints = rawPoints,
            wakeUpPenaltyApplied = penaltyApplied,
            finalPoints = finalPoints,
            breakdown = breakdown
        )
    }

    private fun sumOptionalPoints(optionalTasks: List<Task>): Int {
        return optionalTasks
            .filter { it.status == TaskStatus.COMPLETED }
            .sumOf { task -> task.tier?.let { tierValue(it) } ?: 0 }
    }
}
