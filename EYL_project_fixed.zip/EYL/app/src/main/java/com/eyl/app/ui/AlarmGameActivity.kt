package com.eyl.app.ui

import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eyl.app.EylApplication
import com.eyl.app.R
import com.eyl.app.data.model.WakeUpGameState
import com.eyl.app.engine.WakeUpGameEngine
import com.eyl.app.service.LockdownForegroundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import kotlin.random.Random

/**
 * The mandatory wake-up game. Cannot be dismissed except by winning a
 * round — no back button handling that exits, no swipe-away
 * (excludeFromRecents + singleInstance is set in the manifest for
 * exactly this reason).
 *
 * MILESTONE 4 — now alternates between two game types by attempt number,
 * so it's not the same puzzle every single morning:
 * - TAP_SEQUENCE: tap number tiles 1..N in ascending order (the original game).
 * - MATH_CHALLENGE: solve a simple arithmetic problem, pick the right
 *   answer from a few options.
 * Both scale difficulty from the same WakeUpGameEngine.paramsForLevel(),
 * so the "gets harder every failed attempt" rule still lives in exactly
 * one place, not duplicated per game type.
 */
class AlarmGameActivity : AppCompatActivity() {

    private enum class GameType { TAP_SEQUENCE, MATH_CHALLENGE }

    private lateinit var app: EylApplication
    private lateinit var grid: GridLayout
    private lateinit var textAttemptInfo: TextView
    private lateinit var textGameTimer: TextView
    private lateinit var textInstruction: TextView

    private var state: WakeUpGameState? = null
    private var nextExpectedNumber = 1
    private var mathCorrectAnswer = 0
    private var roundTimerJob: kotlinx.coroutines.Job? = null
    private var penaltyCheckJob: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_game)
        app = application as EylApplication

        grid = findViewById(R.id.gridTiles)
        textAttemptInfo = findViewById(R.id.textAttemptInfo)
        textGameTimer = findViewById(R.id.textGameTimer)
        textInstruction = findViewById(R.id.textGameInstruction)

        lifecycleScope.launch {
            val today = LocalDate.now()
            var loaded = app.repository.getWakeUpState(today)
            if (loaded == null) {
                loaded = WakeUpGameEngine.start(today, LocalTime.now())
                app.repository.saveWakeUpState(loaded)
            }
            state = loaded
            startRound()
            startPenaltyWatcher()
        }
    }

    /** No back-button exit — this is intentional per the "no ceiling, must beat it" rule. */
    override fun onBackPressed() {
        // no-op
    }

    private fun startPenaltyWatcher() {
        penaltyCheckJob = lifecycleScope.launch {
            while (true) {
                delay(15_000)
                val s = state ?: continue
                val updated = WakeUpGameEngine.checkPenalty(s, LocalTime.now())
                if (updated != s) {
                    state = updated
                    app.repository.saveWakeUpState(updated)
                }
            }
        }
    }

    /** Alternates game type by attempt count — even attempts get the math
     *  challenge, odd get tap-sequence, so the very first attempt each
     *  morning is always the familiar tap-sequence game. */
    private fun gameTypeFor(attempts: Int): GameType =
        if (attempts % 2 == 0) GameType.TAP_SEQUENCE else GameType.MATH_CHALLENGE

    private fun startRound() {
        val s = state ?: return
        val params = WakeUpGameEngine.paramsForLevel(s.currentDifficultyLevel)
        textAttemptInfo.text = "Attempt ${s.attempts + 1} · difficulty ${s.currentDifficultyLevel}"

        when (gameTypeFor(s.attempts)) {
            GameType.TAP_SEQUENCE -> {
                textInstruction.text = "Tap the numbers in order, fastest first"
                nextExpectedNumber = 1
                buildSequenceGrid(params.targetSequenceLength, params.distractionsEnabled)
            }
            GameType.MATH_CHALLENGE -> {
                buildMathGrid(params.targetSequenceLength)
            }
        }
        runRoundTimer(params.timeLimitSeconds)
    }

    private fun buildSequenceGrid(sequenceLength: Int, distractionsEnabled: Boolean) {
        grid.removeAllViews()
        grid.columnCount = 4

        val numberLabels = (1..sequenceLength).map { it.toString() }.toMutableList()
        val decoyCount = if (distractionsEnabled) (sequenceLength / 2).coerceAtLeast(2) else 0
        val decoyLabels = (1..decoyCount).map { listOf('★', '?', '#', '@', '%').random().toString() }

        val allLabels = (numberLabels + decoyLabels).shuffled()

        allLabels.forEach { label ->
            val button = Button(this).apply {
                text = label
                textSize = 20f
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 160
                    height = 160
                    setMargins(8, 8, 8, 8)
                }
                setOnClickListener { onSequenceTileTapped(label) }
            }
            grid.addView(button)
        }
    }

    /**
     * Difficulty scaling for the math game reuses the sequence length as a
     * rough proxy for "how big the numbers get" — level 1 keeps numbers
     * small (single digits), higher levels use larger operands. Kept
     * simple deliberately; this is a groggy-morning challenge, not a
     * real arithmetic test.
     */
    private fun buildMathGrid(difficultyProxy: Int) {
        grid.removeAllViews()
        grid.columnCount = 2

        val maxOperand = (5 + difficultyProxy * 2).coerceAtMost(50)
        val a = Random.nextInt(1, maxOperand)
        val b = Random.nextInt(1, maxOperand)
        val useSubtraction = Random.nextBoolean() && a > b
        val question = if (useSubtraction) "$a − $b" else "$a + $b"
        mathCorrectAnswer = if (useSubtraction) a - b else a + b

        textInstruction.text = "Solve: $question = ?"

        val wrongAnswers = mutableSetOf<Int>()
        while (wrongAnswers.size < 3) {
            val delta = Random.nextInt(1, 10) * (if (Random.nextBoolean()) 1 else -1)
            val candidate = mathCorrectAnswer + delta
            if (candidate != mathCorrectAnswer && candidate >= 0) wrongAnswers.add(candidate)
        }

        val options = (wrongAnswers + mathCorrectAnswer).shuffled()
        options.forEach { value ->
            val button = Button(this).apply {
                text = value.toString()
                textSize = 22f
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 320
                    height = 160
                    setMargins(8, 8, 8, 8)
                }
                setOnClickListener { onMathAnswerTapped(value) }
            }
            grid.addView(button)
        }
    }

    private fun onSequenceTileTapped(label: String) {
        val expected = nextExpectedNumber.toString()
        if (label != expected) {
            onRoundFailed()
            return
        }
        nextExpectedNumber++
        val s = state ?: return
        val params = WakeUpGameEngine.paramsForLevel(s.currentDifficultyLevel)
        if (nextExpectedNumber > params.targetSequenceLength) {
            onRoundWon()
        }
    }

    private fun onMathAnswerTapped(chosen: Int) {
        if (chosen == mathCorrectAnswer) onRoundWon() else onRoundFailed()
    }

    private fun runRoundTimer(seconds: Int) {
        roundTimerJob?.cancel()
        roundTimerJob = lifecycleScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                textGameTimer.text = "$remaining s"
                delay(1000)
                remaining--
            }
            onRoundFailed()
        }
    }

    private fun onRoundFailed() {
        roundTimerJob?.cancel()
        val s = state ?: return
        val updated = WakeUpGameEngine.onAttemptFailed(s)
        state = updated
        lifecycleScope.launch {
            app.repository.saveWakeUpState(updated)
            startRound() // immediately re-present, one level harder — no ceiling
        }
    }

    private fun onRoundWon() {
        roundTimerJob?.cancel()
        val s = state ?: return
        val updated = WakeUpGameEngine.onGameBeaten(s, LocalTime.now())
        state = updated
        lifecycleScope.launch {
            app.repository.saveWakeUpState(updated)
            LockdownForegroundService.stopAlarmRinging(this@AlarmGameActivity)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        roundTimerJob?.cancel()
        penaltyCheckJob?.cancel()
    }
}
