package com.eyl.app.engine

import android.content.Context
import androidx.work.*
import com.eyl.app.EylApplication
import com.eyl.app.data.model.PointsLedger
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

/**
 * Runs once a day, timed near midnight. Two jobs:
 * 1. Make sure today's MUST tasks exist (delegates to
 *    EylRepository.ensureMustTasksExist — idempotent).
 * 2. Make sure YESTERDAY has a finalized PointsLedger, even if the user
 *    never opened the app to trigger a recalculation (e.g. they failed
 *    a must-task and then just... didn't open EYL again that day). This
 *    is what makes the gatekeeper rule actually stick rather than being
 *    something you can dodge by not looking at the app.
 */
class DailyRolloverWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as EylApplication
        val repository = app.repository

        val today = LocalDate.now()
        val yesterday = today.minusDays(1)

        // Resolve any task from yesterday still stuck at IN_PROGRESS (e.g. the
        // foreground service got killed mid-task) before finalizing the ledger,
        // so a stale "running" task doesn't just get silently treated as missed
        // without an explicit FAILED status.
        repository.reconcileOrphanedTasks(yesterday)

        // Finalize yesterday if it wasn't already.
        if (repository.getLedger(yesterday) == null) {
            val mustTasks = repository.getMustTasksForDate(yesterday)
            val optionalTasks = repository.getOptionalTasksForDate(yesterday)
            val wakeUpState = repository.getWakeUpState(yesterday)
            val ledger: PointsLedger = PointsEngine.calculateDay(yesterday, mustTasks, optionalTasks, wakeUpState)
            repository.saveLedger(ledger)
        }

        // Generate today's must-tasks so they're waiting when the user opens the app.
        repository.ensureMustTasksExist(today, com.eyl.app.data.ReadingAppPreference.get(applicationContext))

        // Reset the day-wide restriction store for today. If the user
        // already set up an allocation via SpendActivity, respect it;
        // otherwise default to a zero budget (no unlocked apps, no screen
        // time) rather than silently carrying over yesterday's numbers —
        // spending has to be a deliberate daily choice, per the spec.
        val restrictionStore = DayWideRestrictionStore(applicationContext)
        val existingAllocation = repository.getSpendAllocation(today)
        if (existingAllocation != null) {
            restrictionStore.startNewDay(
                today,
                SpendEngine.screenTimeBudgetMinutes(existingAllocation.screenTimePointsSpent),
                existingAllocation.unlockedPackages.toSet()
            )
        } else {
            restrictionStore.startNewDay(today, budgetMinutes = 0, unlockedPackages = emptySet())
        }

        return Result.success()
    }
}

object DailyRolloverScheduler {

    private const val WORK_NAME = "eyl_daily_rollover"

    /**
     * Schedules the rollover to run once a day, first firing at the next
     * 00:05 (five minutes past midnight, giving a small buffer past exact
     * midnight for clock/timezone edge cases). Uses WorkManager's periodic
     * work rather than AlarmManager since exact timing doesn't matter here
     * — a few minutes of slack overnight is fine, and periodic WorkManager
     * work survives reboots without a BootReceiver of its own.
     */
    fun scheduleDaily(context: Context) {
        val now = LocalDateTime.now()
        var nextRun = LocalDateTime.of(now.toLocalDate(), LocalTime.of(0, 5))
        if (now.isAfter(nextRun)) nextRun = nextRun.plusDays(1)
        val initialDelay = Duration.between(now, nextRun).toMinutes()

        val request = PeriodicWorkRequestBuilder<DailyRolloverWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(initialDelay, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(false) // must run even on low battery — the day still ends
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
