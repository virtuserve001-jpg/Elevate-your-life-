# EYL — Elevate Your Life
### Complete build specification (from scratch)

This document is self-contained. Everything needed to build EYL — the concept, every rule, the full architecture, and every file's responsibility — is written out here so this can be built from zero, without needing to read any prior source code.

Target device: low-end / Android Go phones (e.g. Itel A50 — likely 1-2GB RAM, older Android version, aggressive battery management). Every technical decision below was made with that constraint in mind.

---

## 1. The concept

EYL is a personal discipline app built around one idea: **tasks aren't "done" because you say so — they're verified by a timer, and the app actively enforces that you can't fake it.**

The user has two kinds of tasks each day:

- **Must-tasks** — non-negotiable, identical every day: 5 daily prayers, adhkar (masa/evening + sabah/morning), tahajud, and a 2-hour read.
- **Optional tasks** — whatever the user defines that day, each placed into one of two importance tiers (Important / Less Important) by the user.

Completing tasks earns points. Points are spent the next day on personal privileges (screen time, app access, mobile data budget). The whole system is designed to be **hard to cheat** — verification isn't "tap a checkbox," it's "run a timer, and the phone enforces you can't do anything else while it runs."

There's also a mandatory wake-up alarm: it doesn't stop ringing until the user beats a minigame, and the minigame gets harder every time they fail it.

---

## 2. The complete rulebook (locked, do not change without deliberate reason)

### Rule 1 — Must-tasks are a GATEKEEPER
If **any single** must-task is missed for the day (even one prayer), the **entire day's points become zero** — regardless of how many optional tasks were completed. This is intentional and harsh: must-tasks are meant to function as a floor, not just heavily-weighted items.

### Rule 2 — Tier points are FIXED, not user-set
The user places each optional task into a tier (Important / Less Important) but does **not** choose the point value — the app assigns a fixed value per tier. This prevents users from inflating their own score. Suggested values (tunable, but keep the ratio meaningful): Important = 15 pts, Less Important = 5 pts.

### Rule 3 — Points currency: one pool, flexible spend
All earned points go into a single pool. The next day, the user allocates that pool across three currencies at a fixed exchange rate:
- **Screen time** (minutes of non-EYL app usage)
- **Mobile data** (a data budget — see honesty note in section 6)
- **App unlocks** (unlocking specific apps the user has designated as "restricted by default")

Points spent on one currency reduce what's available for the others (it's one pool, not three separate pools).

### Rule 4 — Verification is timer-based, with automatic lockdown
No task is "complete" just because the user says so. Every task has a duration; completing it means running a timer for that full duration **while the phone auto-enforces you can't do anything else disallowed**. Two lockdown modes:
- **Single-app lock**: only one app (or nothing) is reachable — used for reading, phone-based adhkar.
- **Whitelist lock**: a pre-defined set of apps stay reachable — used for tasks like freelancing that legitimately need multiple apps. The whitelist is set once per task definition, not chosen per-session — lockdown engages automatically with zero manual setup each time.

### Rule 5 — Prayer/adhkar/tahajud durations are FIXED; other task durations are user-set
Prayers use fixed default durations (average, not fastest/slowest):
| Task | Minutes |
|---|---|
| Fajr | 10 |
| Dhuhr | 15 (Friday/Jumuah: 38, because khutbah + prayer runs long) |
| Asr | 15 |
| Maghrib | 10 |
| Isha | 15 |
| Tahajud | 30 |
| Adhkar (sabah, masa — each) | 10 |
| 2-hour read | 120 |

These are non-adjustable by the user. Optional tasks have user-set durations.

### Rule 6 — Interruptions are auto-blocked, no exceptions
During any active lockdown, calls, notifications, and other apps are all automatically suppressed — the user never has to make a mid-task decision, and the system never asks. (Tradeoff, stated plainly to the user: this also blocks genuine emergency calls during the lockdown window.)

### Rule 7 — Wake-up game: no ceiling, escalating difficulty, 30-min penalty window
- The alarm has **no time ceiling** — it keeps ringing/re-presenting the game until the user actually beats it. There is no snooze, no dismiss-without-winning.
- Every **failed attempt** makes the next attempt **harder** (difficulty only ever increases within a session, never decreases).
- A failed attempt costs nothing by itself.
- BUT there is a **30-minute limit measured from when the alarm first rang**. If the user is still not up (game not beaten) by then, that day's points take a flat penalty deduction — separate from and less severe than the must-task gatekeeper zero-out. Beating the game after the 30 minutes have already elapsed does **not** retroactively remove the penalty (the penalty is about being up on time, not about eventual success).

---

## 3. Why native Android (not cross-platform)

Flutter/React Native cannot reliably implement Accessibility-Service-based app lockdown or foreground-service-based enforcement — these need direct platform APIs. Build this as a **native Android app in Kotlin**.

`minSdk = 23` is chosen deliberately for reach on older/Android-Go devices like the target phone. `compileSdk`/`targetSdk = 34`.

---

## 4. Full architecture

```
EYL/
├── build.gradle.kts, settings.gradle.kts
├── app/build.gradle.kts
├── app/src/main/AndroidManifest.xml
├── app/src/main/res/
│   ├── layout/    activity_main, item_task, dialog_add_task,
│   │              activity_task_lockdown, activity_alarm_game,
│   │              activity_spend, activity_setup
│   ├── values/    strings.xml, themes.xml
│   └── xml/       accessibility_service_config.xml
├── app/src/main/java/com/eyl/app/
│   ├── EylApplication.kt
│   ├── data/model/          Task.kt, PointsModels.kt
│   ├── data/db/              Converters.kt, TaskDao.kt, PointsDaos.kt, EylDatabase.kt
│   ├── data/EylRepository.kt
│   ├── engine/
│   │   ├── PointsEngine.kt          (Rules 1, 2, 7-penalty)
│   │   ├── WakeUpGameEngine.kt       (Rule 7)
│   │   ├── TaskTimerManager.kt        (Rules 4, 5, 6)
│   │   ├── PhoneUntouchedMonitor.kt    (Rule 6, for prayer-type tasks)
│   │   ├── SpendEngine.kt              (Rule 3 — exchange rates)
│   │   ├── DayWideRestrictionStore.kt   (Rule 3 — enforcement state)
│   │   ├── AlarmScheduler.kt             (Rule 7 — AlarmManager wiring)
│   │   └── DailyRolloverWorker.kt         (midnight rollover)
│   ├── service/
│   │   ├── LockdownAccessibilityService.kt  (Rules 4, 6, and day-wide Rule 3 enforcement)
│   │   ├── LockdownForegroundService.kt      (keeps enforcement alive; owns TaskTimerManager + alarm sound)
│   │   ├── AlarmReceiver.kt                   (Rule 7 trigger)
│   │   └── BootReceiver.kt                     (re-arms daily rollover after reboot)
│   └── ui/
│       ├── MainActivity.kt          (dashboard)
│       ├── TaskLockdownActivity.kt   (countdown screen + bounce-back target)
│       ├── AlarmGameActivity.kt       (the wake-up minigame)
│       ├── SpendActivity.kt            (Rule 3 spend UI)
│       └── SetupActivity.kt             (permissions onboarding)
└── app/src/test/java/com/eyl/app/engine/
    ├── PointsEngineTest.kt
    └── WakeUpGameEngineTest.kt
```

---

## 5. Data models (Room entities)

### `Task`
```kotlin
enum class TaskCategory { MUST, OPTIONAL }

enum class MustTaskType(val defaultMinutes: Int, val fridayOverrideMinutes: Int? = null) {
    FAJR(10), DHUHR(15, fridayOverrideMinutes = 38), ASR(15), MAGHRIB(10), ISHA(15),
    TAHAJUD(30), ADHKAR_SABAH(10), ADHKAR_MASA(10), READ_TWO_HOURS(120);

    fun durationMinutesFor(date: LocalDate): Int = // Friday check for DHUHR, else defaultMinutes
}

enum class ImportanceTier { IMPORTANT, LESS_IMPORTANT }

enum class LockdownMode { SINGLE_APP, WHITELIST, NONE } // NONE = prayer-type, phone-untouched check instead

enum class TaskStatus { PENDING, IN_PROGRESS, COMPLETED, FAILED }

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val date: LocalDate,
    val category: TaskCategory,
    val title: String,
    val mustTaskType: MustTaskType? = null,      // set only if category == MUST
    val tier: ImportanceTier? = null,             // set only if category == OPTIONAL
    val durationMinutes: Int,
    val lockdownMode: LockdownMode,
    val whitelistedPackages: List<String> = emptyList(), // only used when lockdownMode == WHITELIST
    val status: TaskStatus = TaskStatus.PENDING,
    val startedAt: LocalTime? = null,
    val completedAt: LocalTime? = null,
    val lockdownBroken: Boolean = false
)
```

### `WakeUpGameState`
```kotlin
@Entity(tableName = "wake_up_game_state")
data class WakeUpGameState(
    @PrimaryKey val date: LocalDate,
    val alarmStartedAt: LocalTime,
    val attempts: Int = 0,
    val currentDifficultyLevel: Int = 1,  // increments per failure, never decreases
    val beatenAt: LocalTime? = null,
    val penaltyApplied: Boolean = false
) {
    companion object { const val TIME_LIMIT_MINUTES = 30 }
    fun minutesSinceAlarmStart(now: LocalTime): Long = Duration.between(alarmStartedAt, now).toMinutes()
    fun isPastLimit(now: LocalTime): Boolean = beatenAt == null && minutesSinceAlarmStart(now) >= TIME_LIMIT_MINUTES
}
```

### `PointsLedger`
```kotlin
@Entity(tableName = "points_ledger")
data class PointsLedger(
    @PrimaryKey val date: LocalDate,
    val mustTasksAllCompleted: Boolean,
    val rawOptionalPoints: Int,
    val wakeUpPenaltyApplied: Boolean,
    val finalPoints: Int,
    val breakdown: List<String> = emptyList()  // human-readable trace for UI transparency
)
```

### `SpendAllocation`
```kotlin
@Entity(tableName = "spend_allocation")
data class SpendAllocation(
    @PrimaryKey val date: LocalDate,
    val pointsAvailable: Int,
    val screenTimePointsSpent: Int = 0,
    val mobileDataPointsSpent: Int = 0,   // tracked only, see section 6
    val appUnlockPointsSpent: Int = 0,
    val unlockedPackages: List<String> = emptyList()
) {
    val pointsRemaining: Int get() = pointsAvailable - screenTimePointsSpent - mobileDataPointsSpent - appUnlockPointsSpent
    init { require(pointsRemaining >= 0) }
}
```

Room `TypeConverters` needed: `LocalDate ↔ String`, `LocalTime ↔ String`, each enum `↔ String` (`.name`/`.valueOf()`), and **one single** `List<String> ↔ String` converter shared across all list fields (Room disambiguates converters by type signature, not name, so you can only have one converter per type pair — use a pipe delimiter `"|~|"` that's safe for both package names and free-text breakdown strings).

---

## 6. The three enforcement mechanisms — build these honestly

This is the part most likely to go wrong if rebuilt casually. Be precise about what's actually enforceable on a normal (non-Device-Owner) Android app.

### 6a. Task lockdown (app-blocking) — `LockdownAccessibilityService`
Android fires `TYPE_WINDOW_STATE_CHANGED` accessibility events whenever the foreground app changes. While a task's lockdown is active:
- `SINGLE_APP` mode: only the EYL app itself is allowed foreground.
- `WHITELIST` mode: only the task's pre-defined package list (+ EYL) is allowed.
- On any other package appearing in `event.packageName`, immediately relaunch the lockdown/task screen (`Intent.FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TOP`) so the disallowed app never gets visible screen time.

Requires: user manually enables this under **Settings → Accessibility → EYL** (cannot be granted programmatically — Android's design). This permission is heavily scrutinized by Play Store review as historically malware-abused; expect friction if distributing there vs. sideloading.

### 6b. Prayer/adhkar/tahajud enforcement — `PhoneUntouchedMonitor`
This is the **opposite** mechanic from app-blocking: the phone should be completely untouched, not confined to an app. Register (dynamically, via `Context.registerReceiver` — these are implicit broadcasts that can't be statically declared in the manifest since Android 8) for:
- `Intent.ACTION_SCREEN_ON`
- `Intent.ACTION_USER_PRESENT` (unlock)

Any of these firing during the task window = fail the task immediately. Also check `PowerManager.isInteractive` at task-start time — if the screen is *already* on/unlocked the moment the task begins, fail immediately rather than starting a countdown that's already compromised.

**Known, accepted gap**: this cannot detect an already-on, already-unlocked phone sitting face-up being glanced at without a fresh unlock event. Closing that needs touch/accelerometer sampling, which costs real battery on a low-end device — document this as a deliberate v1 tradeoff, don't silently claim full coverage.

### 6c. Points spending — `SpendEngine` + `DayWideRestrictionStore` + accessibility service extension
Two of the three currencies are genuinely enforceable using the same accessibility-service mechanism as task lockdown, layered to apply **only when no task lockdown is active** (task lockdown always wins):
- **Screen time**: track elapsed foreground time for non-EYL apps between consecutive `TYPE_WINDOW_STATE_CHANGED` events; once the daily budget (minutes = points spent × exchange rate) is exhausted, bounce back to EYL for any further non-EYL foreground app.
- **App unlocks**: user maintains a list of "restricted by default" packages; spending points unlocks specific ones for the day (capped by how many points were spent — e.g. 10 pts per unlock). Anything restricted-and-not-unlocked gets bounced back, exactly like task lockdown's disallowed-app case.

**Mobile data is NOT enforceable** without either (a) Device Owner/Profile Owner provisioning via `DevicePolicyManager` (needs a factory-reset + QR/NFC enrollment flow — the same heavy MDM path deliberately ruled out for lockdown), or (b) a `VpnService`-based traffic filter (invasive, battery-costly, routes ALL traffic through the app — too heavy for a personal tool). **Track and display a mobile-data "budget" for the user's own accountability, but say plainly in the UI that EYL cannot technically block data usage.** Do not build a UI that implies enforcement that doesn't exist.

Use `SharedPreferences` (not Room) for the day-wide restriction state — it's small, frequently-read (checked on every foreground-app switch), rarely-written data; cheaper than a Room query per accessibility event on a low-RAM device.

Reset this store once a day (via the midnight rollover worker): if the user allocated points via the spend UI, apply that; otherwise default to a **zero budget** rather than silently carrying over yesterday's numbers — spending should be a deliberate daily choice.

### 6d. Wake-up alarm — `AlarmScheduler` + `AlarmReceiver` + `LockdownForegroundService`
Use `AlarmManager.setAlarmClock()` (not `setExactAndAllowWhileIdle`) — this is the only mechanism that reliably survives Doze mode and aggressive Android Go battery management, and is semantically correct since this genuinely is an alarm clock.

On firing: launch a full-screen `Activity` (manifest flags: `showWhenLocked="true"`, `turnScreenOn="true"`, `excludeFromRecents="true"`, `launchMode="singleInstance"`) hosting the minigame, and start a foreground service that owns a looping `MediaPlayer` (`AudioAttributes.USAGE_ALARM`) plus vibration. The **only** code path allowed to stop the ringing is confirmation that `WakeUpGameEngine.onGameBeaten()` fired — no back-button handling that exits, no swipe-away.

### 6e. Keeping everything alive — `LockdownForegroundService`
Android Go devices aggressively kill background work to save RAM/battery. A persistent-notification foreground service is the standard defense (not bulletproof — OEM battery managers can still be hostile) — pair it with prompting the user to disable battery optimization specifically for EYL. This service should own the single live `TaskTimerManager` instance (don't create a second one elsewhere — see section 8 pitfalls) and expose an event stream (`StateFlow` or similar) that UI Activities observe for live countdown/status updates.

---

## 7. Core logic — the two pure-logic engines (write these test-first)

### `PointsEngine` (Rules 1, 2, 7-penalty)
Single function: `calculateDay(date, mustTasks, optionalTasks, wakeUpState) -> PointsLedger`.
1. If **any** must-task's status isn't `COMPLETED` → `finalPoints = 0`, done. (Gatekeeper takes absolute priority — check this first, return immediately.)
2. Otherwise sum tier-fixed points for `COMPLETED` optional tasks only.
3. If `wakeUpState.penaltyApplied == true`, subtract a flat penalty amount, floored at 0 — this only matters if step 1 didn't already zero the day.
4. Build a human-readable `breakdown` list explaining what happened, for UI transparency.

### `WakeUpGameEngine` (Rule 7)
Pure functions, no Android dependencies:
- `start(date, alarmStartedAt) -> WakeUpGameState` — level 1, 0 attempts.
- `onAttemptFailed(state) -> WakeUpGameState` — attempts+1, difficulty level+1 (monotonic, never decreases).
- `onGameBeaten(state, beatenAt) -> WakeUpGameState` — sets `beatenAt`; does NOT clear an already-applied penalty.
- `checkPenalty(state, now) -> WakeUpGameState` — idempotent; sets `penaltyApplied = true` the first time `now` is ≥30 min past `alarmStartedAt` and the game hasn't been beaten yet. Safe to call repeatedly.
- `paramsForLevel(level) -> GameParams` — the single place difficulty scaling logic lives (e.g. sequence length grows, time limit shrinks, distractor tiles enable from level 3+). Keep this centralized so "gets harder" isn't duplicated across the UI and the engine.

**Write unit tests for both of these before anything else** — they have zero Android dependencies, run as plain JVM tests (no emulator), and are the cheapest place to catch logic errors. Minimum coverage: gatekeeper zeroing on any single missed must-task; gatekeeper takes priority over (i.e. makes moot) the wake-up penalty; tier point differentiation; penalty floors at zero; difficulty monotonically increases across many failures; exact 30-minute boundary behavior; idempotent penalty checks; beating the game late doesn't retroactively remove an already-applied penalty.

---

## 8. Known pitfalls to avoid on rebuild

1. **Don't create more than one live `TaskTimerManager`.** It's tempting to instantiate one in the Application class for convenience and another inside the foreground service for the actual running task — pick exactly one owner (the foreground service, since its scope must outlive any single Activity) and have everything else reach it through that single instance.
2. **Don't let Room's TypeConverters collide.** Room disambiguates converters purely by type signature. If you write a converter for `List<String> -> String` for package lists and a separate one for ledger breakdown text, Room will throw an ambiguity error at compile time. Use exactly one converter per type-signature pair.
3. **Don't silently no-op when the accessibility service isn't enabled.** If `LockdownAccessibilityService.instance` is null when a task starts, either block the start with a clear message, or explicitly let the user choose "start anyway on the honor system" — don't run an unenforced timer that looks identical to an enforced one.
4. **Don't build UI that implies enforcement your permission model can't deliver.** The mobile-data currency is the clearest example — label it honestly rather than pretending.
5. **Prayer/adhkar/tahajud tasks need `LockdownMode.NONE`**, not `SINGLE_APP` — they need the opposite mechanic (phone untouched) from app-blocking. Auto-generate must-tasks with this in mind: only the 2-hour read (`READ_TWO_HOURS`) should get `SINGLE_APP`.
6. **The wake-up game must never have an exit path other than winning.** No back-button handling that finishes the Activity, no dismissible notification action that stops the ringing.
7. **Test the exact 30-minute boundary**, not just "before" and "long after" — off-by-one errors here (`>` vs `>=`) change real behavior for the user.

---

## 9. Manifest permissions required (all need user action beyond just declaring them)

```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
<uses-permission android:name="android.permission.USE_EXACT_ALARM" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" /> <!-- Android 13+ -->
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
```

Plus the Accessibility Service declaration (with `<meta-data>` pointing at an XML config declaring `accessibilityEventTypes="typeWindowStateChanged"`), and manifest entries for every Activity/Service/Receiver listed in section 4.

Build a **first-run onboarding screen** that checks live status of each of these (accessibility service enabled? battery optimization disabled? notifications granted? exact-alarm scheduling allowed?) and deep-links directly to the right Settings screen for each — none of these can be granted programmatically by design of the Android permission model.

---

## 10. Gradle setup

- `minSdk 23`, `compileSdk`/`targetSdk 34`, Kotlin + KSP (not kapt, for build speed) for Room's annotation processing.
- Dependencies: Room (`room-runtime`, `room-ktx`, `room-compiler` via ksp), `kotlinx-coroutines-android`, `androidx.lifecycle:lifecycle-service`, `androidx.work:work-runtime-ktx` (for the daily rollover), `androidx.appcompat`, `material`, `constraintlayout`.
- Test deps: `junit:junit`, `androidx.test.ext:junit`, `androidx.test.espresso:espresso-core` (Espresso for future UI tests — not required for the two pure-logic engine tests, which need only plain JUnit).

---

## 11. Suggested build order

1. Gradle scaffold + manifest skeleton (get an empty app compiling and installable first).
2. Data models + Room (`Task`, `WakeUpGameState`, `PointsLedger`, `SpendAllocation`, DAOs, converters, database class).
3. `PointsEngine` + `WakeUpGameEngine` + their unit tests — validate the rulebook in isolation before touching any Android APIs.
4. `EylRepository` (DAO wrapper + must-task auto-generation logic).
5. `TaskTimerManager` (the coordinator — but don't wire lockdown enforcement yet, just the countdown + COMPLETED/FAILED state transitions against a fake/no-op lockdown).
6. Basic UI: `MainActivity` dashboard (create a task, start it, watch `PointsEngine` react to real data) — this is the first point you can manually verify the rulebook against real interaction.
7. `LockdownAccessibilityService` + `LockdownForegroundService` — wire real app-blocking lockdown into `TaskTimerManager`.
8. `PhoneUntouchedMonitor` — wire the prayer-type enforcement.
9. `AlarmScheduler` + `AlarmReceiver` + `AlarmGameActivity` — the wake-up flow.
10. `SpendEngine` + `DayWideRestrictionStore` + `SpendActivity` — points spending, with the mobile-data honesty constraint from section 6c.
11. `SetupActivity` — permissions onboarding, last, since it ties together every permission the earlier steps introduced.
12. `DailyRolloverWorker` + `BootReceiver` — midnight rollover and reboot resilience.

---

## 12. What "done" actually requires (don't skip these)

- **Compile it.** This spec has not been run through an actual Android compiler — expect some errors on first build regardless of who/what writes the code.
- **Run it on an emulator first**, then sideload onto the actual target device (Android Go / low-RAM hardware) — foreground-service survival and accessibility-service reliability behave differently on real low-end hardware than in an emulator.
- **Grant every permission manually** via the onboarding screen before expecting any enforcement to actually work — none of it activates until the user does this by hand.
- **Test the gatekeeper rule end-to-end**: complete every must-task except one, confirm the day's points show 0, not just in unit tests but by actually using the app for a day.
